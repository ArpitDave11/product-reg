# WMA Data Product Registration — Demo Guide & API Integration Blueprint

---

## PART 1: DEMO WALKTHROUGH (Sample Inputs for All 10 Steps)

### Before You Start

1. Run `npm run dev` — app opens at http://localhost:3000
2. You will see a green toast **"API connected"** — this confirms the mock API health check passed
3. The API Log bar at the bottom shows 4 entries (health check + draft load)
4. Click the API Log bar to expand it — show the audience real-time API activity

---

### STEP 1: Product Identity

**What to type:**

| Field              | Value to Enter                                              |
|--------------------|-------------------------------------------------------------|
| Product Name       | `WMA Client Account`                                        |
| Product Type       | Select: `Composite Data Product`                            |
| Business Domain    | Select: `Account`                                           |
| Short Description  | `Consolidated client account data for WMA advisory platform` |
| Long Description   | `This data product aggregates account-level information from SPP, CRM, and Core Banking systems. It provides a unified view of client accounts including balances, types, and relationships for use by WMA advisors and analytics teams.` |
| Business Purpose   | `Enable WMA advisors to have a 360-degree view of client accounts for advisory and reporting purposes` |
| Key KPIs / Metrics | `Account coverage rate, Data freshness SLA, Consumer adoption` |
| Consumer Personas  | `Data Scientist, Financial Advisor, Risk Analyst`            |
| Source System      | Select: `SPP`                                               |

**What happens behind the scenes:**

```
1. As you type each field:
   -> updateField('productName', 'W') -> updateField('productName', 'WM') -> ...
   -> React state updates: stepData.step1.productName = "WMA Client Account"

2. 2 seconds after you STOP typing:
   -> AUTO-SAVE fires
   -> API CALL: PUT /metaq-api/registration/draft
   -> INPUT:  stepKey="step1", stepData={productName:"WMA Client Account", productType:"Composite Data Product", ...}
   -> OUTPUT: {success:true, message:"Step 'step1' saved successfully", registrationId:"draft-2026-XXXX"}
   -> Green toast appears: "Draft saved"
   -> API Log shows: PUT /metaq-api/registration/draft -> ok (700ms)

3. When you click "Save & Continue":
   -> API CALL #1: POST /metaq-api/registration/validate
   -> INPUT:  stepKey="step1", stepData={productName:"WMA Client Account", ...all fields above...}
   -> OUTPUT: {valid:true, errors:[], warnings:[]}
      (All required fields filled, all warnings resolved because we filled optional fields too)

   -> API CALL #2: PUT /metaq-api/registration/draft
   -> INPUT:  same stepData
   -> OUTPUT: {success:true, ...}
   -> Green toast: "Step 1 saved"
   -> Form advances to Step 2
```

**Demo tip:** To show validation errors, try clicking "Save & Continue" with Product Type empty. You'll see red borders and error messages. Then fill it and continue.

---

### STEP 2: Ownership & Contacts

**What to type:**

| Field               | Value to Enter             |
|---------------------|----------------------------|
| Data Product Owner  | `john.smith@ubs.com`       |
| Backup Owner        | `jane.doe@ubs.com`         |
| IT Lead             | `mike.chen@ubs.com`        |
| Data Steward        | `sarah.jones@ubs.com`      |
| Distribution List   | `wma-account-team@ubs.com` |
| Support Hours       | Select: `Business Hours (US)` |

**API interaction:**

```
Auto-save: PUT /metaq-api/registration/draft (step2 data, 700ms)
Validate:  POST /metaq-api/registration/validate
  -> Checks: owner field is required AND must be valid email
  -> "john.smith@ubs.com" passes validateEmail regex: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  -> Result: {valid:true, errors:[], warnings:[]}
Save:      PUT /metaq-api/registration/draft
```

**Demo tip:** Type `not-an-email` in Owner field and click Save & Continue. You'll see: "Invalid email format" error. Then fix it to `john.smith@ubs.com`.

---

### STEP 3: Connect to Source & Entitlements

**What to type:**

| Field              | Value to Enter                              |
|--------------------|---------------------------------------------|
| Source Application URL | `https://spp.ubs.com/api/v2`           |
| Environment        | Select: `PROD`                              |
| Storage Location   | `abfss://wma-container@ubsdatalake.dfs.core.windows.net` |
| CID Classification | Select: `Amber`                             |
| Input Datasets     | `rcat0100 (Account base), rcat0200 (Client attributes), rcat0300 (Transaction summary)` |

**API interaction:**

```
Validate: POST /metaq-api/registration/validate
  -> Required fields: environment ("PROD") ✓, cidClassification ("Amber") ✓
  -> Warnings: sourceUrl filled ✓, inputDatasets filled ✓ (no warnings)
  -> Result: {valid:true, errors:[], warnings:[]}
```

**Demo tip:** This step is important for governance — `cidClassification` is checked by the Entitlement Alignment governance check later. If you skip it, governance will FAIL at submission.

---

### STEP 4: KDE Semantics

**What to type:**

| Field               | Value to Enter                              |
|---------------------|---------------------------------------------|
| Business Definitions | `Account: A financial instrument held by a client for the purpose of managing assets. Client: An individual or entity that holds one or more accounts with UBS WMA.` |
| KDE Mapping         | `ACC_N -> Account Number (KDE), ACCT_TYPE_CD -> Account Type Code (KDE), CLIENT_ID -> Client Identifier (KDE)` |
| Ontology Alignment  | `ONT-001 Client, ONT-005 Account`           |
| Glossary Terms      | `Account Balance, Client Relationship, Portfolio`|

**API interaction:**

```
Validate: POST /metaq-api/registration/validate
  -> No required fields for step4
  -> Warnings checked: businessDefs filled ✓, kdeMapping filled ✓
  -> Result: {valid:true, errors:[], warnings:[]}
```

**Demo tip:** This step is marked "Optional" (gray badge). You can click Save & Continue with empty fields — it will pass with warnings only, never errors.

---

### STEP 5: Scope & Data Quality

**What to type:**

| Field           | Value to Enter |
|-----------------|----------------|
| DQ Threshold (%)| `95`           |
| Coverage (%)    | `99.5`         |
| Completeness (%)| `98`           |
| Timeliness      | Select: `Daily`|
| Accuracy Rule   | `All account numbers must pass Luhn check. Client names must match CRM source with >95% fuzzy match score. Transaction amounts must be non-negative.` |

**API interaction:**

```
Validate: POST /metaq-api/registration/validate
  -> Required: threshold ("95") ✓
  -> Warnings: coverage ("99.5") ✓, completeness ("98") ✓
  -> Result: {valid:true, errors:[], warnings:[]}
```

---

### STEP 6: Data Contract

**What to type:**

| Field              | Value to Enter |
|--------------------|----------------|
| Update Frequency   | Select: `Daily` |
| Access Modes       | Select: `API`   |
| SLA Target         | `99.5% availability, max 4hr recovery` |
| Versioning Policy  | Select: `Semantic` |
| Deprecation Policy | `Minimum 6 months notice before deprecation. V(N-1) supported for 12 months after V(N) release. Breaking changes require major version bump and consumer notification via DL.` |

**API interaction:**

```
Validate: POST /metaq-api/registration/validate
  -> Required: updateFrequency ("Daily") ✓
  -> Result: {valid:true, errors:[], warnings:[]}
```

---

### STEP 7: Lineage

**What to type:**

| Field              | Value to Enter |
|--------------------|----------------|
| Upstream Products  | `1. SPP Account Master (rcat0100) - Account base attributes\n2. CRM Client Hub (rcat0200) - Client demographics\n3. Core Banking Transactions (rcat0300) - Transaction summaries` |
| Lineage Narrative  | `Data flows from three upstream systems: SPP provides account-level attributes, CRM provides client identity and demographics, Core Banking provides transaction aggregates. Data is ingested via daily batch ETL, joined on CLIENT_ID, deduplicated, and quality-checked before publishing.` |
| Transformations    | `1. Deduplication on ACC_N (keep latest record)\n2. LEFT JOIN rcat0100 to rcat0200 on CLIENT_ID\n3. Aggregate rcat0300 to account-level\n4. Apply CID masking rules per classification` |
| Data Flow Diagram URL | `https://confluence.ubs.com/wma/lineage/account-dp` |

**API interaction:**

```
Validate: POST /metaq-api/registration/validate
  -> No required fields for step7
  -> All warning fields filled -> no warnings
  -> Result: {valid:true, errors:[], warnings:[]}
```

---

### STEP 8: Sensitivity & Policy

**What to type:**

| Field                | Value to Enter |
|----------------------|----------------|
| Classification       | Select: `Confidential` |
| Retention Requirement| Select: `7 years` |
| Permitted Uses       | `Internal WMA advisory and analytics only. Not approved for external client reporting without DWO sign-off. Cross-border transfer requires regional compliance approval.` |
| Restricted Regions   | `EU (GDPR restrictions apply)` |
| Encryption Required  | Select: `Both` |

**API interaction:**

```
Validate: POST /metaq-api/registration/validate
  -> Required: classification ("Confidential") ✓
  -> Warnings: retentionReq ("7 years") ✓, permittedUses filled ✓
  -> Result: {valid:true, errors:[], warnings:[]}
```

**Demo tip:** `retentionReq` is critical for governance. The Retention Compliance governance check reads this field from store.draft.steps.step8. If empty = governance FAILS.

---

### STEP 9: AI Readiness

**What to type:**

| Field                  | Value to Enter |
|------------------------|----------------|
| AI Ready               | Check the checkbox ✓ |
| AI Use Cases           | `1. Client churn prediction model\n2. Next-best-action recommendation engine\n3. Portfolio anomaly detection` |
| ML Model Compatibility | Select: `Structured only` |
| Feature Store          | Select: `Available` |
| Bias Assessment        | `Account data is representative across client segments. Known bias: higher data completeness for HNW clients vs retail. Mitigation: stratified sampling recommended for model training.` |

**API interaction:**

```
Validate: POST /metaq-api/registration/validate
  -> No required fields for step9 (entire step is optional)
  -> No warning fields either
  -> Result: {valid:true, errors:[], warnings:[]}
```

---

### STEP 10: Attestations & Submit

**What to type:**

| Field                  | Action |
|------------------------|--------|
| Accuracy Attestation   | Check the checkbox ✓ |
| Ownership Attestation  | Check the checkbox ✓ |
| Policy Attestation     | Check the checkbox ✓ |
| Additional Notes       | `First registration for WMA Account data product. Contact john.smith@ubs.com for questions.` |

**Click "Submit Registration" — here is the FULL sequence:**

```
STEP A: Validate attestations
  API CALL: POST /metaq-api/registration/validate
  INPUT:  stepKey="step10", stepData={accuracyAttest:true, ownershipAttest:true, policyAttest:true, additionalNotes:"..."}
  OUTPUT: {valid:true, errors:[], warnings:[]}
  SCREEN: Loading overlay "Validating attestations..."

STEP B: Run governance checks
  API CALL: POST /metaq-api/registration/governance
  INPUT:  reads store.draft.steps (step1, step3, step8)
  CHECKS:
    1. PII detection         -> "passed"  (always passes in mock)
    2. Retention compliance  -> "passed"  (step8.retentionReq = "7 years" ✓)
    3. Naming conventions    -> "warning" (product name "WMA Client Account" has spaces)
    4. Metadata completeness -> "passed"  (step1.longDescription is filled ✓)
    5. Entitlement alignment -> "passed"  (step3.cidClassification = "Amber" ✓)
  OUTPUT: {overallStatus:"passed_with_warnings", checks:[...]}
  SCREEN: Loading overlay "Running governance checks..."

STEP C: Submit registration
  API CALL: POST /metaq-api/registration/submit
  INPUT:  reads entire store.draft
  ACTIONS:
    - Creates catalog entry: {p_dataset_data: {resource_iri:"wma://data-product/wma-client-account", title:"WMA Client Account", ...}}
    - Generates tracking ID: "WMA-2026-XXXX"
    - Initializes 4 automated checks (all "pending")
    - Initializes 3 reviewers (all "Waiting")
  API LOG: POST /metaq-api/registration/submit -> pending
           POST /metaq-api/dataset -> ok (500ms)  (catalog entry created)
           POST /metaq-api/registration/submit -> ok (2000ms)
  OUTPUT: {success:true, trackingId:"WMA-2026-5678", submittedAt:"2026-02-12T...", eta:"3-5 business days"}
  SCREEN: Loading overlay "Submitting registration..."

STEP D: Phase switch
  -> Toast: "Submitted! Tracking: WMA-2026-5678"
  -> Screen switches to POST-SUBMISSION DASHBOARD
  -> Sidebar: all steps show green checkmarks, status = "Submitted"

STEP E: Polling starts (automatic, every 3 seconds)
  Every 3s:
    API CALL: GET /metaq-api/registration/checks
    API CALL: GET /metaq-api/registration/reviews

  Poll 1: Check 1 "running", rest "pending".     Reviews: all "Waiting"
  Poll 2: Check 1 "passed", check 2 "running".   Reviews: all "Waiting"
  Poll 3: Check 2 "passed" (score:87), check 3 "running". Reviews: all "Waiting"
  Poll 4: Check 3 "passed", check 4 "running".   Reviews: all "Waiting"
  Poll 5: ALL checks complete. Check 4 = "warning".  First reviewer -> "Pending"!
  Poll 6+: Same state. Checks show "Completed". First reviewer stays "Pending".
```

**Demo tip for the audience:** Point out the API Log bar — it fills up with every poll. Expand it to show the real-time GET requests cycling every 3 seconds.

---

## PART 2: HOW TO INTEGRATE REAL API ENDPOINTS

### Current Architecture (What You Have Now)

```
                    YOUR APP
                       |
          +------------+------------+
          |                         |
    src/hooks/handlers.ts     src/hooks/useAutoSave.ts
    src/hooks/usePolling.ts
          |                         |
          v                         v
    src/lib/mockApi.ts  <--- ALL API calls go through here
          |
          v
    IN-MEMORY MockStore (JavaScript object, lives in browser memory)
```

**Key insight:** Every API call in the entire app goes through ONE file: `src/lib/mockApi.ts`. The hooks and handlers import functions from this file. The UI components know NOTHING about APIs.

### What You Need to Change (and ONLY This)

You replace `src/lib/mockApi.ts` functions with real `fetch()` calls. **Nothing else changes.**

```
                    YOUR APP (UNCHANGED)
                       |
          +------------+------------+
          |                         |
    src/hooks/handlers.ts     src/hooks/useAutoSave.ts    (NO CHANGES)
    src/hooks/usePolling.ts                                (NO CHANGES)
          |                         |
          v                         v
    src/lib/realApi.ts  <--- NEW FILE (replaces mockApi.ts)
          |
          v
    REAL REST API SERVER (MetaQ API, your backend)
```

### The Contract — What Each Function Must Return

The hooks and handlers expect EXACT response shapes. Your real API functions must return the same shapes. Here is the contract:

#### Function 1: Health Check

```
CURRENT:   mockGetHealth(store, logger) -> { status: "ok" }
REAL:      realGetHealth(logger) -> { status: "ok" }

What changes:
  - Remove `store` parameter (real server IS the store)
  - Remove `delay(300)` (real network provides latency)
  - Replace with: fetch("https://your-server/metaq-api/health")

Example real implementation:
  export async function realGetHealth(logger: Logger): Promise<{status: string}> {
    const entry = createApiLogEntry({method:'GET', endpoint:'/metaq-api/health', status:'pending'});
    logger(entry);
    const response = await fetch('https://your-server/metaq-api/health');
    const data = await response.json();
    logger({...entry, status:'ok', duration: Date.now() - startTime});
    return data;  // Must be: { status: "ok" }
  }
```

#### Function 2: Get Datasets

```
CURRENT:   mockGetDatasets(store, logger)
REAL:      realGetDatasets(logger)
ENDPOINT:  GET /metaq-api/datasets
MUST RETURN: { data: Dataset[], limit: number, offset: number, count: number }
```

#### Function 3: Get Dataset By Title

```
CURRENT:   mockGetDatasetByTitle(store, logger, title)
REAL:      realGetDatasetByTitle(logger, title)
ENDPOINT:  GET /metaq-api/dataset/{title}
MUST RETURN: { data: Dataset[], limit: number, offset: number, count: number }
```

#### Function 4: Get Draft

```
CURRENT:   mockGetDraft(store, logger)
REAL:      realGetDraft(logger)
ENDPOINT:  GET /metaq-api/registration/draft
MUST RETURN:
  { exists: boolean, registrationId: string|null, status: string|null,
    currentStep: number, lastSaved: string|null, steps: Record<string,StepData>|null }
```

#### Function 5: Save Draft

```
CURRENT:   mockSaveDraft(store, logger, stepKey, stepData)
REAL:      realSaveDraft(logger, stepKey, stepData)
ENDPOINT:  PUT /metaq-api/registration/draft
BODY:      { stepKey: "step1", data: { productName: "WMA Account", ... } }
MUST RETURN: { success: boolean, message: string, timestamp: string|null, registrationId: string|null }
```

#### Function 6: Validate Step

```
CURRENT:   mockValidateStep(store, logger, stepKey, stepData)
REAL:      realValidateStep(logger, stepKey, stepData)
ENDPOINT:  POST /metaq-api/registration/validate
BODY:      { stepKey: "step1", data: { productName: "WMA Account", ... } }
MUST RETURN: { valid: boolean, errors: FieldError[], warnings: FieldError[] }
  where FieldError = { field: string, message: string }
```

#### Function 7: Run Governance Checks

```
CURRENT:   mockRunGovernanceChecks(store, logger)
REAL:      realRunGovernanceChecks(logger)
ENDPOINT:  POST /metaq-api/registration/governance
MUST RETURN:
  { overallStatus: "passed"|"passed_with_warnings"|"failed",
    checks: GovernanceCheck[] }
  where GovernanceCheck = { name: string, status: "passed"|"warning"|"failed", detail: string }
```

#### Function 8: Submit Registration

```
CURRENT:   mockSubmitRegistration(store, logger)
REAL:      realSubmitRegistration(logger)
ENDPOINT:  POST /metaq-api/registration/submit
MUST RETURN:
  { success: boolean, trackingId: string, submittedAt: string,
    eta: string, catalogEntry: Record<string,unknown> }
```

#### Function 9: Get Automated Checks

```
CURRENT:   mockGetAutomatedChecks(store, logger)
REAL:      realGetAutomatedChecks(logger)
ENDPOINT:  GET /metaq-api/registration/checks
MUST RETURN:
  { status: "running"|"completed",
    checks: Check[] }
  where Check = { name: string, status: "passed"|"running"|"pending"|"warning"|"failed", score?: number, note?: string }
```

#### Function 10: Get Review Status

```
CURRENT:   mockGetReviewStatus(store, logger)
REAL:      realGetReviewStatus(logger)
ENDPOINT:  GET /metaq-api/registration/reviews
MUST RETURN:
  { reviews: Review[] }
  where Review = { name: string, status: "Pending"|"Waiting"|"Approved", assignedTo: string, sla: string }
```

### Where Each Function Is Called (So You Know What to Update)

```
FILE: src/hooks/handlers.ts
  Line ~120: handleAppInit       -> calls mockGetHealth, mockGetDraft
  Line ~23:  handleSaveAndContinue -> calls mockValidateStep, mockSaveDraft
  Line ~67:  handleSubmit        -> calls mockValidateStep, mockRunGovernanceChecks, mockSubmitRegistration

FILE: src/hooks/useAutoSave.ts
  Line ~27:  useAutoSave         -> calls mockSaveDraft

FILE: src/hooks/usePolling.ts
  Line ~26:  usePolling          -> calls mockGetAutomatedChecks, mockGetReviewStatus
```

### Step-by-Step Integration Plan

```
STEP 1: Create src/lib/realApi.ts
  - Copy the TYPE EXPORTS from mockApi.ts (Dataset, StepData, DraftState, etc.)
  - Write real fetch() functions with same return types
  - Remove `store` parameter from all functions
  - Remove `delay()` calls
  - Keep `logger` parameter (powers the API Log Panel)

STEP 2: Update 3 import statements
  FILE: src/hooks/handlers.ts
    CHANGE: import { mockSaveDraft, mockValidateStep, ... } from '../lib/mockApi'
    TO:     import { realSaveDraft, realValidateStep, ... } from '../lib/realApi'

  FILE: src/hooks/useAutoSave.ts
    CHANGE: import { mockSaveDraft } from '../lib/mockApi'
    TO:     import { realSaveDraft } from '../lib/realApi'

  FILE: src/hooks/usePolling.ts
    CHANGE: import { mockGetAutomatedChecks, mockGetReviewStatus } from '../lib/mockApi'
    TO:     import { realGetAutomatedChecks, realGetReviewStatus } from '../lib/realApi'

STEP 3: Update src/hooks/useAppState.ts
    CHANGE: import { initMockStore } from '../lib/mockApi'
    REMOVE: const [store] = useState(() => initMockStore())
    (You no longer need a local store — the server IS the store)
    (Pass a placeholder or remove store from handler calls)

STEP 4: Update function calls in handlers.ts
    CHANGE: mockGetHealth(store, logger)  ->  realGetHealth(logger)
    CHANGE: mockGetDraft(store, logger)   ->  realGetDraft(logger)
    CHANGE: mockSaveDraft(store, logger, stepKey, data)  ->  realSaveDraft(logger, stepKey, data)
    ... etc for all 10 functions

STEP 5: Set your API base URL
    Add to realApi.ts:
      const API_BASE = 'https://your-server.ubs.com';
    Or use environment variable:
      const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8080';

THAT'S IT. The UI, hooks, atoms, steps, post-submission — NOTHING changes.
```

### The 10 REST Endpoints Your Backend Must Implement

| Method | Endpoint                              | Purpose                    |
|--------|---------------------------------------|----------------------------|
| GET    | `/metaq-api/health`                   | Health check               |
| GET    | `/metaq-api/datasets`                 | List all datasets          |
| GET    | `/metaq-api/dataset/{title}`          | Filter datasets by title   |
| GET    | `/metaq-api/registration/draft`       | Load saved draft           |
| PUT    | `/metaq-api/registration/draft`       | Save step data             |
| POST   | `/metaq-api/registration/validate`    | Validate a step            |
| POST   | `/metaq-api/registration/governance`  | Run governance checks      |
| POST   | `/metaq-api/registration/submit`      | Submit registration        |
| GET    | `/metaq-api/registration/checks`      | Poll automated checks      |
| GET    | `/metaq-api/registration/reviews`     | Poll review status         |

### Why This Design Makes Integration Easy

```
MOCK MODE (current):
  Browser -> mockApi.ts -> in-memory JavaScript object

REAL MODE (after integration):
  Browser -> realApi.ts -> fetch() -> HTTPS -> Real Server -> Database

The UI layer (atoms, steps, post, sidebar) has ZERO knowledge of where data comes from.
The hooks layer just calls functions and reads the response.
ONLY the API layer changes.
```

---

## PART 3: DEMO TALKING POINTS

### Opening (30 seconds)
> "This is the WMA Data Product Registration platform. It provides a guided 10-step wizard for registering data products with full governance, validation, and automated review pipelines."

### During Form Filling (show steps 1-3 live, skip to 10)
> "Notice the API Activity Log at the bottom — every field change triggers an auto-save after 2 seconds. The system validates against UBS governance rules in real-time."

### At Submission
> "Watch the submission pipeline: first we validate attestations, then run 5 governance checks against the actual data we entered — PII detection, retention compliance, naming conventions, metadata completeness, and entitlement alignment. Only then does the registration submit."

### Post-Submission Dashboard
> "After submission, the system polls for automated check progress every 3 seconds. You can see checks advancing from pending to running to passed. Once automated checks complete, human reviewers are activated — the first reviewer status changes from Waiting to Pending."

### Architecture Question
> "The entire mock API layer is a single file. To integrate with a real MetaQ backend, we swap 10 functions in one file. The UI, validation, and orchestration layers don't change at all."
