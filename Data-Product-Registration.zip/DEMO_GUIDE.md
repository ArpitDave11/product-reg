# WMA Data Product Registration — Demo Guide

## Demo Scenario

**You are registering a new data product called "WMA Client Portfolio Summary"** — a composite data product that aggregates client portfolio holdings, valuations, and performance metrics for Wealth Management Advisors.

---

## Step 1: Product Identity

| Field | Sample Input |
|-------|-------------|
| **Product Name** | `WMA Client Portfolio Summary` |
| **Product Type** | `Composite Data Product` |
| **Business Domain** | `Portfolio` |
| **Short Description** | `Aggregated client portfolio holdings with real-time valuations and performance tracking` |
| **Long Description** | `This data product consolidates portfolio holdings from Core Banking and market valuations from Market Data systems. It provides advisors with a unified view of client positions, asset allocation, unrealized P&L, and benchmark-relative performance across all account types.` |
| **Business Purpose** | `Enable wealth advisors to deliver personalized investment reviews by providing a single source of truth for client portfolio analytics, reducing manual data reconciliation by 80%.` |
| **Key KPIs** | `AUM accuracy, portfolio refresh latency, advisor adoption rate` |
| **Consumer Personas** | `Wealth Advisor, Portfolio Manager, Compliance Officer` |
| **Source System** | `Core Banking` |

---

## Step 2: Ownership & Contacts

| Field | Sample Input |
|-------|-------------|
| **Owner** | `jane.smith@ubs.com` |
| **Backup Owner** | `michael.chen@ubs.com` |
| **IT Lead** | `raj.patel@ubs.com` |
| **Data Steward** | `lisa.wong@ubs.com` |
| **Distribution List** | `wma-portfolio-team@ubs.com` |
| **Support Hours** | `Business Hours (US)` |

---

## Step 3: Connect to Source & Entitlements

| Field | Sample Input |
|-------|-------------|
| **Source URL** | `https://core-banking.internal.ubs.com/api/v2` |
| **Environment** | `UAT` |
| **Storage Location** | `adbfs://wma-portfolio@datalake-prod` |
| **CID Classification** | `Amber` |
| **Input Datasets** | `rcat0100, rcat0200, rcat0300` |

---

## Step 4: KDE Semantics (Optional)

| Field | Sample Input |
|-------|-------------|
| **Business Definitions** | `Client Portfolio: A collection of financial instruments held by a client across one or more accounts. AUM: Assets Under Management — total market value of all managed positions.` |
| **KDE Mapping** | `portfolio_id → KDE.Portfolio.Identifier, client_id → KDE.Client.MasterID, market_value → KDE.Valuation.CurrentMarketValue` |
| **Ontology Alignment** | `WMA-ONT-2024-Portfolio` |
| **Glossary Terms** | `AUM, NAV, Unrealized P&L, Asset Allocation, Benchmark` |

---

## Step 5: Scope & Data Quality

| Field | Sample Input |
|-------|-------------|
| **Threshold** | `95` |
| **Coverage** | `99` |
| **Completeness** | `98` |
| **Timeliness** | `Daily` |
| **Accuracy** | `Portfolio valuations must match source system within 0.01% tolerance. Position quantities must be exact. Performance calculations follow GIPS standards.` |

---

## Step 6: Data Contract

| Field | Sample Input |
|-------|-------------|
| **Update Frequency** | `Daily` |
| **Access Modes** | `API` |
| **SLA Target** | `99.5% uptime, data refresh by 6:00 AM EST` |
| **Versioning Policy** | `Semantic` |
| **Deprecation Policy** | `Minimum 90-day notice before major version deprecation. Minor versions supported for 6 months. Consumers notified via distribution list and catalog alerts.` |

---

## Step 7: Lineage (Optional)

| Field | Sample Input |
|-------|-------------|
| **Upstream Products** | `Core Banking Positions (rcat0100), Market Data Valuations (rcat0200), Client Master (rcat0300)` |
| **Lineage Narrative** | `Raw positions are extracted nightly from Core Banking → enriched with real-time market prices from Market Data feed → joined with Client Master for advisor mapping → aggregated by portfolio and asset class → quality checks applied → published to consumption layer.` |
| **Transformations** | `1. Position deduplication across account types. 2. FX conversion to base currency (USD). 3. Market value calculation (quantity × price). 4. Performance calculation vs benchmark (S&P 500, custom). 5. Asset class classification using internal taxonomy.` |
| **Data Flow Diagram** | `https://confluence.internal/wma/portfolio-lineage-v2` |

---

## Step 8: Sensitivity & Policy

| Field | Sample Input |
|-------|-------------|
| **Classification** | `Confidential` |
| **Retention Requirement** | `7 years` |
| **Permitted Uses** | `Client portfolio reporting, investment advisory, regulatory reporting (MiFID II, SEC). Not permitted for marketing or third-party distribution without explicit client consent.` |
| **Restricted Regions** | `EU, APAC` |
| **Encryption Requirement** | `Both` |

---

## Step 9: AI Readiness (Optional)

| Field | Sample Input |
|-------|-------------|
| **AI Ready Flag** | `✓ checked` |
| **AI Use Cases** | `1. Next-best-action recommendations for advisors. 2. Anomaly detection on portfolio drift. 3. Client churn prediction based on portfolio activity patterns.` |
| **ML Model Compatibility** | `Structured only` |
| **Feature Store** | `Planned` |
| **Bias Assessment** | `Portfolio data inherently skews toward high-net-worth clients. Models trained on this data may underperform for emerging-affluent segment. Mitigation: stratified sampling and segment-specific model evaluation.` |

---

## Step 10: Attestations & Submit

| Field | Sample Input |
|-------|-------------|
| **Accuracy Attestation** | `✓ checked` |
| **Ownership Attestation** | `✓ checked` |
| **Policy Attestation** | `✓ checked` |
| **Additional Notes** | `This is a UAT registration for demo purposes. Production registration will follow after the pilot with 5 advisor teams in Q2. Please prioritize DWO Steward review.` |

---

## API Interaction Flow

### Phase A: Form Filling (Steps 1–10)

```
┌─────────────────────────────────────────────────────────┐
│  App Loads                                              │
│                                                         │
│  1. GET /metaq-api/health         → { status: "ok" }   │
│  2. GET /metaq-api/datasets       → 5 seed datasets    │
│  3. GET /metaq-api/registration/draft → existing draft? │
│     └─ If draft exists → restore form data & step       │
│     └─ If no draft → start fresh at Step 1              │
└─────────────────────────────────────────────────────────┘
```

### Phase B: Save & Continue (on each step)

Every time you click **"Save & Continue"**, three API calls fire:

```
User clicks "Save & Continue" on Step 3
         │
         ▼
┌─ PUT /metaq-api/registration/draft ──────────────────┐
│  Body: { stepKey: "step3", stepData: { ... } }       │
│  Response: { success: true, timestamp: "..." }       │
│  → Toast: "Draft saved"                              │
└──────────────────────────────────────────────────────┘
         │
         ▼
┌─ POST /metaq-api/registration/validate ──────────────┐
│  Body: { stepKey: "step3", stepData: { ... } }       │
│  Response: { valid: true, errors: [], warnings: [] } │
│  → Red errors block progress, yellow warnings don't  │
└──────────────────────────────────────────────────────┘
         │
         ▼
  If valid → advance to Step 4
  If errors → stay on Step 3, show error messages
```

### Phase C: Auto-Save (background)

```
Every 30 seconds while filling the form:
  → PUT /metaq-api/registration/draft  (silent save)
  → Small toast: "Auto-saved"
```

### Phase D: Submission (Step 10)

```
User checks all 3 attestations, clicks "Submit"
         │
         ▼
┌─ POST /metaq-api/registration/governance ────────────┐
│  Runs 5 governance checks:                           │
│   ✓ PII detection                                    │
│   ✓ Retention compliance                             │
│   ⚠ Naming conventions (warns if name has spaces)    │
│   ✓ Metadata completeness                            │
│   ✓ Entitlement alignment                            │
│  Response: { overallStatus: "passed_with_warnings" } │
└──────────────────────────────────────────────────────┘
         │
         ▼
┌─ POST /metaq-api/registration/submit ────────────────┐
│  Takes ~2 seconds (simulating real submission)       │
│  Response:                                           │
│   { success: true,                                   │
│     trackingId: "REG-1739...",                       │
│     submittedAt: "2026-02-13T...",                   │
│     eta: "2026-02-20T...",                           │
│     catalogEntry: { p_dataset_data: {...} } }        │
│                                                      │
│  Also calls: POST /metaq-api/dataset                 │
│  → Adds new dataset to the catalog                   │
└──────────────────────────────────────────────────────┘
         │
         ▼
  Phase switches from "form" → "submitted"
  Shows: Confirmation Card with tracking ID
```

### Phase E: Post-Submission (Automated Checks)

```
After submission, polling begins every 3 seconds:

  GET /metaq-api/registration/checks
         │
  Poll 1 │  Check 1: "Data product qualification"  → running
         │  Check 2: "Ontology score"               → pending
         │  Check 3: "Upstream source certification" → pending
         │  Check 4: "Entitlement source validation" → pending
         │
  Poll 2 │  Check 1: ✓ passed
         │  Check 2: "Ontology score"               → running
         │  Check 3: pending
         │  Check 4: pending
         │
  Poll 3 │  Check 1: ✓ passed
         │  Check 2: ✓ passed (score: 87)
         │  Check 3: "Upstream source certification" → running
         │  Check 4: pending
         │
  Poll 4 │  Check 1: ✓ passed
         │  Check 2: ✓ passed (score: 87)
         │  Check 3: ✓ passed
         │  Check 4: "Entitlement source validation" → running
         │
  Poll 5 │  All checks complete:
         │  Check 1: ✓ passed
         │  Check 2: ✓ passed (score: 87)
         │  Check 3: ✓ passed
         │  Check 4: ⚠ warning — "Review recommended"
         │
         │  status: "completed" → polling stops
```

### Phase F: Review Pipeline

```
Once automated checks finish, review polling starts:

  GET /metaq-api/registration/reviews

  ┌──────────────────────────────┬───────────┬──────────────────────┐
  │ Reviewer                     │ Status    │ Assigned To          │
  ├──────────────────────────────┼───────────┼──────────────────────┤
  │ Upstream Data Owners         │ Pending   │ upstream-team@ubs.com│
  │ DWO Steward                  │ Waiting   │ steward@ubs.com      │
  │ KDE Reviewer                 │ Waiting   │ kde-team@ubs.com     │
  └──────────────────────────────┴───────────┴──────────────────────┘

  Reviews are sequential — each approves before the next activates.
  SLA: 2-3 days per reviewer.
```

---

## Demo Tips

1. **Start with the API Log panel open** (bottom of screen) — it shows every API call in real-time, great for showing the audience what's happening behind the scenes.

2. **Deliberately leave a required field empty** (e.g., skip Product Name in Step 1) — this triggers validation errors and shows the error handling UX.

3. **Watch the auto-save** — after 30 seconds of inactivity, a save fires automatically. Mention this for resilience.

4. **On Step 10**, the governance check will show a **warning** for the product name having spaces ("WMA Client Portfolio Summary"). This is expected and demonstrates the warning vs. error distinction.

5. **After submission**, the automated checks animate one-by-one (each poll advances one check). This takes ~15-20 seconds total — great visual for the audience.

6. **Refresh the page mid-form** to demonstrate draft recovery — the app will reload your saved progress.

---

## Quick-Start: Copy-Paste Values

For speed, here are the critical required fields only:

```
Step 1:  WMA Client Portfolio Summary | Composite Data Product | Portfolio | Aggregated client portfolio holdings
Step 2:  jane.smith@ubs.com
Step 3:  UAT | Amber
Step 5:  95
Step 6:  Daily
Step 8:  Confidential
Step 10: ✓ ✓ ✓ (all three checkboxes)
```

Everything else is optional or has warnings only (won't block submission).
