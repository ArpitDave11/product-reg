// =============================================================================
// Phase 3 — UI Atoms — Structural Tests
// Run: npx tsx tests/components/atoms.test.ts
//
// These tests verify module exports, component types, and prop contracts.
// Visual testing is done via the dev server at http://localhost:3000.
// =============================================================================

import { Toast, ApiLogPanel, Field, StepperItem, Badge, StatusPill, CardWrapper, LoadingOverlay } from '../../src/components/atoms';

let passed = 0;
let failed = 0;

function assert(label: string, condition: boolean) {
  if (condition) {
    console.log(`  \u2713 ${label}`);
    passed++;
  } else {
    console.error(`  \u2717 ${label}`);
    failed++;
  }
}

// -----------------------------------------------------------------------------
// U-01: Toast
// -----------------------------------------------------------------------------

function testToast() {
  console.log('\n=== U-01: Toast ===\n');
  assert('Toast is exported', typeof Toast === 'function');
  assert('Toast is a function component', Toast.length >= 0);
}

// -----------------------------------------------------------------------------
// U-02: ApiLogPanel
// -----------------------------------------------------------------------------

function testApiLogPanel() {
  console.log('\n=== U-02: ApiLogPanel ===\n');
  assert('ApiLogPanel is exported', typeof ApiLogPanel === 'function');
  assert('ApiLogPanel is a function component', ApiLogPanel.length >= 0);
}

// -----------------------------------------------------------------------------
// U-03: Field
// -----------------------------------------------------------------------------

function testField() {
  console.log('\n=== U-03: Field ===\n');
  assert('Field is exported', typeof Field === 'function');
  assert('Field is a function component', Field.length >= 0);
}

// -----------------------------------------------------------------------------
// U-04: StepperItem
// -----------------------------------------------------------------------------

function testStepperItem() {
  console.log('\n=== U-04: StepperItem ===\n');
  assert('StepperItem is exported', typeof StepperItem === 'function');
  assert('StepperItem is a function component', StepperItem.length >= 0);
}

// -----------------------------------------------------------------------------
// U-05: Badge
// -----------------------------------------------------------------------------

function testBadge() {
  console.log('\n=== U-05: Badge ===\n');
  assert('Badge is exported', typeof Badge === 'function');
  assert('Badge is a function component', Badge.length >= 0);
}

// -----------------------------------------------------------------------------
// U-06: StatusPill
// -----------------------------------------------------------------------------

function testStatusPill() {
  console.log('\n=== U-06: StatusPill ===\n');
  assert('StatusPill is exported', typeof StatusPill === 'function');
  assert('StatusPill is a function component', StatusPill.length >= 0);
}

// -----------------------------------------------------------------------------
// U-07: CardWrapper
// -----------------------------------------------------------------------------

function testCardWrapper() {
  console.log('\n=== U-07: CardWrapper ===\n');
  assert('CardWrapper is exported', typeof CardWrapper === 'function');
  assert('CardWrapper is a function component', CardWrapper.length >= 0);
}

// -----------------------------------------------------------------------------
// U-08: LoadingOverlay
// -----------------------------------------------------------------------------

function testLoadingOverlay() {
  console.log('\n=== U-08: LoadingOverlay ===\n');
  assert('LoadingOverlay is exported', typeof LoadingOverlay === 'function');
  assert('LoadingOverlay is a function component', LoadingOverlay.length >= 0);
}

// -----------------------------------------------------------------------------
// Main
// -----------------------------------------------------------------------------

function main() {
  testToast();
  testApiLogPanel();
  testField();
  testStepperItem();
  testBadge();
  testStatusPill();
  testCardWrapper();
  testLoadingOverlay();

  console.log(`\n=============================`);
  console.log(`RESULTS: ${passed} passed, ${failed} failed`);
  console.log(`=============================\n`);

  if (failed > 0) process.exit(1);
}

main();
