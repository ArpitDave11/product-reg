// =============================================================================
// Phase 4 — Step Forms — Structural Tests
// Run: npx tsx tests/components/steps.test.ts
//
// Verifies module exports, component types, and prop contracts.
// Visual testing is done via the dev server at http://localhost:3000.
// =============================================================================

import {
  Step1ProductIdentity,
  Step2Ownership,
  Step3Connect,
  Step4KdeSemantics,
  Step5ScopeDq,
  Step6DataContract,
  Step7Lineage,
  Step8Sensitivity,
  Step9AiReadiness,
  Step10Submit,
} from '../../src/components/steps';

import type { StepFormProps } from '../../src/components/steps';

let passed = 0;
let failed = 0;

function assert(label: string, condition: boolean) {
  if (condition) {
    console.log(`  \u2713 ${label}`);
    passed++;
  } else {
    console.error(`  \u2717 ${label}`);
    failed++;
  }
}

// -----------------------------------------------------------------------------
// S-01: Step1ProductIdentity
// -----------------------------------------------------------------------------

function testStep1() {
  console.log('\n=== S-01: Step1ProductIdentity ===\n');
  assert('Step1ProductIdentity is exported', typeof Step1ProductIdentity === 'function');
  assert('Step1ProductIdentity is a function component', Step1ProductIdentity.length >= 0);
}

// -----------------------------------------------------------------------------
// S-02: Step2Ownership
// -----------------------------------------------------------------------------

function testStep2() {
  console.log('\n=== S-02: Step2Ownership ===\n');
  assert('Step2Ownership is exported', typeof Step2Ownership === 'function');
  assert('Step2Ownership is a function component', Step2Ownership.length >= 0);
}

// -----------------------------------------------------------------------------
// S-03: Step3Connect
// -----------------------------------------------------------------------------

function testStep3() {
  console.log('\n=== S-03: Step3Connect ===\n');
  assert('Step3Connect is exported', typeof Step3Connect === 'function');
  assert('Step3Connect is a function component', Step3Connect.length >= 0);
}

// -----------------------------------------------------------------------------
// S-04: Step4KdeSemantics
// -----------------------------------------------------------------------------

function testStep4() {
  console.log('\n=== S-04: Step4KdeSemantics ===\n');
  assert('Step4KdeSemantics is exported', typeof Step4KdeSemantics === 'function');
  assert('Step4KdeSemantics is a function component', Step4KdeSemantics.length >= 0);
}

// -----------------------------------------------------------------------------
// S-05: Step5ScopeDq
// -----------------------------------------------------------------------------

function testStep5() {
  console.log('\n=== S-05: Step5ScopeDq ===\n');
  assert('Step5ScopeDq is exported', typeof Step5ScopeDq === 'function');
  assert('Step5ScopeDq is a function component', Step5ScopeDq.length >= 0);
}

// -----------------------------------------------------------------------------
// S-06: Step6DataContract
// -----------------------------------------------------------------------------

function testStep6() {
  console.log('\n=== S-06: Step6DataContract ===\n');
  assert('Step6DataContract is exported', typeof Step6DataContract === 'function');
  assert('Step6DataContract is a function component', Step6DataContract.length >= 0);
}

// -----------------------------------------------------------------------------
// S-07: Step7Lineage
// -----------------------------------------------------------------------------

function testStep7() {
  console.log('\n=== S-07: Step7Lineage ===\n');
  assert('Step7Lineage is exported', typeof Step7Lineage === 'function');
  assert('Step7Lineage is a function component', Step7Lineage.length >= 0);
}

// -----------------------------------------------------------------------------
// S-08: Step8Sensitivity
// -----------------------------------------------------------------------------

function testStep8() {
  console.log('\n=== S-08: Step8Sensitivity ===\n');
  assert('Step8Sensitivity is exported', typeof Step8Sensitivity === 'function');
  assert('Step8Sensitivity is a function component', Step8Sensitivity.length >= 0);
}

// -----------------------------------------------------------------------------
// S-09: Step9AiReadiness
// -----------------------------------------------------------------------------

function testStep9() {
  console.log('\n=== S-09: Step9AiReadiness ===\n');
  assert('Step9AiReadiness is exported', typeof Step9AiReadiness === 'function');
  assert('Step9AiReadiness is a function component', Step9AiReadiness.length >= 0);
}

// -----------------------------------------------------------------------------
// S-10: Step10Submit
// -----------------------------------------------------------------------------

function testStep10() {
  console.log('\n=== S-10: Step10Submit ===\n');
  assert('Step10Submit is exported', typeof Step10Submit === 'function');
  assert('Step10Submit is a function component', Step10Submit.length >= 0);
}

// -----------------------------------------------------------------------------
// Type contract check
// -----------------------------------------------------------------------------

function testTypeContract() {
  console.log('\n=== StepFormProps type contract ===\n');

  // Verify the type exists by constructing a conforming object
  const props: StepFormProps = {
    data: { productName: 'Test' },
    onUpdate: (_field: string, _value: string | boolean) => {},
    errors: {},
    warnings: {},
  };

  assert('StepFormProps data is object', typeof props.data === 'object');
  assert('StepFormProps onUpdate is function', typeof props.onUpdate === 'function');
  assert('StepFormProps errors is object', typeof props.errors === 'object');
  assert('StepFormProps warnings is object', typeof props.warnings === 'object');
}

// -----------------------------------------------------------------------------
// Main
// -----------------------------------------------------------------------------

function main() {
  testStep1();
  testStep2();
  testStep3();
  testStep4();
  testStep5();
  testStep6();
  testStep7();
  testStep8();
  testStep9();
  testStep10();
  testTypeContract();

  console.log(`\n=============================`);
  console.log(`RESULTS: ${passed} passed, ${failed} failed`);
  console.log(`=============================\n`);

  if (failed > 0) process.exit(1);
}

main();
