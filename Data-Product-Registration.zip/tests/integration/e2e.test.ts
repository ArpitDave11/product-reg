// =============================================================================
// Phase 7 — Integration / E2E Test
// Run: npx tsx tests/integration/e2e.test.ts
//
// Simulates a complete registration lifecycle using the mock API:
// init store → save drafts → validate → governance → submit → checks → reviews.
// =============================================================================

import { initMockStore, mockGetHealth, mockGetDatasets, mockGetDatasetByTitle, mockGetDraft,
  mockSaveDraft, mockValidateStep, mockRunGovernanceChecks, mockSubmitRegistration,
  mockGetAutomatedChecks, mockGetReviewStatus } from '../../src/lib/mockApi';
import type { ApiLogEntry } from '../../src/lib/foundation';

let passed = 0;
let failed = 0;
const logs: ApiLogEntry[] = [];
const logger = (entry: ApiLogEntry) => logs.push(entry);

function assert(label: string, condition: boolean) {
  if (condition) {
    console.log(`  \u2713 ${label}`);
    passed++;
  } else {
    console.error(`  \u2717 ${label}`);
    failed++;
  }
}

// -----------------------------------------------------------------------------
// I-01: Full lifecycle test
// -----------------------------------------------------------------------------

async function testFullLifecycle() {
  console.log('\n=== I-01: Full Registration Lifecycle ===\n');

  // 1. Init
  const store = initMockStore();
  assert('Store initialized', store.datasets.length === 5);
  assert('No draft initially', store.draft === null);

  // 2. Health check
  const health = await mockGetHealth(store, logger);
  assert('Health check returns ok', health.status === 'ok');

  // 3. Load datasets
  const allDatasets = await mockGetDatasets(store, logger);
  assert('All datasets loaded', allDatasets.count === 5);

  // 4. Filter by title
  const filtered = await mockGetDatasetByTitle(store, logger, 'rcat0200');
  assert('Filtered datasets by title', filtered.count === 2);

  // 5. Check draft (empty)
  const emptyDraft = await mockGetDraft(store, logger);
  assert('No draft exists yet', emptyDraft.exists === false);

  // 6. Save Step 1
  const step1Data = { productName: 'WMA Account', productType: 'Composite Data Product',
    businessDomain: 'Account', shortDescription: 'Account data product',
    longDescription: 'A comprehensive account data product for WMA', businessPurpose: 'Client analytics' };
  const save1 = await mockSaveDraft(store, logger, 'step1', step1Data);
  assert('Step 1 saved successfully', save1.success === true);

  // 7. Validate Step 1
  const val1 = await mockValidateStep(store, logger, 'step1', step1Data);
  assert('Step 1 valid', val1.valid === true);
  assert('Step 1 has no errors', val1.errors.length === 0);

  // 8. Save Step 2
  const step2Data = { owner: 'owner@ubs.com', backupOwner: 'backup@ubs.com', itLead: 'it@ubs.com', dataSteward: 'steward@ubs.com' };
  const save2 = await mockSaveDraft(store, logger, 'step2', step2Data);
  assert('Step 2 saved successfully', save2.success === true);

  // 9. Save Step 3
  const step3Data = { environment: 'PROD', cidClassification: 'Green', sourceUrl: 'https://source.ubs.com' };
  const save3 = await mockSaveDraft(store, logger, 'step3', step3Data);
  assert('Step 3 saved successfully', save3.success === true);

  // 10. Save Step 8 (needed for governance)
  const step8Data = { classification: 'Internal', retentionReq: '7 years' };
  const save8 = await mockSaveDraft(store, logger, 'step8', step8Data);
  assert('Step 8 saved successfully', save8.success === true);

  // 11. Check draft (should exist now)
  const loadedDraft = await mockGetDraft(store, logger);
  assert('Draft exists after saves', loadedDraft.exists === true);
  assert('Draft has step1 data', loadedDraft.steps?.step1 !== undefined);
  assert('Draft tracks current step', loadedDraft.currentStep >= 1);

  // 12. Save Step 10
  const step10Data = { accuracyAttest: true, ownershipAttest: true, policyAttest: true };
  const save10 = await mockSaveDraft(store, logger, 'step10', step10Data);
  assert('Step 10 saved successfully', save10.success === true);

  // 13. Validate Step 10
  const val10 = await mockValidateStep(store, logger, 'step10', step10Data);
  assert('Step 10 valid', val10.valid === true);

  // 14. Governance checks
  const gov = await mockRunGovernanceChecks(store, logger);
  assert('Governance checks completed', gov.checks.length === 5);
  assert('Governance passed or passed with warnings', gov.overallStatus === 'passed' || gov.overallStatus === 'passed_with_warnings');

  // 15. Submit
  const sub = await mockSubmitRegistration(store, logger);
  assert('Submission successful', sub.success === true);
  assert('Tracking ID generated', sub.trackingId.startsWith('WMA-'));
  assert('Catalog entry created', sub.catalogEntry.p_dataset_data !== undefined);

  // 16. Poll automated checks (4 ticks to complete)
  let checksResult = await mockGetAutomatedChecks(store, logger);
  assert('Checks started (tick 1)', checksResult.status === 'running');

  checksResult = await mockGetAutomatedChecks(store, logger);
  assert('Checks progressing (tick 2)', checksResult.status === 'running');

  checksResult = await mockGetAutomatedChecks(store, logger);
  assert('Checks progressing (tick 3)', checksResult.status === 'running');

  checksResult = await mockGetAutomatedChecks(store, logger);
  assert('Checks completed (tick 4)', checksResult.status === 'completed');

  // 17. Review status
  const reviewResult = await mockGetReviewStatus(store, logger);
  assert('Reviews available', reviewResult.reviews.length === 3);
  assert('First reviewer activated', reviewResult.reviews[0].status === 'Pending');

  // 18. API log accumulated
  assert('API log captured calls', logs.length > 0);
  assert('Log entries have IDs', logs.every(l => l.id.startsWith('log-')));
}

// -----------------------------------------------------------------------------
// I-02: Validation failure test
// -----------------------------------------------------------------------------

async function testValidationFailure() {
  console.log('\n=== I-02: Validation Failure Path ===\n');

  const store = initMockStore();

  // Empty step 1 should fail
  const val = await mockValidateStep(store, logger, 'step1', {});
  assert('Empty step 1 fails validation', val.valid === false);
  assert('Missing fields reported as errors', val.errors.length >= 4);
  assert('Warnings for optional fields', val.warnings.length >= 1);

  // Invalid email
  const valEmail = await mockValidateStep(store, logger, 'step2', { owner: 'not-an-email' });
  assert('Invalid email detected', valEmail.valid === false);
  assert('Email error message', valEmail.errors.some(e => e.message.includes('email')));
}

// -----------------------------------------------------------------------------
// I-03: Governance failure test
// -----------------------------------------------------------------------------

async function testGovernanceFailure() {
  console.log('\n=== I-03: Governance Failure Path ===\n');

  const store = initMockStore();

  // No draft data → governance should fail
  const gov = await mockRunGovernanceChecks(store, logger);
  assert('Governance fails without data', gov.overallStatus === 'failed');
  assert('Failed checks identified', gov.checks.some(c => c.status === 'failed'));
}

// -----------------------------------------------------------------------------
// I-04: Module import verification
// -----------------------------------------------------------------------------

async function testModuleImports() {
  console.log('\n=== I-04: Module Imports ===\n');

  // Verify all barrel exports work
  const atoms = await import('../../src/components/atoms');
  assert('Atoms barrel export works', typeof atoms.Toast === 'function');
  assert('All 8 atoms accessible', typeof atoms.LoadingOverlay === 'function');

  const steps = await import('../../src/components/steps');
  assert('Steps barrel export works', typeof steps.Step1ProductIdentity === 'function');
  assert('All 10 steps accessible', typeof steps.Step10Submit === 'function');

  const post = await import('../../src/components/post');
  assert('Post barrel export works', typeof post.PostSubmissionView === 'function');
  assert('All 5 post components accessible', typeof post.CertificationPipeline === 'function');

  const hooks = await import('../../src/hooks');
  assert('Hooks barrel export works', typeof hooks.useAppState === 'function');
  assert('All handlers accessible', typeof hooks.handleAppInit === 'function');
}

// -----------------------------------------------------------------------------
// Main
// -----------------------------------------------------------------------------

async function main() {
  await testFullLifecycle();
  await testValidationFailure();
  await testGovernanceFailure();
  await testModuleImports();

  console.log(`\n=============================`);
  console.log(`RESULTS: ${passed} passed, ${failed} failed`);
  console.log(`=============================\n`);

  if (failed > 0) process.exit(1);
}

main();
