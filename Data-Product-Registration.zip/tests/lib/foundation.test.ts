// =============================================================================
// Foundation Layer — Tests
// Run: npx tsx tests/lib/foundation.test.ts
// =============================================================================

import { delay, generateId, getTimestamp, formatTime, deepClone, validateEmail, validateRequired, createApiLogEntry } from '../../src/lib/foundation';

let passed = 0;
let failed = 0;

function assert(label: string, condition: boolean) {
  if (condition) {
    console.log(`  ✓ ${label}`);
    passed++;
  } else {
    console.error(`  ✗ ${label}`);
    failed++;
  }
}

async function testDelay() {
  console.log('\n=== F-01: delay(ms) ===\n');

  // Test 1: Normal delay resolves
  {
    const start = Date.now();
    await delay(100);
    const elapsed = Date.now() - start;
    assert('delay(100) resolves after ~100ms', elapsed >= 90 && elapsed < 200);
  }

  // Test 2: delay(0) resolves immediately (next tick)
  {
    const start = Date.now();
    await delay(0);
    const elapsed = Date.now() - start;
    assert('delay(0) resolves immediately', elapsed < 50);
  }

  // Test 3: Negative value treated as 0
  {
    const start = Date.now();
    await delay(-100);
    const elapsed = Date.now() - start;
    assert('delay(-100) treated as 0, resolves immediately', elapsed < 50);
  }

  // Test 4: NaN treated as 0
  {
    const start = Date.now();
    await delay(NaN);
    const elapsed = Date.now() - start;
    assert('delay(NaN) treated as 0, resolves immediately', elapsed < 50);
  }

  // Test 5: Infinity treated as 0
  {
    const start = Date.now();
    await delay(Infinity);
    const elapsed = Date.now() - start;
    assert('delay(Infinity) treated as 0, resolves immediately', elapsed < 50);
  }

  // Test 6: Returns a Promise
  {
    const result = delay(10);
    assert('delay() returns a Promise', result instanceof Promise);
    await result;
  }

  // Test 7: Resolves to undefined
  {
    const result = await delay(10);
    assert('delay() resolves to undefined', result === undefined);
  }
}

function testGenerateId() {
  console.log('\n=== F-02: generateId(prefix) ===\n');

  // Test 1: Correct format with prefix
  {
    const id = generateId('WMA');
    const pattern = /^WMA-\d{4}-\d{4}$/;
    assert('generateId("WMA") matches format "WMA-YYYY-NNNN"', pattern.test(id));
  }

  // Test 2: Contains current year
  {
    const id = generateId('draft');
    const year = new Date().getFullYear().toString();
    assert(`generateId("draft") contains current year ${year}`, id.includes(year));
  }

  // Test 3: Different prefix works
  {
    const id = generateId('corr');
    assert('generateId("corr") starts with "corr-"', id.startsWith('corr-'));
  }

  // Test 4: Empty prefix still produces valid format
  {
    const id = generateId('');
    const pattern = /^-\d{4}-\d{4}$/;
    assert('generateId("") produces "-YYYY-NNNN"', pattern.test(id));
  }

  // Test 5: Two calls produce different IDs (high probability)
  {
    const ids = new Set(Array.from({ length: 20 }, () => generateId('test')));
    assert('20 consecutive calls produce mostly unique IDs', ids.size > 10);
  }

  // Test 6: Returns a string
  {
    const id = generateId('WMA');
    assert('generateId() returns a string', typeof id === 'string');
  }

  // Test 7: Random part is exactly 4 digits
  {
    const id = generateId('X');
    const parts = id.split('-');
    assert('Random part is exactly 4 digits', parts[2].length === 4 && /^\d{4}$/.test(parts[2]));
  }
}

function testGetTimestamp() {
  console.log('\n=== F-03: getTimestamp() ===\n');

  // Test 1: Returns a string
  {
    const ts = getTimestamp();
    assert('getTimestamp() returns a string', typeof ts === 'string');
  }

  // Test 2: Valid ISO 8601 format
  {
    const ts = getTimestamp();
    const parsed = new Date(ts);
    assert('getTimestamp() returns valid ISO 8601', !isNaN(parsed.getTime()));
  }

  // Test 3: Ends with Z (UTC)
  {
    const ts = getTimestamp();
    assert('getTimestamp() ends with "Z" (UTC)', ts.endsWith('Z'));
  }

  // Test 4: Contains current year
  {
    const ts = getTimestamp();
    const year = new Date().getFullYear().toString();
    assert(`getTimestamp() contains current year ${year}`, ts.startsWith(year));
  }

  // Test 5: Is close to "now"
  {
    const before = Date.now();
    const ts = getTimestamp();
    const after = Date.now();
    const tsMs = new Date(ts).getTime();
    assert('getTimestamp() is within 1s of now', tsMs >= before - 1000 && tsMs <= after + 1000);
  }
}

function testFormatTime() {
  console.log('\n=== F-04: formatTime(date) ===\n');

  // Test 1: ISO string input
  {
    const result = formatTime('2026-02-12T14:30:05Z');
    assert('formatTime("2026-02-12T14:30:05Z") → "14:30:05"', result === '14:30:05');
  }

  // Test 2: Date object input
  {
    const d = new Date('2026-02-12T09:05:01Z');
    const result = formatTime(d);
    assert('formatTime(Date) → "09:05:01"', result === '09:05:01');
  }

  // Test 3: Midnight
  {
    const result = formatTime('2026-01-01T00:00:00Z');
    assert('formatTime(midnight) → "00:00:00"', result === '00:00:00');
  }

  // Test 4: End of day
  {
    const result = formatTime('2026-12-31T23:59:59Z');
    assert('formatTime(23:59:59) → "23:59:59"', result === '23:59:59');
  }

  // Test 5: null returns fallback
  {
    const result = formatTime(null);
    assert('formatTime(null) → "00:00:00"', result === '00:00:00');
  }

  // Test 6: undefined returns fallback
  {
    const result = formatTime(undefined);
    assert('formatTime(undefined) → "00:00:00"', result === '00:00:00');
  }

  // Test 7: Invalid string returns fallback
  {
    const result = formatTime('not-a-date');
    assert('formatTime("not-a-date") → "00:00:00"', result === '00:00:00');
  }

  // Test 8: Returns a string
  {
    const result = formatTime(new Date());
    assert('formatTime() returns a string', typeof result === 'string');
  }

  // Test 9: Format is HH:MM:SS (8 chars, 2 colons)
  {
    const result = formatTime('2026-02-12T07:08:09Z');
    assert('Format is exactly HH:MM:SS', /^\d{2}:\d{2}:\d{2}$/.test(result));
  }
}

function testDeepClone() {
  console.log('\n=== F-05: deepClone(obj) ===\n');

  // Test 1: Nested object — no shared references
  {
    const original = { a: { b: 1 } };
    const copy = deepClone(original);
    copy.a.b = 2;
    assert('Mutating copy does not affect original', original.a.b === 1);
  }

  // Test 2: Arrays are deep-copied
  {
    const original = { items: [1, 2, { x: 3 }] };
    const copy = deepClone(original);
    (copy.items[2] as any).x = 99;
    assert('Nested array objects are independent', (original.items[2] as any).x === 3);
  }

  // Test 3: null returns null
  {
    const result = deepClone(null);
    assert('deepClone(null) → null', result === null);
  }

  // Test 4: undefined returns undefined
  {
    const result = deepClone(undefined);
    assert('deepClone(undefined) → undefined', result === undefined);
  }

  // Test 5: Primitives pass through
  {
    assert('deepClone(42) → 42', deepClone(42) === 42);
    assert('deepClone("hello") → "hello"', deepClone('hello') === 'hello');
    assert('deepClone(true) → true', deepClone(true) === true);
  }

  // Test 6: Empty object
  {
    const copy = deepClone({});
    assert('deepClone({}) produces empty object', JSON.stringify(copy) === '{}');
  }

  // Test 7: Empty array
  {
    const copy = deepClone([]);
    assert('deepClone([]) produces empty array', Array.isArray(copy) && copy.length === 0);
  }

  // Test 8: Deep equality
  {
    const original = { a: 1, b: { c: [2, 3], d: 'test' } };
    const copy = deepClone(original);
    assert('Deep clone is structurally equal', JSON.stringify(copy) === JSON.stringify(original));
    assert('Deep clone is not the same reference', copy !== original);
  }
}

function testValidateEmail() {
  console.log('\n=== F-06: validateEmail(value) ===\n');

  // Valid emails
  assert('validateEmail("user@ubs.com") → true', validateEmail('user@ubs.com') === true);
  assert('validateEmail("a@b.co") → true', validateEmail('a@b.co') === true);
  assert('validateEmail("first.last@domain.org") → true', validateEmail('first.last@domain.org') === true);

  // Invalid emails
  assert('validateEmail("") → false', validateEmail('') === false);
  assert('validateEmail(null) → false', validateEmail(null) === false);
  assert('validateEmail(undefined) → false', validateEmail(undefined) === false);
  assert('validateEmail("user@ubs") → false (no dot after @)', validateEmail('user@ubs') === false);
  assert('validateEmail("@ubs.com") → false (nothing before @)', validateEmail('@ubs.com') === false);
  assert('validateEmail("user@.com") → false (nothing between @ and .)', validateEmail('user@.com') === false);
  assert('validateEmail("userubs.com") → false (no @)', validateEmail('userubs.com') === false);
  assert('validateEmail("user@@ubs.com") → false (double @)', validateEmail('user@@ubs.com') === false);
  assert('validateEmail("   ") → false (whitespace only)', validateEmail('   ') === false);

  // Returns boolean
  assert('validateEmail() returns a boolean', typeof validateEmail('test@test.com') === 'boolean');
}

function testValidateRequired() {
  console.log('\n=== F-07: validateRequired(value) ===\n');

  // Strings
  assert('validateRequired("hello") → true', validateRequired('hello') === true);
  assert('validateRequired("") → false', validateRequired('') === false);
  assert('validateRequired("   ") → false (whitespace only)', validateRequired('   ') === false);
  assert('validateRequired(" a ") → true (has content)', validateRequired(' a ') === true);

  // Booleans
  assert('validateRequired(true) → true', validateRequired(true) === true);
  assert('validateRequired(false) → false', validateRequired(false) === false);

  // Null / undefined
  assert('validateRequired(null) → false', validateRequired(null) === false);
  assert('validateRequired(undefined) → false', validateRequired(undefined) === false);

  // Numbers
  assert('validateRequired(0) → true', validateRequired(0) === true);
  assert('validateRequired(42) → true', validateRequired(42) === true);
  assert('validateRequired(-1) → true', validateRequired(-1) === true);
  assert('validateRequired(NaN) → false', validateRequired(NaN) === false);

  // Arrays
  assert('validateRequired([]) → false', validateRequired([]) === false);
  assert('validateRequired([1]) → true', validateRequired([1]) === true);
  assert('validateRequired([null]) → true (has content)', validateRequired([null]) === true);

  // Objects
  assert('validateRequired({}) → true (object exists)', validateRequired({}) === true);
}

function testCreateApiLogEntry() {
  console.log('\n=== F-08: createApiLogEntry(options) ===\n');

  // Test 1: Returns all expected fields
  {
    const entry = createApiLogEntry({ method: 'GET', endpoint: '/metaq-api/health', status: 'ok', duration: 312 });
    assert('Has id field', typeof entry.id === 'string' && entry.id.startsWith('log-'));
    assert('Has time field (HH:MM:SS)', /^\d{2}:\d{2}:\d{2}$/.test(entry.time));
    assert('method is "GET"', entry.method === 'GET');
    assert('endpoint is "/metaq-api/health"', entry.endpoint === '/metaq-api/health');
    assert('status is "ok"', entry.status === 'ok');
    assert('duration is 312', entry.duration === 312);
  }

  // Test 2: Pending entry with no duration
  {
    const entry = createApiLogEntry({ method: 'POST', endpoint: '/metaq-api/submit', status: 'pending' });
    assert('status is "pending"', entry.status === 'pending');
    assert('duration is null when omitted', entry.duration === null);
  }

  // Test 3: Error status
  {
    const entry = createApiLogEntry({ method: 'PUT', endpoint: '/metaq-api/draft', status: 'error', duration: 100 });
    assert('status is "error"', entry.status === 'error');
    assert('method is "PUT"', entry.method === 'PUT');
  }

  // Test 4: DELETE method
  {
    const entry = createApiLogEntry({ method: 'DELETE', endpoint: '/metaq-api/item/1', status: 'ok', duration: 50 });
    assert('method is "DELETE"', entry.method === 'DELETE');
  }

  // Test 5: Each call produces a unique id
  {
    const e1 = createApiLogEntry({ method: 'GET', endpoint: '/a', status: 'ok' });
    const e2 = createApiLogEntry({ method: 'GET', endpoint: '/b', status: 'ok' });
    assert('Two entries have different ids', e1.id !== e2.id);
  }

  // Test 6: Exact output shape (no extra fields)
  {
    const entry = createApiLogEntry({ method: 'GET', endpoint: '/test', status: 'ok', duration: 0 });
    const keys = Object.keys(entry).sort();
    assert('Output has exactly 6 fields', keys.join(',') === 'duration,endpoint,id,method,status,time');
  }
}

async function main() {
  await testDelay();
  testGenerateId();
  testGetTimestamp();
  testFormatTime();
  testDeepClone();
  testValidateEmail();
  testValidateRequired();
  testCreateApiLogEntry();

  console.log(`\n=============================`);
  console.log(`RESULTS: ${passed} passed, ${failed} failed`);
  console.log(`=============================\n`);

  if (failed > 0) process.exit(1);
}

main();
