// =============================================================================
// Phase 2 — Mock API Layer — Tests
// Run: npx tsx tests/lib/mockApi.test.ts
// =============================================================================

import { initMockStore, mockGetHealth, mockGetDatasets, mockGetDatasetByTitle, mockGetDraft, mockSaveDraft, mockValidateStep, mockRunGovernanceChecks, mockSubmitRegistration, mockGetAutomatedChecks, mockGetReviewStatus } from '../../src/lib/mockApi';
import type { ApiLogEntry } from '../../src/lib/foundation';

let passed = 0;
let failed = 0;

function assert(label: string, condition: boolean) {
  if (condition) {
    console.log(`  ✓ ${label}`);
    passed++;
  } else {
    console.error(`  ✗ ${label}`);
    failed++;
  }
}

// -----------------------------------------------------------------------------
// A-01: initMockStore()
// -----------------------------------------------------------------------------

function testInitMockStore() {
  console.log('\n=== A-01: initMockStore() ===\n');

  // Test 1: Returns an object
  {
    const store = initMockStore();
    assert('Returns an object', typeof store === 'object' && store !== null);
  }

  // Test 2: Has all required keys
  {
    const store = initMockStore();
    const keys = Object.keys(store).sort();
    const expected = ['_simulateErrors', 'checksTick', 'checksProgress', 'datasets', 'draft', 'reviewStatus', 'submission'].sort();
    assert('Has all 7 required keys', keys.join(',') === expected.join(','));
  }

  // Test 3: datasets is a non-empty array
  {
    const store = initMockStore();
    assert('datasets is an array with 5 entries', Array.isArray(store.datasets) && store.datasets.length === 5);
  }

  // Test 4: First dataset has correct shape
  {
    const store = initMockStore();
    const d = store.datasets[0];
    assert('First dataset has dataset_title', typeof d.dataset_title === 'string');
    assert('First dataset has name', typeof d.name === 'string');
    assert('First dataset has cidstaterag', typeof d.cidstaterag === 'string');
    assert('First dataset has cidcategory', typeof d.cidcategory === 'string');
    assert('First dataset has dqobject', typeof d.dqobject === 'string');
  }

  // Test 5: draft is null initially
  {
    const store = initMockStore();
    assert('draft is null', store.draft === null);
  }

  // Test 6: submission is null initially
  {
    const store = initMockStore();
    assert('submission is null', store.submission === null);
  }

  // Test 7: checksProgress is empty array
  {
    const store = initMockStore();
    assert('checksProgress is empty array', Array.isArray(store.checksProgress) && store.checksProgress.length === 0);
  }

  // Test 8: reviewStatus is empty array
  {
    const store = initMockStore();
    assert('reviewStatus is empty array', Array.isArray(store.reviewStatus) && store.reviewStatus.length === 0);
  }

  // Test 9: _simulateErrors is false
  {
    const store = initMockStore();
    assert('_simulateErrors is false', store._simulateErrors === false);
  }

  // Test 10: Two calls return independent stores (deep clone)
  {
    const s1 = initMockStore();
    const s2 = initMockStore();
    s1.datasets.push({} as any);
    assert('Two stores are independent (mutating one does not affect other)', s2.datasets.length === 5);
  }

  // Test 11: checksTick is 0
  {
    const store = initMockStore();
    assert('checksTick is 0', store.checksTick === 0);
  }

  // Test 12: Datasets include diverse titles
  {
    const store = initMockStore();
    const titles = new Set(store.datasets.map(d => d.dataset_title));
    assert('Datasets have multiple distinct titles', titles.size >= 2);
  }
}

// -----------------------------------------------------------------------------
// Main
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// A-02: mockGetHealth(store, logger)
// -----------------------------------------------------------------------------

async function testMockGetHealth() {
  console.log('\n=== A-02: mockGetHealth(store, logger) ===\n');

  // Test 1: Returns { status: "ok" }
  {
    const store = initMockStore();
    const logs: ApiLogEntry[] = [];
    const result = await mockGetHealth(store, (e) => logs.push(e));
    assert('Returns { status: "ok" }', result.status === 'ok');
  }

  // Test 2: Logger receives pending then ok
  {
    const store = initMockStore();
    const logs: ApiLogEntry[] = [];
    await mockGetHealth(store, (e) => logs.push(e));
    assert('Logger called twice (pending + ok)', logs.length === 2);
    assert('First log is pending', logs[0].status === 'pending');
    assert('Second log is ok', logs[1].status === 'ok');
  }

  // Test 3: Log entries have correct method and endpoint
  {
    const store = initMockStore();
    const logs: ApiLogEntry[] = [];
    await mockGetHealth(store, (e) => logs.push(e));
    assert('Method is GET', logs[0].method === 'GET');
    assert('Endpoint is /metaq-api/health', logs[0].endpoint === '/metaq-api/health');
  }

  // Test 4: Duration is set on final log entry
  {
    const store = initMockStore();
    const logs: ApiLogEntry[] = [];
    await mockGetHealth(store, (e) => logs.push(e));
    assert('Final log has duration (number)', typeof logs[1].duration === 'number' && logs[1].duration! > 0);
  }

  // Test 5: Takes approximately 300ms
  {
    const store = initMockStore();
    const start = Date.now();
    await mockGetHealth(store, () => {});
    const elapsed = Date.now() - start;
    assert('Takes ~300ms', elapsed >= 250 && elapsed < 500);
  }

  // Test 6: Returns a Promise
  {
    const store = initMockStore();
    const result = mockGetHealth(store, () => {});
    assert('Returns a Promise', result instanceof Promise);
    await result;
  }
}

// -----------------------------------------------------------------------------
// A-03: mockGetDatasets(store, logger)
// -----------------------------------------------------------------------------

async function testMockGetDatasets() {
  console.log('\n=== A-03: mockGetDatasets(store, logger) ===\n');

  // Test 1: Returns DatasetsResponse shape
  {
    const store = initMockStore();
    const logs: ApiLogEntry[] = [];
    const result = await mockGetDatasets(store, (e) => logs.push(e));
    assert('Has data array', Array.isArray(result.data));
    assert('Has limit', result.limit === 100);
    assert('Has offset', result.offset === 0);
    assert('Has count matching data length', result.count === result.data.length);
  }

  // Test 2: Returns all 5 seed datasets
  {
    const store = initMockStore();
    const result = await mockGetDatasets(store, () => {});
    assert('Returns 5 datasets', result.data.length === 5);
  }

  // Test 3: Returns deep clone (not a reference)
  {
    const store = initMockStore();
    const result = await mockGetDatasets(store, () => {});
    result.data[0].name = 'MUTATED';
    assert('Returned data is a deep clone', store.datasets[0].name !== 'MUTATED');
  }

  // Test 4: Logger receives pending then ok
  {
    const store = initMockStore();
    const logs: ApiLogEntry[] = [];
    await mockGetDatasets(store, (e) => logs.push(e));
    assert('Logger called twice', logs.length === 2);
    assert('First log pending', logs[0].status === 'pending');
    assert('Second log ok', logs[1].status === 'ok');
    assert('Endpoint is /metaq-api/datasets', logs[0].endpoint === '/metaq-api/datasets');
  }

  // Test 5: Takes ~800ms
  {
    const store = initMockStore();
    const start = Date.now();
    await mockGetDatasets(store, () => {});
    const elapsed = Date.now() - start;
    assert('Takes ~800ms', elapsed >= 750 && elapsed < 1000);
  }

  // Test 6: Dataset entries have required fields
  {
    const store = initMockStore();
    const result = await mockGetDatasets(store, () => {});
    const d = result.data[0];
    const hasFields = 'dataset_title' in d && 'name' in d && 'cidstaterag' in d && 'cidcategory' in d;
    assert('Dataset entries have all required fields', hasFields);
  }
}

// -----------------------------------------------------------------------------
// A-04: mockGetDatasetByTitle(store, logger, title)
// -----------------------------------------------------------------------------

async function testMockGetDatasetByTitle() {
  console.log('\n=== A-04: mockGetDatasetByTitle(store, logger, title) ===\n');

  // Test 1: Returns matching datasets for "rcat0100"
  {
    const store = initMockStore();
    const result = await mockGetDatasetByTitle(store, () => {}, 'rcat0100');
    assert('rcat0100 returns 2 entries', result.data.length === 2);
    assert('All results match title', result.data.every(d => d.dataset_title === 'rcat0100'));
  }

  // Test 2: Returns matching datasets for "rcat0200"
  {
    const store = initMockStore();
    const result = await mockGetDatasetByTitle(store, () => {}, 'rcat0200');
    assert('rcat0200 returns 2 entries', result.data.length === 2);
  }

  // Test 3: No match returns empty array
  {
    const store = initMockStore();
    const result = await mockGetDatasetByTitle(store, () => {}, 'nonexistent');
    assert('No match returns empty data', result.data.length === 0);
    assert('Count is 0', result.count === 0);
  }

  // Test 4: Empty title returns empty
  {
    const store = initMockStore();
    const result = await mockGetDatasetByTitle(store, () => {}, '');
    assert('Empty title returns empty data', result.data.length === 0);
  }

  // Test 5: Has pagination envelope
  {
    const store = initMockStore();
    const result = await mockGetDatasetByTitle(store, () => {}, 'rcat0100');
    assert('Has limit=100', result.limit === 100);
    assert('Has offset=0', result.offset === 0);
    assert('count matches data length', result.count === result.data.length);
  }

  // Test 6: Logger receives pending then ok
  {
    const store = initMockStore();
    const logs: ApiLogEntry[] = [];
    await mockGetDatasetByTitle(store, (e) => logs.push(e), 'rcat0100');
    assert('Logger called twice', logs.length === 2);
    assert('Endpoint contains title', logs[0].endpoint.includes('rcat0100'));
  }

  // Test 7: Returns deep clone
  {
    const store = initMockStore();
    const result = await mockGetDatasetByTitle(store, () => {}, 'rcat0100');
    result.data[0].name = 'MUTATED';
    assert('Result is a deep clone', store.datasets[0].name !== 'MUTATED');
  }
}

// -----------------------------------------------------------------------------
// A-05: mockGetDraft(store, logger)
// -----------------------------------------------------------------------------

async function testMockGetDraft() {
  console.log('\n=== A-05: mockGetDraft(store, logger) ===\n');

  // Test 1: No draft → exists: false
  {
    const store = initMockStore();
    const result = await mockGetDraft(store, () => {});
    assert('No draft → exists is false', result.exists === false);
    assert('No draft → registrationId is null', result.registrationId === null);
    assert('No draft → status is null', result.status === null);
    assert('No draft → currentStep is 1', result.currentStep === 1);
    assert('No draft → lastSaved is null', result.lastSaved === null);
    assert('No draft → steps is null', result.steps === null);
  }

  // Test 2: With draft → exists: true
  {
    const store = initMockStore();
    store.draft = {
      registrationId: 'draft-2026-0001',
      status: 'in_progress',
      currentStep: 3,
      lastSaved: '2026-02-12T13:00:00Z',
      steps: { step1: { productName: 'WMA Account' }, step2: { owner: 'owner@ubs.com' } },
    };
    const result = await mockGetDraft(store, () => {});
    assert('With draft → exists is true', result.exists === true);
    assert('registrationId matches', result.registrationId === 'draft-2026-0001');
    assert('status matches', result.status === 'in_progress');
    assert('currentStep matches', result.currentStep === 3);
    assert('lastSaved matches', result.lastSaved === '2026-02-12T13:00:00Z');
    assert('steps has step1', result.steps !== null && 'step1' in result.steps);
  }

  // Test 3: Returns deep clone (mutating result doesn't affect store)
  {
    const store = initMockStore();
    store.draft = {
      registrationId: 'draft-2026-0001',
      status: 'in_progress',
      currentStep: 1,
      lastSaved: null,
      steps: { step1: { productName: 'Original' } },
    };
    const result = await mockGetDraft(store, () => {});
    if (result.steps) result.steps.step1.productName = 'MUTATED';
    assert('Deep clone - store not affected', (store.draft.steps.step1 as any).productName === 'Original');
  }

  // Test 4: Logger receives pending then ok
  {
    const store = initMockStore();
    const logs: ApiLogEntry[] = [];
    await mockGetDraft(store, (e) => logs.push(e));
    assert('Logger called twice', logs.length === 2);
    assert('First log pending', logs[0].status === 'pending');
    assert('Second log ok', logs[1].status === 'ok');
    assert('Endpoint correct', logs[0].endpoint === '/metaq-api/registration/draft');
  }
}

// -----------------------------------------------------------------------------
// A-06: mockSaveDraft(store, logger, stepKey, stepData)
// -----------------------------------------------------------------------------

async function testMockSaveDraft() {
  console.log('\n=== A-06: mockSaveDraft(store, logger, stepKey, stepData) ===\n');

  // Test 1: First save creates the draft
  {
    const store = initMockStore();
    assert('Draft starts null', store.draft === null);
    const result = await mockSaveDraft(store, () => {}, 'step1', { productName: 'WMA Account' });
    assert('success is true', result.success === true);
    assert('Draft created', store.draft !== null);
    assert('registrationId starts with draft-', result.registrationId!.startsWith('draft-'));
  }

  // Test 2: Step data is saved correctly
  {
    const store = initMockStore();
    await mockSaveDraft(store, () => {}, 'step1', { productName: 'Test Product' });
    assert('step1 data saved', (store.draft!.steps.step1 as any).productName === 'Test Product');
  }

  // Test 3: lastSaved is updated
  {
    const store = initMockStore();
    const result = await mockSaveDraft(store, () => {}, 'step1', { productName: 'X' });
    assert('timestamp is set', result.timestamp !== null);
    assert('store.lastSaved is set', store.draft!.lastSaved !== null);
  }

  // Test 4: currentStep advances to highest saved step
  {
    const store = initMockStore();
    await mockSaveDraft(store, () => {}, 'step1', { a: 1 });
    assert('currentStep = 1 after step1', store.draft!.currentStep === 1);
    await mockSaveDraft(store, () => {}, 'step5', { b: 2 });
    assert('currentStep = 5 after step5', store.draft!.currentStep === 5);
    await mockSaveDraft(store, () => {}, 'step3', { c: 3 });
    assert('currentStep stays 5 after step3', store.draft!.currentStep === 5);
  }

  // Test 5: Invalid stepKey returns error
  {
    const store = initMockStore();
    const result = await mockSaveDraft(store, () => {}, 'step99', { x: 1 });
    assert('Invalid stepKey → success false', result.success === false);
    assert('Invalid stepKey → message', result.message === 'Invalid step key');
  }

  // Test 6: Null stepData returns error
  {
    const store = initMockStore();
    const result = await mockSaveDraft(store, () => {}, 'step1', null as any);
    assert('Null data → success false', result.success === false);
    assert('Null data → message', result.message === 'No data provided');
  }

  // Test 7: Logger receives pending then ok
  {
    const store = initMockStore();
    const logs: ApiLogEntry[] = [];
    await mockSaveDraft(store, (e) => logs.push(e), 'step1', { a: 1 });
    assert('Logger called twice', logs.length === 2);
    assert('Method is PUT', logs[0].method === 'PUT');
    assert('Status flow: pending → ok', logs[0].status === 'pending' && logs[1].status === 'ok');
  }

  // Test 8: Step data is deep-cloned into store
  {
    const store = initMockStore();
    const data = { productName: 'Original' };
    await mockSaveDraft(store, () => {}, 'step1', data);
    data.productName = 'MUTATED';
    assert('Store has deep clone, not reference', (store.draft!.steps.step1 as any).productName === 'Original');
  }

  // Test 9: Message includes step key
  {
    const store = initMockStore();
    const result = await mockSaveDraft(store, () => {}, 'step3', { x: 1 });
    assert('Message includes step key', result.message.includes('step3'));
  }
}

// -----------------------------------------------------------------------------
// A-07: mockValidateStep(store, logger, stepKey, stepData)
// -----------------------------------------------------------------------------

async function testMockValidateStep() {
  console.log('\n=== A-07: mockValidateStep(store, logger, stepKey, stepData) ===\n');

  const store = initMockStore();

  // Test 1: Step1 all required filled → valid
  {
    const result = await mockValidateStep(store, () => {}, 'step1', {
      productName: 'WMA Account', productType: 'Dataset', businessDomain: 'WMA', shortDescription: 'Test',
    });
    assert('Step1 all required → valid true', result.valid === true);
    assert('Step1 all required → 0 errors', result.errors.length === 0);
  }

  // Test 2: Step1 missing required → errors
  {
    const result = await mockValidateStep(store, () => {}, 'step1', {});
    assert('Step1 empty → valid false', result.valid === false);
    assert('Step1 empty → 4 errors', result.errors.length === 4);
    assert('Error fields include productName', result.errors.some(e => e.field === 'productName'));
  }

  // Test 3: Step1 warnings for missing optional
  {
    const result = await mockValidateStep(store, () => {}, 'step1', {
      productName: 'X', productType: 'Y', businessDomain: 'Z', shortDescription: 'W',
    });
    assert('Step1 → 2 warnings for missing optional', result.warnings.length === 2);
  }

  // Test 4: Step2 email validation
  {
    const result = await mockValidateStep(store, () => {}, 'step2', { owner: 'not-an-email' });
    assert('Step2 bad email → valid false', result.valid === false);
    assert('Step2 bad email → error message', result.errors.some(e => e.message === 'Invalid email format'));
  }

  // Test 5: Step2 valid email passes
  {
    const result = await mockValidateStep(store, () => {}, 'step2', { owner: 'owner@ubs.com' });
    assert('Step2 good email → valid true', result.valid === true);
  }

  // Test 6: Step10 requires attestations
  {
    const result = await mockValidateStep(store, () => {}, 'step10', {});
    assert('Step10 empty → valid false', result.valid === false);
    assert('Step10 → 3 errors for attestations', result.errors.length === 3);
  }

  // Test 7: Step10 with all attestations
  {
    const result = await mockValidateStep(store, () => {}, 'step10', {
      accuracyAttest: true, ownershipAttest: true, policyAttest: true,
    });
    assert('Step10 all attested → valid true', result.valid === true);
  }

  // Test 8: Step9 (all optional) always valid
  {
    const result = await mockValidateStep(store, () => {}, 'step9', {});
    assert('Step9 empty → valid true (all optional)', result.valid === true);
    assert('Step9 → 0 errors', result.errors.length === 0);
    assert('Step9 → 0 warnings', result.warnings.length === 0);
  }

  // Test 9: Unknown step returns error
  {
    const result = await mockValidateStep(store, () => {}, 'step99', {});
    assert('Unknown step → valid false', result.valid === false);
    assert('Unknown step → error field is _step', result.errors[0].field === '_step');
  }

  // Test 10: Logger receives pending then ok
  {
    const logs: ApiLogEntry[] = [];
    await mockValidateStep(store, (e) => logs.push(e), 'step1', { productName: 'X', productType: 'Y', businessDomain: 'Z', shortDescription: 'W' });
    assert('Logger called twice', logs.length === 2);
    assert('Method is POST', logs[0].method === 'POST');
    assert('Endpoint is /metaq-api/registration/validate', logs[0].endpoint === '/metaq-api/registration/validate');
  }

  // Test 11: Response shape is correct
  {
    const result = await mockValidateStep(store, () => {}, 'step4', {});
    assert('Has valid field', typeof result.valid === 'boolean');
    assert('Has errors array', Array.isArray(result.errors));
    assert('Has warnings array', Array.isArray(result.warnings));
  }
}

// -----------------------------------------------------------------------------
// A-08: mockRunGovernanceChecks(store, logger)
// -----------------------------------------------------------------------------

async function testMockRunGovernanceChecks() {
  console.log('\n=== A-08: mockRunGovernanceChecks(store, logger) ===\n');

  // Test 1: No draft → fails (missing metadata + retention + entitlement)
  {
    const store = initMockStore();
    const result = await mockRunGovernanceChecks(store, () => {});
    assert('No draft → overallStatus is "failed"', result.overallStatus === 'failed');
    assert('Has 5 checks', result.checks.length === 5);
  }

  // Test 2: PII detection always passes
  {
    const store = initMockStore();
    const result = await mockRunGovernanceChecks(store, () => {});
    const pii = result.checks.find(c => c.name === 'PII detection');
    assert('PII detection always passes', pii?.status === 'passed');
  }

  // Test 3: Full draft → all pass (with possible warning for spaces in name)
  {
    const store = initMockStore();
    store.draft = {
      registrationId: 'draft-2026-0001', status: 'in_progress', currentStep: 10, lastSaved: null,
      steps: {
        step1: { productName: 'WMAAccount', longDescription: 'Detailed description here' },
        step3: { cidClassification: 'NON-CID' },
        step8: { retentionReq: '7 years' },
      },
    };
    const result = await mockRunGovernanceChecks(store, () => {});
    assert('Full draft (no spaces) → "passed"', result.overallStatus === 'passed');
  }

  // Test 4: Product name with spaces → warning
  {
    const store = initMockStore();
    store.draft = {
      registrationId: 'draft-2026-0001', status: 'in_progress', currentStep: 10, lastSaved: null,
      steps: {
        step1: { productName: 'WMA Account', longDescription: 'Detailed' },
        step3: { cidClassification: 'CID' },
        step8: { retentionReq: '5 years' },
      },
    };
    const result = await mockRunGovernanceChecks(store, () => {});
    assert('Name with spaces → "passed_with_warnings"', result.overallStatus === 'passed_with_warnings');
    const naming = result.checks.find(c => c.name === 'Naming conventions');
    assert('Naming check is warning', naming?.status === 'warning');
  }

  // Test 5: Missing retentionReq → failed
  {
    const store = initMockStore();
    store.draft = {
      registrationId: 'x', status: 'in_progress', currentStep: 1, lastSaved: null,
      steps: { step1: { longDescription: 'Y' }, step3: { cidClassification: 'Z' } },
    };
    const result = await mockRunGovernanceChecks(store, () => {});
    const retention = result.checks.find(c => c.name === 'Retention compliance');
    assert('Missing retention → failed', retention?.status === 'failed');
  }

  // Test 6: Logger receives pending then ok
  {
    const store = initMockStore();
    const logs: ApiLogEntry[] = [];
    await mockRunGovernanceChecks(store, (e) => logs.push(e));
    assert('Logger called twice', logs.length === 2);
    assert('Method is POST', logs[0].method === 'POST');
    assert('Endpoint correct', logs[0].endpoint === '/metaq-api/registration/governance');
  }

  // Test 7: Each check has name, status, detail
  {
    const store = initMockStore();
    const result = await mockRunGovernanceChecks(store, () => {});
    const allValid = result.checks.every(c => c.name && c.status && c.detail);
    assert('All checks have name, status, detail', allValid);
  }
}

// -----------------------------------------------------------------------------
// A-09: mockSubmitRegistration(store, logger)
// -----------------------------------------------------------------------------

async function testMockSubmitRegistration() {
  console.log('\n=== A-09: mockSubmitRegistration(store, logger) ===\n');

  // Test 1: Returns SubmissionResponse shape
  {
    const store = initMockStore();
    store.draft = {
      registrationId: 'draft-2026-0001', status: 'in_progress', currentStep: 10, lastSaved: null,
      steps: {
        step1: { productName: 'WMA Account', shortDescription: 'Test product' },
        step2: { owner: 'owner@ubs.com' },
      },
    };
    const result = await mockSubmitRegistration(store, () => {});
    assert('success is true', result.success === true);
    assert('trackingId starts with WMA-', result.trackingId.startsWith('WMA-'));
    assert('submittedAt is ISO string', new Date(result.submittedAt).toISOString() === result.submittedAt);
    assert('eta is "3-5 business days"', result.eta === '3-5 business days');
  }

  // Test 2: Catalog entry has correct shape
  {
    const store = initMockStore();
    store.draft = {
      registrationId: 'x', status: 'in_progress', currentStep: 10, lastSaved: null,
      steps: { step1: { productName: 'My Product', shortDescription: 'Desc' }, step2: { owner: 'a@b.com' } },
    };
    const result = await mockSubmitRegistration(store, () => {});
    const entry = result.catalogEntry as any;
    assert('catalogEntry has p_dataset_data', 'p_dataset_data' in entry);
    assert('catalogEntry has p_internal', 'p_internal' in entry);
    assert('title matches productName', entry.p_dataset_data.title === 'My Product');
    assert('resource_iri is lowercase kebab', entry.p_dataset_data.resource_iri === 'wma://data-product/my-product');
    assert('status is submitted', entry.p_dataset_data.status === 'submitted');
    assert('owner_team matches', entry.p_internal.owner_team === 'a@b.com');
  }

  // Test 3: Store.submission is populated
  {
    const store = initMockStore();
    store.draft = { registrationId: 'x', status: 'in_progress', currentStep: 1, lastSaved: null, steps: {} };
    await mockSubmitRegistration(store, () => {});
    assert('store.submission is set', store.submission !== null);
    assert('store.submission.trackingId exists', store.submission!.trackingId.startsWith('WMA-'));
  }

  // Test 4: Automated checks initialized
  {
    const store = initMockStore();
    store.draft = { registrationId: 'x', status: 'in_progress', currentStep: 1, lastSaved: null, steps: {} };
    await mockSubmitRegistration(store, () => {});
    assert('checksProgress has 4 checks', store.checksProgress.length === 4);
    assert('All checks start pending', store.checksProgress.every(c => c.status === 'pending'));
    assert('checksTick reset to 0', store.checksTick === 0);
  }

  // Test 5: Review pipeline initialized
  {
    const store = initMockStore();
    store.draft = { registrationId: 'x', status: 'in_progress', currentStep: 1, lastSaved: null, steps: {} };
    await mockSubmitRegistration(store, () => {});
    assert('reviewStatus has 3 reviewers', store.reviewStatus.length === 3);
    assert('All reviewers start Waiting', store.reviewStatus.every(r => r.status === 'Waiting'));
  }

  // Test 6: Logger receives 4 entries (2 for submit, 2 for catalog)
  {
    const store = initMockStore();
    store.draft = { registrationId: 'x', status: 'in_progress', currentStep: 1, lastSaved: null, steps: {} };
    const logs: ApiLogEntry[] = [];
    await mockSubmitRegistration(store, (e) => logs.push(e));
    assert('Logger called 4 times', logs.length === 4);
    assert('First call is POST /submit', logs[0].endpoint.includes('submit'));
    assert('Third call is POST /dataset', logs[2].endpoint.includes('dataset'));
  }
}

// -----------------------------------------------------------------------------
// A-10: mockGetAutomatedChecks(store, logger)
// -----------------------------------------------------------------------------

async function testMockGetAutomatedChecks() {
  console.log('\n=== A-10: mockGetAutomatedChecks(store, logger) ===\n');

  // Helper: set up a submitted store
  function setupSubmittedStore() {
    const store = initMockStore();
    store.checksProgress = [
      { name: 'Data product qualification', status: 'pending' },
      { name: 'Ontology score (advisory)', status: 'pending' },
      { name: 'Upstream source certification', status: 'pending' },
      { name: 'Entitlement source validation', status: 'pending' },
    ];
    store.checksTick = 0;
    return store;
  }

  // Test 1: First call → first check running, rest pending
  {
    const store = setupSubmittedStore();
    const r1 = await mockGetAutomatedChecks(store, () => {});
    assert('Call 1: status is "running"', r1.status === 'running');
    assert('Call 1: first check running', r1.checks[0].status === 'running');
    assert('Call 1: second check pending', r1.checks[1].status === 'pending');
  }

  // Test 2: Progressive state advancement
  {
    const store = setupSubmittedStore();
    await mockGetAutomatedChecks(store, () => {});  // tick 0 → 1
    const r2 = await mockGetAutomatedChecks(store, () => {});  // tick 1 → 2
    assert('Call 2: first check passed', r2.checks[0].status === 'passed');
    assert('Call 2: second check running', r2.checks[1].status === 'running');
  }

  // Test 3: After all ticks → completed
  {
    const store = setupSubmittedStore();
    await mockGetAutomatedChecks(store, () => {}); // tick 0→1
    await mockGetAutomatedChecks(store, () => {}); // tick 1→2
    await mockGetAutomatedChecks(store, () => {}); // tick 2→3
    const r4 = await mockGetAutomatedChecks(store, () => {}); // tick 3→4
    assert('Call 4: status is "completed"', r4.status === 'completed');
  }

  // Test 4: Ontology check gets score
  {
    const store = setupSubmittedStore();
    for (let i = 0; i < 5; i++) await mockGetAutomatedChecks(store, () => {});
    const final = await mockGetAutomatedChecks(store, () => {});
    const ontology = final.checks[1];
    assert('Ontology check has score 87', ontology.score === 87);
  }

  // Test 5: Last check gets warning + note
  {
    const store = setupSubmittedStore();
    for (let i = 0; i < 5; i++) await mockGetAutomatedChecks(store, () => {});
    const final = await mockGetAutomatedChecks(store, () => {});
    const last = final.checks[3];
    assert('Last check is "warning"', last.status === 'warning');
    assert('Last check has note', last.note === 'Review recommended');
  }

  // Test 6: Idempotent after completion
  {
    const store = setupSubmittedStore();
    for (let i = 0; i < 6; i++) await mockGetAutomatedChecks(store, () => {});
    const r1 = await mockGetAutomatedChecks(store, () => {});
    const r2 = await mockGetAutomatedChecks(store, () => {});
    assert('Idempotent: both completed', r1.status === 'completed' && r2.status === 'completed');
  }

  // Test 7: Returns deep clone
  {
    const store = setupSubmittedStore();
    const r = await mockGetAutomatedChecks(store, () => {});
    r.checks[0].name = 'MUTATED';
    assert('Returns deep clone', store.checksProgress[0].name !== 'MUTATED');
  }

  // Test 8: Logger receives pending then ok
  {
    const store = setupSubmittedStore();
    const logs: ApiLogEntry[] = [];
    await mockGetAutomatedChecks(store, (e) => logs.push(e));
    assert('Logger called twice', logs.length === 2);
    assert('Method is GET', logs[0].method === 'GET');
  }
}

// -----------------------------------------------------------------------------
// A-11: mockGetReviewStatus(store, logger)
// -----------------------------------------------------------------------------

async function testMockGetReviewStatus() {
  console.log('\n=== A-11: mockGetReviewStatus(store, logger) ===\n');

  // Test 1: Before checks complete → all Waiting
  {
    const store = initMockStore();
    store.checksProgress = [{ name: 'Check1', status: 'pending' }];
    store.checksTick = 0;
    store.reviewStatus = [
      { name: 'Upstream Data Owners', status: 'Waiting', assignedTo: 'a@b.com', sla: '2 days' },
      { name: 'DWO Steward', status: 'Waiting', assignedTo: 'c@d.com', sla: '3 days' },
    ];
    const result = await mockGetReviewStatus(store, () => {});
    assert('Before checks complete: all Waiting', result.reviews.every(r => r.status === 'Waiting'));
  }

  // Test 2: After checks complete → first reviewer becomes Pending
  {
    const store = initMockStore();
    store.checksProgress = [{ name: 'Check1', status: 'passed' }];
    store.checksTick = 1; // >= checksProgress.length
    store.reviewStatus = [
      { name: 'Upstream Data Owners', status: 'Waiting', assignedTo: 'a@b.com', sla: '2 days' },
      { name: 'DWO Steward', status: 'Waiting', assignedTo: 'c@d.com', sla: '3 days' },
    ];
    const result = await mockGetReviewStatus(store, () => {});
    assert('After checks: first reviewer is Pending', result.reviews[0].status === 'Pending');
    assert('After checks: second reviewer still Waiting', result.reviews[1].status === 'Waiting');
  }

  // Test 3: Empty reviewStatus returns empty array
  {
    const store = initMockStore();
    const result = await mockGetReviewStatus(store, () => {});
    assert('No reviewers → empty array', result.reviews.length === 0);
  }

  // Test 4: Returns deep clone
  {
    const store = initMockStore();
    store.reviewStatus = [
      { name: 'Test', status: 'Waiting', assignedTo: 'x@y.com', sla: '1 day' },
    ];
    const result = await mockGetReviewStatus(store, () => {});
    result.reviews[0].name = 'MUTATED';
    assert('Returns deep clone', store.reviewStatus[0].name === 'Test');
  }

  // Test 5: Review entries have all required fields
  {
    const store = initMockStore();
    store.reviewStatus = [
      { name: 'R1', status: 'Waiting', assignedTo: 'a@b.com', sla: '2 days' },
    ];
    const result = await mockGetReviewStatus(store, () => {});
    const r = result.reviews[0];
    assert('Has name', typeof r.name === 'string');
    assert('Has status', typeof r.status === 'string');
    assert('Has assignedTo', typeof r.assignedTo === 'string');
    assert('Has sla', typeof r.sla === 'string');
  }

  // Test 6: Logger receives pending then ok
  {
    const store = initMockStore();
    const logs: ApiLogEntry[] = [];
    await mockGetReviewStatus(store, (e) => logs.push(e));
    assert('Logger called twice', logs.length === 2);
    assert('Method is GET', logs[0].method === 'GET');
    assert('Endpoint correct', logs[0].endpoint === '/metaq-api/registration/reviews');
  }
}

async function main() {
  testInitMockStore();
  await testMockGetHealth();
  await testMockGetDatasets();
  await testMockGetDatasetByTitle();
  await testMockGetDraft();
  await testMockSaveDraft();
  await testMockValidateStep();
  await testMockRunGovernanceChecks();
  await testMockSubmitRegistration();
  await testMockGetAutomatedChecks();
  await testMockGetReviewStatus();

  console.log(`\n=============================`);
  console.log(`RESULTS: ${passed} passed, ${failed} failed`);
  console.log(`=============================\n`);

  if (failed > 0) process.exit(1);
}

main();
