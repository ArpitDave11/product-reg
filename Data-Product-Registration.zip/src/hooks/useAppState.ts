import { useState, useCallback } from 'react';
import { initMockStore } from '../lib/mockApi';
import type { MockStore, StepData } from '../lib/mockApi';
import type { ApiLogEntry } from '../lib/foundation';
import type { ToastItem } from '../components/atoms/Toast';

/**
 * Phase / view the app can be in.
 * 'form' = multi-step wizard, 'submitted' = post-submission dashboard.
 */
export type AppPhase = 'form' | 'submitted';

export interface AppState {
  store: MockStore;
  currentStep: number;
  stepData: Record<string, StepData>;
  errors: Record<string, string>;
  warnings: Record<string, string>;
  toasts: ToastItem[];
  apiLog: ApiLogEntry[];
  phase: AppPhase;
  loading: boolean;
  loadingMessage: string;
}

const INITIAL_STEP_DATA: Record<string, StepData> = {
  step1: {}, step2: {}, step3: {}, step4: {}, step5: {},
  step6: {}, step7: {}, step8: {}, step9: {}, step10: {},
};

/**
 * O-01: useAppState — Central state management hook.
 * Holds all application state and exposes typed setters.
 * No business logic — just state containers and updaters.
 */
export function useAppState() {
  const [store] = useState<MockStore>(() => initMockStore());
  const [currentStep, setCurrentStep] = useState(1);
  const [stepData, setStepData] = useState<Record<string, StepData>>(() => ({ ...INITIAL_STEP_DATA }));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [warnings, setWarnings] = useState<Record<string, string>>({});
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [apiLog, setApiLog] = useState<ApiLogEntry[]>([]);
  const [phase, setPhase] = useState<AppPhase>('form');
  const [loading, setLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');

  const logger = useCallback((entry: ApiLogEntry) => {
    setApiLog((prev) => [...prev, entry]);
  }, []);

  const addToast = useCallback((toast: Omit<ToastItem, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev, { ...toast, id }]);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const updateField = useCallback((field: string, value: string | boolean) => {
    const stepKey = `step${currentStep}`;
    setStepData((prev) => ({
      ...prev,
      [stepKey]: { ...prev[stepKey], [field]: value },
    }));
  }, [currentStep]);

  return {
    store, currentStep, setCurrentStep, stepData, setStepData,
    errors, setErrors, warnings, setWarnings,
    toasts, addToast, dismissToast,
    apiLog, logger,
    phase, setPhase,
    loading, setLoading, loadingMessage, setLoadingMessage,
    updateField,
  };
}
