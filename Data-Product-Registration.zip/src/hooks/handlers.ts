import { mockSaveDraft, mockValidateStep, mockRunGovernanceChecks, mockSubmitRegistration } from '../lib/mockApi';
import type { MockStore, StepData, Logger, FieldError } from '../lib/mockApi';

type AddToast = (toast: { type: 'success' | 'error' | 'loading' | 'warning'; message: string }) => void;
type SetErrors = (errors: Record<string, string>) => void;
type SetWarnings = (warnings: Record<string, string>) => void;
type SetStep = (step: number) => void;
type SetLoading = (loading: boolean) => void;
type SetLoadingMessage = (msg: string) => void;

function fieldErrorsToRecord(errors: FieldError[]): Record<string, string> {
  const result: Record<string, string> = {};
  for (const e of errors) result[e.field] = e.message;
  return result;
}

/**
 * O-04: handleSaveAndContinue — Validates and saves the current step,
 * then advances to the next step if validation passes.
 */
export async function handleSaveAndContinue(
  store: MockStore,
  logger: Logger,
  currentStep: number,
  stepData: Record<string, StepData>,
  addToast: AddToast,
  setErrors: SetErrors,
  setWarnings: SetWarnings,
  setStep: SetStep,
  setLoading: SetLoading,
  setLoadingMessage: SetLoadingMessage,
): Promise<void> {
  const stepKey = `step${currentStep}`;
  const data = stepData[stepKey] || {};

  setLoading(true);
  setLoadingMessage('Validating...');

  try {
    const validation = await mockValidateStep(store, logger, stepKey, data);

    setErrors(fieldErrorsToRecord(validation.errors));
    setWarnings(fieldErrorsToRecord(validation.warnings));

    if (!validation.valid) {
      addToast({ type: 'error', message: `Step ${currentStep} has validation errors` });
      return;
    }

    setLoadingMessage('Saving...');
    const saveResult = await mockSaveDraft(store, logger, stepKey, data);

    if (!saveResult.success) {
      addToast({ type: 'error', message: 'Save failed' });
      return;
    }

    addToast({ type: 'success', message: `Step ${currentStep} saved` });

    if (currentStep < 10) {
      setStep(currentStep + 1);
      setErrors({});
      setWarnings({});
    }
  } catch {
    addToast({ type: 'error', message: 'An unexpected error occurred' });
  } finally {
    setLoading(false);
    setLoadingMessage('');
  }
}

/**
 * O-05: handleSubmit — Runs governance checks, then submits registration.
 * Called from Step 10.
 */
export async function handleSubmit(
  store: MockStore,
  logger: Logger,
  stepData: Record<string, StepData>,
  addToast: AddToast,
  setErrors: SetErrors,
  setWarnings: SetWarnings,
  setLoading: SetLoading,
  setLoadingMessage: SetLoadingMessage,
  setPhase: (phase: 'form' | 'submitted') => void,
): Promise<void> {
  const stepKey = 'step10';
  const data = stepData[stepKey] || {};

  setLoading(true);
  setLoadingMessage('Validating attestations...');

  try {
    const validation = await mockValidateStep(store, logger, stepKey, data);
    setErrors(fieldErrorsToRecord(validation.errors));
    setWarnings(fieldErrorsToRecord(validation.warnings));

    if (!validation.valid) {
      addToast({ type: 'error', message: 'Please complete all attestations' });
      return;
    }

    setLoadingMessage('Running governance checks...');
    const governance = await mockRunGovernanceChecks(store, logger);

    if (governance.overallStatus === 'failed') {
      addToast({ type: 'warning', message: 'Governance checks need attention' });
      return;
    }

    setLoadingMessage('Submitting registration...');
    const submission = await mockSubmitRegistration(store, logger);

    if (submission.success) {
      addToast({ type: 'success', message: `Submitted! Tracking: ${submission.trackingId}` });
      setPhase('submitted');
    } else {
      addToast({ type: 'error', message: 'Submission failed' });
    }
  } catch {
    addToast({ type: 'error', message: 'Submission error' });
  } finally {
    setLoading(false);
    setLoadingMessage('');
  }
}

/**
 * O-06: handleAppInit — Initializes the app by checking API health
 * and loading any existing draft.
 */
export async function handleAppInit(
  store: MockStore,
  logger: Logger,
  addToast: AddToast,
  setStepData: (data: Record<string, StepData>) => void,
  setStep: SetStep,
): Promise<void> {
  try {
    const { mockGetHealth, mockGetDraft } = await import('../lib/mockApi');

    await mockGetHealth(store, logger);
    addToast({ type: 'success', message: 'API connected' });

    const draft = await mockGetDraft(store, logger);
    if (draft.exists && draft.steps) {
      const merged: Record<string, StepData> = {
        step1: {}, step2: {}, step3: {}, step4: {}, step5: {},
        step6: {}, step7: {}, step8: {}, step9: {}, step10: {},
        ...draft.steps,
      };
      setStepData(merged);
      setStep(draft.currentStep);
      addToast({ type: 'success', message: `Draft loaded (step ${draft.currentStep})` });
    }
  } catch {
    addToast({ type: 'warning', message: 'API health check failed — using local mode' });
  }
}
