// =============================================================================
// PHASE 2 — MOCK API LAYER
// Async functions that simulate real API calls against an in-memory store.
// Each function: creates a log entry → waits → processes → returns response.
// =============================================================================

import { delay, generateId, getTimestamp, createApiLogEntry, deepClone, validateEmail, validateRequired } from './foundation';
import type { ApiLogEntry } from './foundation';

/** Logger callback type — receives ApiLogEntry objects for the UI log panel. */
export type Logger = (entry: ApiLogEntry) => void;

// -----------------------------------------------------------------------------
// Types
// -----------------------------------------------------------------------------

export interface Dataset {
  dataset_title: string;
  name: string;
  description: string | null;
  sourcedescription: string | null;
  aigenerateddescription: string | null;
  ontologyid: string | null;
  ontologyname: string | null;
  cidstaterag: string;
  cidcategory: string;
  cidjustification: string | null;
  disocidcategory: string;
  disocidstaterag: string;
  kde: string | null;
  dqobject: string;
  recommendedusage: string | null;
}

export interface StepData {
  [field: string]: unknown;
}

export interface DraftState {
  registrationId: string;
  status: string;
  currentStep: number;
  lastSaved: string | null;
  steps: Record<string, StepData>;
}

export interface Check {
  name: string;
  status: 'passed' | 'running' | 'pending' | 'warning' | 'failed';
  score?: number;
  note?: string;
}

export interface Review {
  name: string;
  status: 'Pending' | 'Waiting' | 'Approved';
  assignedTo: string;
  sla: string;
}

export interface SubmissionState {
  trackingId: string;
  submittedAt: string;
  eta: string;
  catalogEntry: Record<string, unknown>;
}

export interface MockStore {
  datasets: Dataset[];
  draft: DraftState | null;
  submission: SubmissionState | null;
  checksProgress: Check[];
  checksTick: number;
  reviewStatus: Review[];
  _simulateErrors: boolean;
}

// -----------------------------------------------------------------------------
// Static seed data
// -----------------------------------------------------------------------------

const SEED_DATASETS: Dataset[] = [
  {
    dataset_title: 'rcat0100',
    name: 'ACC_N',
    description: null,
    sourcedescription: null,
    aigenerateddescription: null,
    ontologyid: null,
    ontologyname: null,
    cidstaterag: 'Green',
    cidcategory: 'NON-CID',
    cidjustification: null,
    disocidcategory: 'NON-CID',
    disocidstaterag: 'Green',
    kde: null,
    dqobject: '[]',
    recommendedusage: null,
  },
  {
    dataset_title: 'rcat0100',
    name: 'ACCT_TYPE_CD',
    description: null,
    sourcedescription: null,
    aigenerateddescription: null,
    ontologyid: null,
    ontologyname: null,
    cidstaterag: 'Green',
    cidcategory: 'NON-CID',
    cidjustification: null,
    disocidcategory: 'NON-CID',
    disocidstaterag: 'Green',
    kde: null,
    dqobject: '[]',
    recommendedusage: null,
  },
  {
    dataset_title: 'rcat0200',
    name: 'CLIENT_ID',
    description: 'Unique client identifier',
    sourcedescription: 'Source system: CRM',
    aigenerateddescription: 'AI-generated: Primary client identifier used across systems',
    ontologyid: 'ONT-001',
    ontologyname: 'Client',
    cidstaterag: 'Amber',
    cidcategory: 'CID',
    cidjustification: 'Contains client-identifiable data',
    disocidcategory: 'CID',
    disocidstaterag: 'Amber',
    kde: 'Yes',
    dqobject: '[{"rule":"not_null","threshold":99}]',
    recommendedusage: 'Client reporting and analytics',
  },
  {
    dataset_title: 'rcat0200',
    name: 'CLIENT_NAME',
    description: 'Full legal client name',
    sourcedescription: 'Source system: CRM',
    aigenerateddescription: null,
    ontologyid: 'ONT-002',
    ontologyname: 'Client',
    cidstaterag: 'Red',
    cidcategory: 'CID',
    cidjustification: 'PII - full name',
    disocidcategory: 'CID',
    disocidstaterag: 'Red',
    kde: 'Yes',
    dqobject: '[{"rule":"not_null","threshold":100}]',
    recommendedusage: 'Client onboarding only',
  },
  {
    dataset_title: 'rcat0300',
    name: 'TXN_AMOUNT',
    description: 'Transaction amount in base currency',
    sourcedescription: 'Source system: Core Banking',
    aigenerateddescription: 'AI-generated: Monetary value of individual transactions',
    ontologyid: 'ONT-010',
    ontologyname: 'Transaction',
    cidstaterag: 'Green',
    cidcategory: 'NON-CID',
    cidjustification: null,
    disocidcategory: 'NON-CID',
    disocidstaterag: 'Green',
    kde: 'Yes',
    dqobject: '[{"rule":"range","min":0,"threshold":95}]',
    recommendedusage: 'Financial reporting and reconciliation',
  },
];

// -----------------------------------------------------------------------------
// A-01: initMockStore()
// -----------------------------------------------------------------------------

/**
 * Initializes the in-memory data store that acts as the mock "database."
 * Called once on app startup. Returns a mutable object (intentional —
 * it simulates a server-side database).
 *
 * @returns A fully initialized MockStore with seed datasets and empty state.
 *
 * @example
 * const store = initMockStore();
 * store.datasets.length → 5
 * store.draft → null
 */
export function initMockStore(): MockStore {
  return {
    datasets: deepClone(SEED_DATASETS),
    draft: null,
    submission: null,
    checksProgress: [],
    checksTick: 0,
    reviewStatus: [],
    _simulateErrors: false,
  };
}

// -----------------------------------------------------------------------------
// A-02: mockGetHealth(store, logger)
// -----------------------------------------------------------------------------

/**
 * Simulates `GET /metaq-api/health`. Returns API health status.
 * When store._simulateErrors is true, has a 20% chance of throwing.
 *
 * @param store - The mock data store.
 * @param logger - Callback to receive API log entries.
 * @returns Promise resolving to { status: "ok" }.
 */
export async function mockGetHealth(
  store: MockStore,
  logger: Logger,
): Promise<{ status: string }> {
  const endpoint = '/metaq-api/health';
  const pending = createApiLogEntry({ method: 'GET', endpoint, status: 'pending' });
  logger(pending);

  await delay(300);

  if (store._simulateErrors && Math.random() < 0.2) {
    logger({ ...pending, status: 'error', duration: 300 });
    throw new Error('Service unavailable');
  }

  logger({ ...pending, status: 'ok', duration: 300 });
  return { status: 'ok' };
}

// -----------------------------------------------------------------------------
// A-03: mockGetDatasets(store, logger)
// -----------------------------------------------------------------------------

/** Paginated response envelope for dataset queries. */
export interface DatasetsResponse {
  data: Dataset[];
  limit: number;
  offset: number;
  count: number;
}

/**
 * Simulates `GET /metaq-api/datasets`. Returns the full dataset catalog
 * wrapped in a pagination envelope.
 *
 * @param store - The mock data store (reads store.datasets).
 * @param logger - Callback to receive API log entries.
 * @returns Promise resolving to a DatasetsResponse.
 */
export async function mockGetDatasets(
  store: MockStore,
  logger: Logger,
): Promise<DatasetsResponse> {
  const endpoint = '/metaq-api/datasets';
  const pending = createApiLogEntry({ method: 'GET', endpoint, status: 'pending' });
  logger(pending);

  await delay(800);

  const data = deepClone(store.datasets);
  logger({ ...pending, status: 'ok', duration: 800 });
  return { data, limit: 100, offset: 0, count: data.length };
}

// -----------------------------------------------------------------------------
// A-04: mockGetDatasetByTitle(store, logger, title)
// -----------------------------------------------------------------------------

/**
 * Simulates `GET /metaq-api/dataset/{title}`. Returns datasets matching
 * a given title, wrapped in a pagination envelope.
 *
 * @param store - The mock data store.
 * @param logger - Callback to receive API log entries.
 * @param title - Dataset title to filter by (e.g., "rcat0100").
 * @returns Promise resolving to a DatasetsResponse (filtered).
 */
export async function mockGetDatasetByTitle(
  store: MockStore,
  logger: Logger,
  title: string,
): Promise<DatasetsResponse> {
  const endpoint = `/metaq-api/dataset/${title || ''}`;
  const pending = createApiLogEntry({ method: 'GET', endpoint, status: 'pending' });
  logger(pending);

  await delay(600);

  const safeTitle = (title ?? '').trim();
  const filtered = safeTitle
    ? deepClone(store.datasets.filter((d) => d.dataset_title === safeTitle))
    : [];

  logger({ ...pending, status: 'ok', duration: 600 });
  return { data: filtered, limit: 100, offset: 0, count: filtered.length };
}

// -----------------------------------------------------------------------------
// A-05: mockGetDraft(store, logger)
// -----------------------------------------------------------------------------

/** Response shape for draft retrieval. */
export interface DraftResponse {
  exists: boolean;
  registrationId: string | null;
  status: string | null;
  currentStep: number;
  lastSaved: string | null;
  steps: Record<string, StepData> | null;
}

/**
 * Simulates `GET /metaq-api/registration/{id}/draft`. Loads saved form state.
 * Returns a "no draft" response if store.draft is null, otherwise a deep clone.
 *
 * @param store - The mock data store (reads store.draft).
 * @param logger - Callback to receive API log entries.
 * @returns Promise resolving to a DraftResponse.
 */
export async function mockGetDraft(
  store: MockStore,
  logger: Logger,
): Promise<DraftResponse> {
  const endpoint = '/metaq-api/registration/draft';
  const pending = createApiLogEntry({ method: 'GET', endpoint, status: 'pending' });
  logger(pending);

  await delay(500);

  logger({ ...pending, status: 'ok', duration: 500 });

  if (!store.draft) {
    return { exists: false, registrationId: null, status: null, currentStep: 1, lastSaved: null, steps: null };
  }

  const draft = deepClone(store.draft);
  return {
    exists: true,
    registrationId: draft.registrationId,
    status: draft.status,
    currentStep: draft.currentStep,
    lastSaved: draft.lastSaved,
    steps: draft.steps,
  };
}

// -----------------------------------------------------------------------------
// A-06: mockSaveDraft(store, logger, stepKey, stepData)
// -----------------------------------------------------------------------------

const VALID_STEP_KEYS = ['step1','step2','step3','step4','step5','step6','step7','step8','step9','step10'];

/** Response shape for draft save operations. */
export interface SaveResponse {
  success: boolean;
  message: string;
  timestamp: string | null;
  registrationId: string | null;
}

/**
 * Simulates `PUT /metaq-api/registration/{id}/draft`. Saves one step's data
 * to the in-memory store. Creates the draft if it doesn't exist yet.
 *
 * @param store - The mock data store (writes to store.draft).
 * @param logger - Callback to receive API log entries.
 * @param stepKey - "step1" through "step10".
 * @param stepData - Object containing the field values for that step.
 * @returns Promise resolving to a SaveResponse.
 */
export async function mockSaveDraft(
  store: MockStore,
  logger: Logger,
  stepKey: string,
  stepData: StepData,
): Promise<SaveResponse> {
  const endpoint = '/metaq-api/registration/draft';
  const pending = createApiLogEntry({ method: 'PUT', endpoint, status: 'pending' });
  logger(pending);

  await delay(700);

  if (!VALID_STEP_KEYS.includes(stepKey)) {
    logger({ ...pending, status: 'error', duration: 700 });
    return { success: false, message: 'Invalid step key', timestamp: null, registrationId: null };
  }

  if (!stepData) {
    logger({ ...pending, status: 'error', duration: 700 });
    return { success: false, message: 'No data provided', timestamp: null, registrationId: null };
  }

  if (!store.draft) {
    store.draft = {
      registrationId: generateId('draft'),
      status: 'in_progress',
      currentStep: 1,
      lastSaved: null,
      steps: {},
    };
  }

  const stepNumber = parseInt(stepKey.replace('step', ''), 10);
  store.draft.steps[stepKey] = deepClone(stepData);
  store.draft.lastSaved = getTimestamp();
  store.draft.currentStep = Math.max(store.draft.currentStep, stepNumber);

  logger({ ...pending, status: 'ok', duration: 700 });
  return {
    success: true,
    message: `Step '${stepKey}' saved successfully`,
    timestamp: store.draft.lastSaved,
    registrationId: store.draft.registrationId,
  };
}

// -----------------------------------------------------------------------------
// A-07: mockValidateStep(store, logger, stepKey, stepData)
// -----------------------------------------------------------------------------

/** Validation error for a single field. */
export interface FieldError {
  field: string;
  message: string;
}

/** Response shape for step validation. */
export interface ValidationResponse {
  valid: boolean;
  errors: FieldError[];
  warnings: FieldError[];
}

/** Validation rule definition per step. */
interface StepValidationRule {
  required: { field: string; label: string; email?: boolean }[];
  warnings: { field: string; label: string }[];
}

const VALIDATION_RULES: Record<string, StepValidationRule> = {
  step1: {
    required: [
      { field: 'productName', label: 'Product Name' },
      { field: 'productType', label: 'Product Type' },
      { field: 'businessDomain', label: 'Business Domain' },
      { field: 'shortDescription', label: 'Short Description' },
    ],
    warnings: [
      { field: 'longDescription', label: 'A detailed description improves discoverability' },
      { field: 'businessPurpose', label: 'Business purpose is recommended' },
    ],
  },
  step2: {
    required: [
      { field: 'owner', label: 'Data Product Owner', email: true },
    ],
    warnings: [
      { field: 'backupOwner', label: 'Backup owner is recommended' },
      { field: 'itLead', label: 'IT Lead is recommended' },
      { field: 'dataSteward', label: 'Data Steward is recommended' },
    ],
  },
  step3: {
    required: [
      { field: 'environment', label: 'Environment' },
      { field: 'cidClassification', label: 'CID Classification' },
    ],
    warnings: [
      { field: 'sourceUrl', label: 'Source URL is recommended' },
      { field: 'inputDatasets', label: 'Input datasets are recommended' },
    ],
  },
  step4: {
    required: [],
    warnings: [
      { field: 'businessDefs', label: 'Business definitions improve clarity' },
      { field: 'kdeMapping', label: 'KDE mapping is recommended' },
    ],
  },
  step5: {
    required: [
      { field: 'threshold', label: 'DQ Threshold' },
    ],
    warnings: [
      { field: 'coverage', label: 'Coverage metric is recommended' },
      { field: 'completeness', label: 'Completeness metric is recommended' },
    ],
  },
  step6: {
    required: [
      { field: 'updateFrequency', label: 'Update Frequency' },
    ],
    warnings: [
      { field: 'accessModes', label: 'Access modes are recommended' },
      { field: 'deprecationPolicy', label: 'Deprecation policy is recommended' },
    ],
  },
  step7: {
    required: [],
    warnings: [
      { field: 'upstreamProducts', label: 'Upstream products are recommended' },
      { field: 'lineageNarrative', label: 'Lineage narrative is recommended' },
    ],
  },
  step8: {
    required: [
      { field: 'classification', label: 'Classification' },
    ],
    warnings: [
      { field: 'retentionReq', label: 'Retention requirement is recommended' },
      { field: 'permittedUses', label: 'Permitted uses are recommended' },
    ],
  },
  step9: {
    required: [],
    warnings: [],
  },
  step10: {
    required: [
      { field: 'accuracyAttest', label: 'Accuracy attestation is required' },
      { field: 'ownershipAttest', label: 'Ownership attestation is required' },
      { field: 'policyAttest', label: 'Policy attestation is required' },
    ],
    warnings: [],
  },
};

/**
 * Simulates `POST /metaq-api/registration/validate`. Runs server-side
 * validation for a step against the VALIDATION_RULES lookup table.
 *
 * @param store - The mock data store (used for signature consistency).
 * @param logger - Callback to receive API log entries.
 * @param stepKey - "step1" through "step10".
 * @param stepData - Object with the step's field values.
 * @returns Promise resolving to a ValidationResponse.
 */
export async function mockValidateStep(
  _store: MockStore,
  logger: Logger,
  stepKey: string,
  stepData: StepData,
): Promise<ValidationResponse> {
  const endpoint = '/metaq-api/registration/validate';
  const pending = createApiLogEntry({ method: 'POST', endpoint, status: 'pending' });
  logger(pending);

  await delay(400);

  const rules = VALIDATION_RULES[stepKey];
  if (!rules) {
    logger({ ...pending, status: 'error', duration: 400 });
    return { valid: false, errors: [{ field: '_step', message: 'Unknown step' }], warnings: [] };
  }

  const errors: FieldError[] = [];
  const warnings: FieldError[] = [];
  const data = stepData || {};

  for (const r of rules.required) {
    const val = data[r.field];
    if (!validateRequired(val)) {
      errors.push({ field: r.field, message: `${r.label} is required` });
    } else if (r.email && !validateEmail(val as string)) {
      errors.push({ field: r.field, message: `Invalid email format` });
    }
  }

  for (const w of rules.warnings) {
    if (!validateRequired(data[w.field])) {
      warnings.push({ field: w.field, message: w.label });
    }
  }

  logger({ ...pending, status: 'ok', duration: 400 });
  return { valid: errors.length === 0, errors, warnings };
}

// -----------------------------------------------------------------------------
// A-08: mockRunGovernanceChecks(store, logger)
// -----------------------------------------------------------------------------

/** A single governance check result. */
export interface GovernanceCheck {
  name: string;
  status: 'passed' | 'warning' | 'failed';
  detail: string;
}

/** Response from governance check run. */
export interface GovernanceResponse {
  overallStatus: 'passed' | 'passed_with_warnings' | 'failed';
  checks: GovernanceCheck[];
}

/**
 * Simulates `POST /metaq-api/registration/{id}/governance`. Runs pre-submission
 * governance checks against the full draft. Checks actually inspect the draft
 * data, so filling more fields = more checks passing.
 *
 * @param store - The mock data store (reads store.draft).
 * @param logger - Callback to receive API log entries.
 * @returns Promise resolving to a GovernanceResponse.
 */
export async function mockRunGovernanceChecks(
  store: MockStore,
  logger: Logger,
): Promise<GovernanceResponse> {
  const endpoint = '/metaq-api/registration/governance';
  const pending = createApiLogEntry({ method: 'POST', endpoint, status: 'pending' });
  logger(pending);

  await delay(1200);

  const steps = store.draft?.steps || {};
  const step1 = (steps.step1 || {}) as Record<string, unknown>;
  const step3 = (steps.step3 || {}) as Record<string, unknown>;
  const step8 = (steps.step8 || {}) as Record<string, unknown>;

  const checks: GovernanceCheck[] = [
    { name: 'PII detection', status: 'passed', detail: 'No PII fields detected' },
    {
      name: 'Retention compliance',
      status: validateRequired(step8.retentionReq) ? 'passed' : 'failed',
      detail: validateRequired(step8.retentionReq) ? 'Meets UBS policy' : 'Retention requirement missing',
    },
    {
      name: 'Naming conventions',
      status: (typeof step1.productName === 'string' && step1.productName.includes(' ')) ? 'warning' : 'passed',
      detail: (typeof step1.productName === 'string' && step1.productName.includes(' '))
        ? 'Consider aligning to WMA naming standard' : 'Naming compliant',
    },
    {
      name: 'Metadata completeness',
      status: validateRequired(step1.longDescription) ? 'passed' : 'failed',
      detail: validateRequired(step1.longDescription) ? 'All metadata fields populated' : 'Long description missing',
    },
    {
      name: 'Entitlement alignment',
      status: validateRequired(step3.cidClassification) ? 'passed' : 'failed',
      detail: validateRequired(step3.cidClassification)
        ? 'Aligned with source entitlements' : 'CID classification not set',
    },
  ];

  const hasFailed = checks.some((c) => c.status === 'failed');
  const hasWarning = checks.some((c) => c.status === 'warning');
  const overallStatus = hasFailed ? 'failed' : hasWarning ? 'passed_with_warnings' : 'passed';

  logger({ ...pending, status: 'ok', duration: 1200 });
  return { overallStatus, checks };
}

// -----------------------------------------------------------------------------
// A-09: mockSubmitRegistration(store, logger)
// -----------------------------------------------------------------------------

/** Response shape for registration submission. */
export interface SubmissionResponse {
  success: boolean;
  trackingId: string;
  submittedAt: string;
  eta: string;
  catalogEntry: Record<string, unknown>;
}

/**
 * Simulates the full submission flow: creates catalog entry, generates
 * tracking ID, initializes automated checks and review pipeline.
 *
 * @param store - The mock data store (reads draft, writes submission state).
 * @param logger - Callback to receive API log entries.
 * @returns Promise resolving to a SubmissionResponse.
 */
export async function mockSubmitRegistration(
  store: MockStore,
  logger: Logger,
): Promise<SubmissionResponse> {
  const endpoint = '/metaq-api/registration/submit';
  const pending = createApiLogEntry({ method: 'POST', endpoint, status: 'pending' });
  logger(pending);

  await delay(1500);

  const steps = store.draft?.steps || {};
  const step1 = (steps.step1 || {}) as Record<string, unknown>;
  const step2 = (steps.step2 || {}) as Record<string, unknown>;

  const catalogEntry = {
    p_dataset_data: {
      resource_iri: `wma://data-product/${String(step1.productName || 'unknown').toLowerCase().replace(/\s+/g, '-')}`,
      title: step1.productName || '',
      description: step1.shortDescription || '',
      status: 'submitted',
    },
    p_internal: {
      source_system_code: 'SPP',
      owner_team: step2.owner || '',
    },
  };

  const catalogLog = createApiLogEntry({ method: 'POST', endpoint: '/metaq-api/dataset', status: 'pending' });
  logger(catalogLog);

  await delay(500);

  logger({ ...catalogLog, status: 'ok', duration: 500 });

  const trackingId = generateId('WMA');
  const submittedAt = getTimestamp();

  store.submission = { trackingId, submittedAt, eta: '3-5 business days', catalogEntry };

  store.checksProgress = [
    { name: 'Data product qualification', status: 'pending' },
    { name: 'Ontology score (advisory)', status: 'pending' },
    { name: 'Upstream source certification', status: 'pending' },
    { name: 'Entitlement source validation', status: 'pending' },
  ];
  store.checksTick = 0;

  store.reviewStatus = [
    { name: 'Upstream Data Owners', status: 'Waiting', assignedTo: 'upstream-team@ubs.com', sla: '2 days' },
    { name: 'DWO Steward', status: 'Waiting', assignedTo: 'steward@ubs.com', sla: '3 days' },
    { name: 'KDE Reviewer', status: 'Waiting', assignedTo: 'kde-team@ubs.com', sla: '3 days' },
  ];

  logger({ ...pending, status: 'ok', duration: 2000 });
  return { success: true, trackingId, submittedAt, eta: '3-5 business days', catalogEntry };
}

// -----------------------------------------------------------------------------
// A-10: mockGetAutomatedChecks(store, logger)
// -----------------------------------------------------------------------------

/** Response shape for automated checks polling. */
export interface ChecksResponse {
  status: 'running' | 'completed';
  checks: Check[];
}

/**
 * Simulates `GET /metaq-api/registration/{id}/checks`. Returns current
 * check states, advancing them by one tick on each call (state machine).
 *
 * @param store - The mock data store (reads/writes store.checksProgress).
 * @param logger - Callback to receive API log entries.
 * @returns Promise resolving to a ChecksResponse.
 */
export async function mockGetAutomatedChecks(
  store: MockStore,
  logger: Logger,
): Promise<ChecksResponse> {
  const endpoint = '/metaq-api/registration/checks';
  const pending = createApiLogEntry({ method: 'GET', endpoint, status: 'pending' });
  logger(pending);

  await delay(600);

  const checks = store.checksProgress;
  const tick = store.checksTick;

  if (tick < checks.length) {
    for (let i = 0; i < checks.length; i++) {
      if (i < tick) {
        checks[i].status = 'passed';
        if (i === 1) checks[i].score = 87;
        if (i === 3) { checks[i].status = 'warning'; checks[i].note = 'Review recommended'; }
      } else if (i === tick) {
        checks[i].status = 'running';
      } else {
        checks[i].status = 'pending';
      }
    }
    store.checksTick++;
  } else {
    checks[0].status = 'passed';
    checks[1] = { ...checks[1], status: 'passed', score: 87 };
    checks[2].status = 'passed';
    checks[3] = { ...checks[3], status: 'warning', note: 'Review recommended' };
  }

  const completed = store.checksTick >= checks.length;
  logger({ ...pending, status: 'ok', duration: 600 });
  return { status: completed ? 'completed' : 'running', checks: deepClone(checks) };
}

// -----------------------------------------------------------------------------
// A-11: mockGetReviewStatus(store, logger)
// -----------------------------------------------------------------------------

/** Response shape for review status polling. */
export interface ReviewResponse {
  reviews: Review[];
}

/**
 * Simulates `GET /metaq-api/registration/{id}/reviews`. Returns reviewer
 * statuses. Once automated checks complete, advances the first reviewer
 * from "Waiting" to "Pending" (simulating handoff).
 *
 * @param store - The mock data store (reads store.reviewStatus).
 * @param logger - Callback to receive API log entries.
 * @returns Promise resolving to a ReviewResponse.
 */
export async function mockGetReviewStatus(
  store: MockStore,
  logger: Logger,
): Promise<ReviewResponse> {
  const endpoint = '/metaq-api/registration/reviews';
  const pending = createApiLogEntry({ method: 'GET', endpoint, status: 'pending' });
  logger(pending);

  await delay(400);

  const checksCompleted = store.checksTick >= store.checksProgress.length && store.checksProgress.length > 0;
  if (checksCompleted && store.reviewStatus.length > 0 && store.reviewStatus[0].status === 'Waiting') {
    store.reviewStatus[0].status = 'Pending';
  }

  logger({ ...pending, status: 'ok', duration: 400 });
  return { reviews: deepClone(store.reviewStatus) };
}
