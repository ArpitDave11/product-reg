// =============================================================================
// PHASE 1 — FOUNDATION LAYER
// Pure utility functions with zero external dependencies.
// =============================================================================

// -----------------------------------------------------------------------------
// F-01: delay(ms)
// -----------------------------------------------------------------------------

/**
 * Creates a Promise that resolves after a given number of milliseconds.
 * Core building block for simulating API latency in the mock layer.
 *
 * @param ms - Milliseconds to wait. Negative or NaN values are treated as 0.
 * @returns A Promise that resolves to undefined after the specified delay.
 *
 * @example
 * await delay(500); // pauses execution for 500ms
 * await delay(0);   // resolves on next microtask
 * await delay(-1);  // treated as 0, resolves immediately
 */
export function delay(ms: number): Promise<void> {
  const safe = (!Number.isFinite(ms) || ms < 0) ? 0 : ms;
  return new Promise((resolve) => setTimeout(resolve, safe));
}

// -----------------------------------------------------------------------------
// F-02: generateId(prefix)
// -----------------------------------------------------------------------------

/**
 * Generates a unique identifier string for tracking IDs, registration IDs,
 * and correlation IDs in the mock layer.
 *
 * @param prefix - String prefix (e.g., "WMA", "draft", "corr").
 * @returns String in format "{prefix}-{year}-{4-digit-random}".
 *
 * @example
 * generateId("WMA")   → "WMA-2026-0384"
 * generateId("draft") → "draft-2026-0917"
 */
export function generateId(prefix: string): string {
  const year = new Date().getFullYear();
  const rand = String(Math.floor(Math.random() * 10000)).padStart(4, '0');
  return `${prefix}-${year}-${rand}`;
}

// -----------------------------------------------------------------------------
// F-03: getTimestamp()
// -----------------------------------------------------------------------------

/**
 * Returns the current time as an ISO 8601 string.
 * Single source of truth for all timestamps across the mock layer.
 *
 * @returns ISO 8601 string, e.g., "2026-02-12T14:30:00.000Z"
 *
 * @example
 * getTimestamp() → "2026-02-12T14:30:00.000Z"
 */
export function getTimestamp(): string {
  return new Date().toISOString();
}

// -----------------------------------------------------------------------------
// F-04: formatTime(date)
// -----------------------------------------------------------------------------

/**
 * Formats a Date object or ISO string into a human-readable "HH:MM:SS" string.
 * Used in the API log panel and toast notifications.
 *
 * @param date - A Date object or ISO 8601 string.
 * @returns String in format "HH:MM:SS" (24-hour). Returns "00:00:00" for invalid input.
 *
 * @example
 * formatTime(new Date("2026-02-12T14:30:05Z")) → "14:30:05"
 * formatTime("2026-02-12T14:30:05Z")           → "14:30:05"
 * formatTime(null)                               → "00:00:00"
 */
export function formatTime(date: Date | string | null | undefined): string {
  const fallback = '00:00:00';
  if (date == null) return fallback;
  const d = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(d.getTime())) return fallback;
  const h = String(d.getUTCHours()).padStart(2, '0');
  const m = String(d.getUTCMinutes()).padStart(2, '0');
  const s = String(d.getUTCSeconds()).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

// -----------------------------------------------------------------------------
// F-05: deepClone(obj)
// -----------------------------------------------------------------------------

/**
 * Creates a deep copy of a JSON-serializable value. Returns a new object
 * with no shared references to the original. Critical for the mock layer
 * to prevent the UI from mutating "backend" state directly.
 *
 * @param obj - Any JSON-serializable value (object, array, primitive, null).
 * @returns A deep copy with no shared references. Date objects become strings.
 *
 * @example
 * const copy = deepClone({ a: { b: 1 } });
 * copy.a.b = 2; // original.a.b is still 1
 */
export function deepClone<T>(obj: T): T {
  if (obj === null || obj === undefined) return obj;
  if (typeof structuredClone === 'function') return structuredClone(obj);
  return JSON.parse(JSON.stringify(obj));
}

// -----------------------------------------------------------------------------
// F-06: validateEmail(value)
// -----------------------------------------------------------------------------

/**
 * Validates that a string is a plausible email address. Not a full RFC 5322
 * implementation — just a sensible check for the registration form.
 *
 * @param value - String to validate.
 * @returns true if the string matches a basic email pattern, false otherwise.
 *
 * @example
 * validateEmail("user@ubs.com") → true
 * validateEmail("user@ubs")     → false
 * validateEmail("")             → false
 */
export function validateEmail(value: string | null | undefined): boolean {
  if (value == null || typeof value !== 'string') return false;
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return pattern.test(value);
}

// -----------------------------------------------------------------------------
// F-07: validateRequired(value)
// -----------------------------------------------------------------------------

/**
 * Checks if a value is non-empty. The most common validator across all steps.
 *
 * Rules:
 * - string: trimmed length > 0
 * - boolean: true = filled, false = empty
 * - null/undefined: always empty
 * - number: 0 is filled, NaN is empty
 * - array: length > 0
 *
 * @param value - Any value to check.
 * @returns true if the value is considered "filled", false if "empty".
 *
 * @example
 * validateRequired("hello") → true
 * validateRequired("")      → false
 * validateRequired("   ")   → false
 * validateRequired(0)       → true
 * validateRequired(false)   → false
 */
export function validateRequired(value: unknown): boolean {
  if (value == null) return false;
  if (typeof value === 'string') return value.trim().length > 0;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return !isNaN(value);
  if (Array.isArray(value)) return value.length > 0;
  return true;
}

// -----------------------------------------------------------------------------
// F-08: createApiLogEntry(options)
// -----------------------------------------------------------------------------

/** Shape of an API log entry displayed in the ApiLogPanel. */
export interface ApiLogEntry {
  id: string;
  time: string;
  method: string;
  endpoint: string;
  status: 'ok' | 'pending' | 'error';
  duration: number | null;
}

/** Options for creating an API log entry. */
export interface ApiLogEntryOptions {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  endpoint: string;
  status: 'ok' | 'pending' | 'error';
  duration?: number | null;
}

/**
 * Creates a structured log entry object for the API Activity Log panel.
 * Every mock API call produces one of these.
 *
 * @param options - Object with method, endpoint, status, and optional duration.
 * @returns An ApiLogEntry with a unique id and formatted timestamp.
 *
 * @example
 * createApiLogEntry({
 *   method: "GET",
 *   endpoint: "/metaq-api/health",
 *   status: "ok",
 *   duration: 312,
 * })
 * → { id: "log-2026-0001", time: "14:30:05", method: "GET", endpoint: "/metaq-api/health", status: "ok", duration: 312 }
 */
export function createApiLogEntry(options: ApiLogEntryOptions): ApiLogEntry {
  return {
    id: generateId('log'),
    time: formatTime(new Date()),
    method: options.method,
    endpoint: options.endpoint,
    status: options.status,
    duration: options.duration ?? null,
  };
}
