import { useEffect } from 'react';

export interface ToastItem {
  id: string;
  type: 'success' | 'error' | 'loading' | 'warning';
  message: string;
}

interface ToastProps {
  toasts: ToastItem[];
  onDismiss: (id: string) => void;
}

const ICONS: Record<ToastItem['type'], string> = {
  success: '\u2713',
  error: '\u2717',
  loading: '\u25CB',
  warning: '\u26A0',
};

const COLORS: Record<ToastItem['type'], { bg: string; border: string; text: string }> = {
  success: { bg: 'bg-[#ddf6e0]', border: 'border-[#2e7d32]', text: 'text-[#2e7d32]' },
  error:   { bg: 'bg-[#ffe6ea]', border: 'border-[#e60028]', text: 'text-[#e60028]' },
  loading: { bg: 'bg-[#f4f4f4]', border: 'border-[#5a5a5a]', text: 'text-[#5a5a5a]' },
  warning: { bg: 'bg-[#fff8e1]', border: 'border-[#f57f17]', text: 'text-[#f57f17]' },
};

/**
 * U-01: Toast — Displays a stack of notification messages.
 * Fixed-position stack in the top-right corner. Auto-dismisses after 4s
 * (except "loading" type which persists).
 */
export function Toast({ toasts, onDismiss }: ToastProps) {
  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 max-w-sm">
      {toasts.map((toast) => (
        <ToastEntry key={toast.id} toast={toast} onDismiss={onDismiss} />
      ))}
    </div>
  );
}

function ToastEntry({ toast, onDismiss }: { toast: ToastItem; onDismiss: (id: string) => void }) {
  useEffect(() => {
    if (toast.type === 'loading') return;
    const timer = setTimeout(() => onDismiss(toast.id), 4000);
    return () => clearTimeout(timer);
  }, [toast.id, toast.type, onDismiss]);

  const c = COLORS[toast.type];

  return (
    <div
      className={`flex items-center gap-3 px-4 py-3 rounded-xl border ${c.bg} ${c.border} ${c.text} shadow-sm cursor-pointer text-sm`}
      onClick={() => onDismiss(toast.id)}
    >
      <span className="font-bold text-base">{ICONS[toast.type]}</span>
      <span>{toast.message}</span>
      {toast.type === 'loading' && (
        <span className="ml-auto animate-spin text-xs">&#9696;</span>
      )}
    </div>
  );
}
