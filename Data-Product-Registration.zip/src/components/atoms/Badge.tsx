interface BadgeProps {
  variant: 'required' | 'optional';
}

/**
 * U-05: Badge — Small pill showing "Required" or "Optional" on step cards.
 */
export function Badge({ variant }: BadgeProps) {
  const style = variant === 'required'
    ? 'bg-gradient-to-r from-[#ffe6ea] to-[#fff0f2] text-[#e60028] border-2 border-[#ffcccc] shadow-sm'
    : 'bg-[#f4f4f4] text-[#5a5a5a] border-2 border-[#d9d9d9]';

  const label = variant === 'required' ? 'REQUIRED' : 'OPTIONAL';

  return (
    <span className={`px-4 py-2 rounded-full text-xs font-bold ${style}`}>
      {label}
    </span>
  );
}
