import { CheckCircle2, Clock } from 'lucide-react';

export interface StepInfo {
  id: number;
  title: string;
  sub: string;
}

export type StepStatus = 'completed' | 'active' | 'upcoming' | 'error';

interface StepperItemProps {
  step: StepInfo;
  status: StepStatus;
  onClick: () => void;
}

/**
 * U-04: StepperItem — A single step item in the sidebar stepper.
 * Shows step number in a circle, title, subtitle, and visual status.
 */
export function StepperItem({ step, status, onClick }: StepperItemProps) {
  const cardStyle = {
    completed: 'bg-gradient-to-r from-[#e60028] to-[#ff1744] text-white shadow-lg shadow-red-200 scale-105',
    active: 'bg-white border-2 border-[#e60028] shadow-md hover:shadow-lg hover:scale-105',
    upcoming: 'bg-white/50 border border-[#e5e5e5] hover:bg-white hover:border-[#d9d9d9] hover:shadow-md',
    error: 'bg-white border-2 border-[#e60028] shadow-md',
  }[status];

  const circleStyle = {
    completed: 'bg-white text-[#e60028] shadow-md',
    active: 'bg-[#e60028] text-white',
    upcoming: 'bg-[#f4f4f4] text-[#5a5a5a]',
    error: 'bg-[#ffe6ea] text-[#e60028]',
  }[status];

  const titleColor = status === 'completed' ? 'text-white' : status === 'error' ? 'text-[#e60028]' : 'text-[#000000]';
  const subColor = status === 'completed' ? 'text-white/90' : 'text-[#5a5a5a]';

  return (
    <li
      className={`flex gap-3 p-3 rounded-xl cursor-pointer transition-all duration-300 relative animate-slide-in-right ${cardStyle}`}
      onClick={onClick}
    >
      <div
        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 z-10 ${circleStyle}`}
      >
        {status === 'completed' ? <CheckCircle2 className="w-4 h-4" /> : step.id}
      </div>
      <div className="flex flex-col gap-0.5 flex-1">
        <div className={`font-semibold text-sm ${titleColor}`}>{step.title}</div>
        <div className={`text-xs ${subColor}`}>{step.sub}</div>
      </div>
      {status === 'active' && (
        <div className="absolute -right-2 -top-2">
          <div className="bg-[#e60028] text-white rounded-full p-1 shadow-lg animate-pulse">
            <Clock className="w-3 h-3" />
          </div>
        </div>
      )}
    </li>
  );
}
