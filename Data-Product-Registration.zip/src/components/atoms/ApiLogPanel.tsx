import { useEffect, useRef } from 'react';
import { Activity, X } from 'lucide-react';
import type { ApiLogEntry } from '../../lib/foundation';

interface ApiLogPanelProps {
  logs: ApiLogEntry[];
  visible: boolean;
  onToggle: () => void;
}

const METHOD_COLORS: Record<string, string> = {
  GET: 'text-[#2e7d32]',
  POST: 'text-[#1565c0]',
  PUT: 'text-[#f57f17]',
  DELETE: 'text-[#e60028]',
};

const STATUS_COLORS: Record<string, string> = {
  ok: 'text-[#2e7d32]',
  pending: 'text-[#5a5a5a]',
  error: 'text-[#e60028]',
};

/**
 * U-02: ApiLogPanel — Floating slide-in drawer showing API activity.
 * Toggle button in top-right corner. Drawer slides in from right as overlay.
 * Uses inline styles for positioning since compiled CSS lacks fixed/z-index utilities.
 */
export function ApiLogPanel({ logs, visible, onToggle }: ApiLogPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (visible && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs.length, visible]);

  return (
    <>
      {/* Toggle button — fixed top-right */}
      <button
        onClick={onToggle}
        style={{
          position: 'fixed',
          top: 16,
          right: 16,
          zIndex: 9998,
        }}
        className="flex items-center gap-2 px-3 py-2 bg-white border-2 border-[#d9d9d9] hover:border-[#e60028] rounded-xl text-xs font-semibold text-[#5a5a5a] shadow-md hover:shadow-lg transition-all duration-300"
      >
        <Activity className="w-3 h-3" />
        API Log ({logs.length})
      </button>

      {/* Backdrop */}
      {visible && (
        <div
          onClick={onToggle}
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 9998,
            backgroundColor: 'rgba(0,0,0,0.1)',
          }}
        />
      )}

      {/* Slide-in drawer */}
      <div
        style={{
          position: 'fixed',
          top: 0,
          right: 0,
          zIndex: 9999,
          height: '100vh',
          width: 384,
          transform: visible ? 'translateX(0)' : 'translateX(100%)',
          transition: 'transform 0.3s ease',
        }}
        className="bg-white border-l-2 border-[#d9d9d9] shadow-2xl"
      >
        {/* Drawer header */}
        <div className="flex items-center justify-between p-4" style={{ borderBottom: '2px solid #d9d9d9' }}>
          <div className="flex items-center gap-2">
            <div className="p-1 bg-gradient-to-br from-[#e60028] to-[#ff1744] rounded-lg">
              <Activity className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-sm text-[#000000]">API Activity Log</span>
            <span className="px-2 bg-[#f4f4f4] rounded-full text-xs font-semibold text-[#5a5a5a]">
              {logs.length}
            </span>
          </div>
          <button
            onClick={onToggle}
            className="p-1 hover:bg-[#f4f4f4] rounded-lg transition-colors"
          >
            <X className="w-4 h-4 text-[#5a5a5a]" />
          </button>
        </div>

        {/* Log entries */}
        <div ref={scrollRef} className="overflow-y-auto p-4" style={{ height: 'calc(100vh - 60px)' }}>
          {logs.length === 0 ? (
            <p className="text-sm text-[#5a5a5a] text-center mt-8">No API calls yet.</p>
          ) : (
            <div className="space-y-2">
              {logs.map((entry) => (
                <div
                  key={entry.id}
                  className="p-3 border border-[#e5e5e5] rounded-xl text-xs"
                  style={{ background: 'linear-gradient(to bottom right, #fff, #fafafa)' }}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className={`font-bold ${METHOD_COLORS[entry.method] || 'text-[#000000]'}`}>
                      {entry.method}
                    </span>
                    <span className="text-[#5a5a5a]">{entry.time}</span>
                  </div>
                  <div className="text-[#000000] font-medium mb-1" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{entry.endpoint}</div>
                  <div className="flex items-center justify-between">
                    <span className={`font-medium ${STATUS_COLORS[entry.status] || ''}`}>
                      {entry.status}
                    </span>
                    <span className="text-[#5a5a5a]">
                      {entry.duration != null ? `${entry.duration}ms` : '...'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
