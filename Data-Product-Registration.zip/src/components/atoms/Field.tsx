interface FieldProps {
  label: string;
  value: string | boolean;
  onChange: (newValue: string | boolean) => void;
  type?: 'text' | 'textarea' | 'select' | 'checkbox';
  options?: string[];
  placeholder?: string;
  disabled?: boolean;
  error?: string;
  warning?: string;
  span2?: boolean;
}

/**
 * U-03: Field — A single form field. Renders text input, textarea, select,
 * or checkbox based on type prop. Fully controlled via value/onChange.
 */
export function Field({
  label,
  value,
  onChange,
  type = 'text',
  options,
  placeholder,
  disabled = false,
  error,
  warning,
  span2 = false,
}: FieldProps) {
  const borderColor = error
    ? 'border-[#e60028]'
    : 'border-2 border-[#e5e5e5] hover:border-[#e60028]';

  const focusRing = 'focus:outline-none focus:border-[#e60028] focus:shadow-sm';
  const inputBase = `w-full ${borderColor} rounded-xl p-4 text-sm bg-gradient-to-br from-white to-[#fafafa] text-[#000000] font-medium transition-all duration-200 shadow-sm ${focusRing}`;

  return (
    <div className={`space-y-2 ${span2 ? 'col-span-2' : ''}`}>
      <label className="text-xs text-[#5a5a5a] font-bold uppercase tracking-wider flex items-center gap-2">
        <div className="w-1.5 h-1.5 rounded-full bg-[#e60028]"></div>
        {label}
      </label>

      {type === 'checkbox' ? (
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={value === true}
            onChange={(e) => onChange(e.target.checked)}
            disabled={disabled}
            className="w-4 h-4 accent-[#e60028]"
          />
          <span className="text-sm text-[#000000]">{placeholder || label}</span>
        </label>
      ) : type === 'textarea' ? (
        <textarea
          value={typeof value === 'string' ? value : ''}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          rows={3}
          className={`${inputBase} resize-vertical ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        />
      ) : type === 'select' ? (
        <select
          value={typeof value === 'string' ? value : ''}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          className={`${inputBase} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <option value="">{placeholder || 'Select...'}</option>
          {options?.map((opt) => (
            <option key={opt} value={opt}>{opt}</option>
          ))}
        </select>
      ) : (
        <input
          type="text"
          value={typeof value === 'string' ? value : ''}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          className={`${inputBase} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        />
      )}

      {error && <p className="text-xs text-[#e60028]">{error}</p>}
      {!error && warning && <p className="text-xs text-[#f57f17]">{warning}</p>}
    </div>
  );
}
