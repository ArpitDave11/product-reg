import type { ReactNode } from 'react';

interface CardWrapperProps {
  children: ReactNode;
  muted?: boolean;
  className?: string;
}

/**
 * U-07: CardWrapper — Standard card container used by every step form
 * and dashboard panel. Matches the design reference card style.
 */
export function CardWrapper({ children, muted = false, className = '' }: CardWrapperProps) {
  const bg = muted ? 'bg-gradient-to-br from-[#f4f4f4] to-[#fafafa]' : 'bg-white';

  return (
    <div className={`group border-2 border-[#d9d9d9] hover:border-[#e60028] rounded-3xl p-8 shadow-sm hover:shadow-2xl transition-all duration-300 animate-fade-in ${bg} ${className}`}>
      {children}
    </div>
  );
}
