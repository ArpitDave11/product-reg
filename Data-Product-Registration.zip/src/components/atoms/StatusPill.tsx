export type PillVariant = 'default' | 'progress' | 'success' | 'warning' | 'error';

interface StatusPillProps {
  label: string;
  variant?: PillVariant;
}

/**
 * U-06: StatusPill — Small pill showing a status label with colored styling.
 * Progress variant gets gradient background + shimmer animation.
 */
export function StatusPill({ label, variant = 'default' }: StatusPillProps) {
  if (variant === 'progress') {
    return (
      <div className="relative overflow-hidden px-4 py-3 rounded-xl bg-gradient-to-r from-[#e60028] to-[#ff1744] text-white text-sm text-center font-semibold shadow-lg shadow-red-200">
        <div className="relative z-10">{label}</div>
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 animate-shimmer"></div>
      </div>
    );
  }

  const VARIANT_STYLES: Record<PillVariant, string> = {
    default: 'border-[#d9d9d9] text-[#5a5a5a] bg-white',
    progress: '',
    success: 'border-[#2e7d32] text-white bg-gradient-to-r from-[#22c55e] to-[#16a34a] shadow-lg',
    warning: 'border-[#f57f17] text-[#f57f17] bg-[#fff8e1]',
    error: 'border-[#e60028] text-[#e60028] bg-[#ffe6ea]',
  };

  return (
    <div className={`px-4 py-3 border-2 rounded-xl text-sm text-center font-semibold ${VARIANT_STYLES[variant]}`}>
      {label}
    </div>
  );
}
