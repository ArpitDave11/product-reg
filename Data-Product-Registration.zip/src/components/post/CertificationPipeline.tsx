import { Shield, CheckCircle2, Database, Send } from 'lucide-react';
import { StatusPill } from '../atoms';

interface CertificationPipelineProps {
  checksComplete: boolean;
}

const PIPELINE_STEPS = [
  { label: 'Integrity Check', icon: CheckCircle2 },
  { label: 'Validation', icon: Shield },
  { label: 'Register', icon: Database },
  { label: 'Publish', icon: Send },
];

/**
 * P-04: CertificationPipeline — Shows the certification and publish pipeline
 * steps. Activated after automated checks complete.
 */
export function CertificationPipeline({ checksComplete }: CertificationPipelineProps) {
  return (
    <section className="bg-gradient-to-br from-white to-[#fafafa] border-2 border-[#d9d9d9] rounded-3xl p-8 shadow-lg animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-gradient-to-br from-[#e60028] to-[#ff1744] rounded-xl shadow-lg">
          <Shield className="w-6 h-6 text-white" />
        </div>
        <h3 className="font-bold text-2xl text-[#000000]">Certification & Publish (WMA)</h3>
        <div className="ml-auto">
          <StatusPill label={checksComplete ? 'Ready' : 'Waiting'} variant={checksComplete ? 'success' : 'default'} />
        </div>
      </div>
      <div className="grid grid-cols-4 gap-4">
        {PIPELINE_STEPS.map(({ label, icon: Icon }) => (
          <div key={label} className="group p-5 bg-white border-2 border-[#e5e5e5] hover:border-[#e60028] rounded-2xl transition-all duration-300 hover:shadow-lg cursor-pointer">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#e60028]/10 to-[#ff1744]/10 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <Icon className="w-6 h-6 text-[#e60028]" />
            </div>
            <div className="text-sm font-semibold text-[#000000]">{label}</div>
          </div>
        ))}
      </div>
      <div className="mt-6 p-4 bg-white border border-[#e5e5e5] rounded-xl">
        <p className="text-sm text-[#5a5a5a]">
          Product becomes discoverable for consumers in WMA Data Catalog.
        </p>
      </div>
    </section>
  );
}
