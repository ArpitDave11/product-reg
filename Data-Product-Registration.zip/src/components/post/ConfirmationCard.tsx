import { CheckCircle2, Clock, Database } from 'lucide-react';

interface ConfirmationCardProps {
  trackingId: string;
  submittedAt: string;
  eta: string;
}

/**
 * P-01: ConfirmationCard — Displays submission receipt with tracking ID,
 * timestamp, and estimated time to completion.
 */
export function ConfirmationCard({ trackingId, submittedAt, eta }: ConfirmationCardProps) {
  return (
    <section className="bg-gradient-to-br from-[#f0fdf4] to-white border-2 border-[#86efac] rounded-3xl p-8 shadow-lg animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-gradient-to-br from-[#22c55e] to-[#16a34a] rounded-xl shadow-lg">
          <CheckCircle2 className="w-6 h-6 text-white" />
        </div>
        <h3 className="font-bold text-2xl text-[#000000]">Submission Confirmed</h3>
      </div>
      <div className="flex items-start gap-6 p-6 bg-white border-2 border-[#86efac] rounded-2xl">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#22c55e] to-[#16a34a] flex items-center justify-center shadow-lg shadow-green-200 flex-shrink-0">
          <CheckCircle2 className="w-8 h-8 text-white" />
        </div>
        <div className="flex-1">
          <div className="font-bold text-lg text-[#000000] mb-2">Submission Received Successfully</div>
          <div className="text-sm text-[#5a5a5a] mb-4">Your data product is now in automated validation queue.</div>
          <div className="flex flex-wrap gap-3">
            <span className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#f4f4f4] to-white border-2 border-[#d9d9d9] rounded-xl text-sm font-semibold text-[#000000] shadow-sm">
              <Database className="w-4 h-4 text-[#e60028]" />
              {trackingId}
            </span>
            <span className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#f4f4f4] to-white border-2 border-[#d9d9d9] rounded-xl text-sm font-semibold text-[#000000] shadow-sm">
              <Clock className="w-4 h-4 text-[#e60028]" />
              {submittedAt}
            </span>
            <span className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#f4f4f4] to-white border-2 border-[#d9d9d9] rounded-xl text-sm font-semibold text-[#000000] shadow-sm">
              <Clock className="w-4 h-4 text-[#e60028]" />
              ETA: {eta}
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
