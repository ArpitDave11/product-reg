import { TrendingUp, Clock } from 'lucide-react';
import { StatusPill } from '../atoms';
import type { Review } from '../../lib/mockApi';
import type { PillVariant } from '../atoms';

interface ReviewDashboardProps {
  reviews: Review[];
}

const REVIEW_VARIANT: Record<Review['status'], PillVariant> = {
  Pending: 'progress',
  Waiting: 'default',
  Approved: 'success',
};

/**
 * P-03: ReviewDashboard — Shows human reviewer status with SLA info.
 */
export function ReviewDashboard({ reviews }: ReviewDashboardProps) {
  return (
    <section className="bg-gradient-to-br from-white to-[#fafafa] border-2 border-[#d9d9d9] rounded-3xl p-8 shadow-lg animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-gradient-to-br from-[#e60028] to-[#ff1744] rounded-xl shadow-lg">
          <TrendingUp className="w-6 h-6 text-white" />
        </div>
        <h3 className="font-bold text-2xl text-[#000000]">Review Dashboard</h3>
      </div>
      <div className="space-y-3">
        <div className="grid grid-cols-3 gap-4 p-4 bg-gradient-to-r from-[#e60028] to-[#ff1744] rounded-xl font-bold text-sm text-white shadow-lg">
          <div>Reviewer</div>
          <div>Status</div>
          <div>SLA</div>
        </div>
        {reviews.map((review) => (
          <div key={review.name} className="grid grid-cols-3 gap-4 p-4 bg-white border-2 border-[#e5e5e5] hover:border-[#e60028] rounded-xl text-sm text-[#000000] transition-all duration-200 hover:shadow-lg">
            <div className="font-medium">{review.name}</div>
            <div><StatusPill label={review.status} variant={REVIEW_VARIANT[review.status]} /></div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#5a5a5a]" />
              {review.sla}
            </div>
          </div>
        ))}
      </div>
      {reviews.length === 0 && (
        <p className="text-sm text-[#5a5a5a]">Reviews will begin after automated checks complete.</p>
      )}
    </section>
  );
}
