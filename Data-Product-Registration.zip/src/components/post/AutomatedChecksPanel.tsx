import { Activity, CheckCircle2, Clock } from 'lucide-react';
import { StatusPill } from '../atoms';
import type { Check } from '../../lib/mockApi';
import type { PillVariant } from '../atoms';

interface AutomatedChecksPanelProps {
  checks: Check[];
  complete: boolean;
}

const STATUS_VARIANT: Record<Check['status'], PillVariant> = {
  passed: 'success',
  running: 'progress',
  pending: 'default',
  warning: 'warning',
  failed: 'error',
};

/**
 * P-02: AutomatedChecksPanel — Displays the list of automated checks
 * with their current status (pending -> running -> passed/warning/failed).
 */
export function AutomatedChecksPanel({ checks, complete }: AutomatedChecksPanelProps) {
  return (
    <section className="group bg-gradient-to-br from-white to-[#fafafa] border-2 border-[#d9d9d9] hover:border-[#e60028] rounded-3xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2.5 bg-gradient-to-br from-[#e60028] to-[#ff1744] rounded-xl shadow-lg">
          <Activity className="w-5 h-5 text-white" />
        </div>
        <h3 className="font-bold text-lg text-[#000000]">Automated Checks</h3>
        <div className="ml-auto">
          <StatusPill label={complete ? 'Completed' : 'Running'} variant={complete ? 'success' : 'progress'} />
        </div>
      </div>
      <ul className="space-y-3">
        {checks.map((check) => (
          <li key={check.name} className="flex items-center justify-between p-3 border-2 border-[#e5e5e5] hover:border-[#e60028] rounded-xl text-sm transition-all duration-200 hover:shadow-lg">
            <div className="flex items-start gap-2 text-[#000000]">
              <CheckCircle2 className="w-5 h-5 text-[#e60028] flex-shrink-0 mt-0.5" />
              <span>
                {check.name}
                {check.score != null && <span className="ml-2 text-xs text-[#5a5a5a]">(Score: {check.score})</span>}
                {check.note && <span className="ml-2 text-xs text-[#f57f17]">{check.note}</span>}
              </span>
            </div>
            <StatusPill label={check.status} variant={STATUS_VARIANT[check.status]} />
          </li>
        ))}
      </ul>
      {checks.length === 0 && (
        <p className="text-sm text-[#5a5a5a]">Waiting for checks to start...</p>
      )}
      <div className="mt-6 p-3 bg-white border border-[#e5e5e5] rounded-xl">
        <p className="text-xs text-[#5a5a5a] flex items-center gap-2">
          <Clock className="w-4 h-4 text-[#e60028]" />
          Runs automatically after submission
        </p>
      </div>
    </section>
  );
}
