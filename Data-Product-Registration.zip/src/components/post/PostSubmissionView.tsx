import { TrendingUp, Sparkles } from 'lucide-react';
import type { Check, Review, SubmissionState } from '../../lib/mockApi';
import { ConfirmationCard } from './ConfirmationCard';
import { AutomatedChecksPanel } from './AutomatedChecksPanel';
import { ReviewDashboard } from './ReviewDashboard';
import { CertificationPipeline } from './CertificationPipeline';

interface PostSubmissionViewProps {
  submission: SubmissionState | null;
  checks: Check[];
  checksComplete: boolean;
  reviews: Review[];
}

/**
 * P-05: PostSubmissionView — Composite view that assembles all
 * post-submission components into the dashboard layout.
 */
export function PostSubmissionView({ submission, checks, checksComplete, reviews }: PostSubmissionViewProps) {
  if (!submission) return null;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="mb-10">
        <div className="flex items-center gap-3 mb-3">
          <div className="p-3 bg-gradient-to-br from-[#e60028] to-[#ff1744] rounded-2xl shadow-lg">
            <TrendingUp className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-4xl font-bold text-[#000000]">Submission Dashboard</h1>
            <p className="text-[#5a5a5a] mt-1">Track your data product registration progress.</p>
          </div>
        </div>
      </div>

      <ConfirmationCard
        trackingId={submission.trackingId}
        submittedAt={submission.submittedAt}
        eta={submission.eta}
      />

      <div className="grid grid-cols-2 gap-6">
        <AutomatedChecksPanel checks={checks} complete={checksComplete} />
        <ReviewDashboard reviews={reviews} />
      </div>

      <CertificationPipeline checksComplete={checksComplete} />

      {/* Post-Publish Lifecycle */}
      <section className="bg-gradient-to-br from-[#e60028]/5 to-white border-2 border-[#ffcccc] rounded-3xl p-8 shadow-lg animate-fade-in">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-gradient-to-br from-[#e60028] to-[#ff1744] rounded-xl shadow-lg">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <h3 className="font-bold text-2xl text-[#000000]">Post-Publish Lifecycle</h3>
        </div>
        <div className="flex flex-wrap gap-3">
          {['Monitor Quality', 'Consumer Experience', 'Version Updates', 'Change Management', 'Deprecation'].map((item) => (
            <div key={item} className="group px-5 py-3 bg-white border-2 border-[#e5e5e5] hover:border-[#e60028] rounded-full transition-all duration-300 hover:shadow-lg cursor-pointer">
              <span className="text-sm font-semibold text-[#000000] group-hover:text-[#e60028]">{item}</span>
            </div>
          ))}
        </div>
        <div className="mt-6 p-4 bg-white border border-[#e5e5e5] rounded-xl">
          <p className="text-sm text-[#5a5a5a]">
            Lifecycle management per versioning policy and retirement criteria.
          </p>
        </div>
      </section>
    </div>
  );
}
