import { ChevronDown, ChevronUp } from 'lucide-react';

export function RecentTransactions() {
  const transactions = [
    {
      date: 'October 22, 2019 20:36',
      timeAgo: '20 minutes ago',
      merchant: 'GALAXUS.CH',
      icon: '🏪',
      amount: -50.99,
    },
    {
      date: 'October 22, 2019 17:08',
      timeAgo: 'Less than 4h ago',
      merchant: 'MIGROS SA',
      icon: '🛒',
      amount: 3500.24,
    },
  ];

  return (
    <section className="bg-white rounded-3xl p-8">
      <h2 className="text-xl text-gray-600 mb-6">Recent transactions</h2>
      
      <div className="space-y-6">
        {transactions.map((transaction, index) => (
          <div key={index} className="space-y-2">
            <div className="flex items-center justify-between text-sm text-gray-500">
              <span>{transaction.date}</span>
              <span>{transaction.timeAgo}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center text-xl">
                  {transaction.icon}
                </div>
                <span className="text-lg font-medium">{transaction.merchant}</span>
              </div>
              
              <div className={`flex items-center gap-2 ${
                transaction.amount > 0 ? 'text-green-600' : 'text-[#c93838]'
              }`}>
                {transaction.amount > 0 ? (
                  <ChevronUp className="w-5 h-5" />
                ) : (
                  <ChevronDown className="w-5 h-5" />
                )}
                <span className="text-lg font-medium">
                  CHF {Math.abs(transaction.amount).toFixed(2)}
                </span>
              </div>
            </div>

            {index < transactions.length - 1 && (
              <div className="border-t border-gray-100 mt-6"></div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
