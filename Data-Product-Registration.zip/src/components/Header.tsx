import { Save, Send, Sparkles } from 'lucide-react';

export function Header() {
  return (
    <header className="flex items-center justify-between pb-6 mb-8 relative">
      {/* Decorative gradient line */}
      <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-[#e60028] via-[#ff1744] to-transparent"></div>

      <div className="flex items-baseline gap-4 animate-fade-in">
        <div className="relative">
          <span className="text-3xl font-bold text-[#e60028] tracking-tight">UBS</span>
          <div className="absolute -top-1 -right-1 w-2 h-2 bg-[#e60028] rounded-full animate-pulse"></div>
        </div>
        <div className="flex flex-col">
          <span className="text-xs text-[#5a5a5a] uppercase font-bold tracking-wider">WMA Data Platform</span>
          <span className="text-xs text-[#8c8c8c] flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            Registration Portal
          </span>
        </div>
      </div>
      <div className="flex gap-3 animate-fade-in">
        <button className="group px-6 py-2.5 border-2 border-[#000000] rounded-full text-sm font-semibold hover:bg-[#000000] hover:text-white transition-all duration-300 shadow-sm hover:shadow-md flex items-center gap-2">
          <Save className="w-4 h-4 group-hover:rotate-12 transition-transform" />
          Save Draft
        </button>
        <button className="group px-6 py-2.5 bg-gradient-to-r from-[#e60028] to-[#ff1744] text-white rounded-full text-sm font-semibold hover:shadow-xl hover:shadow-red-200 transition-all duration-300 hover:scale-105 flex items-center gap-2">
          <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          Submit
        </button>
      </div>
    </header>
  );
}
