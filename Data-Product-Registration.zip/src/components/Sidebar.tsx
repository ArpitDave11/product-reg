import ubsLogo from 'figma:asset/00ac1239b9b421f7eee8b4e260132b1ac860676a.png';
import { Sparkles } from 'lucide-react';
import { StepperItem, StatusPill } from './atoms';
import type { StepInfo, StepStatus } from './atoms';
import type { AppPhase } from '../hooks/useAppState';

const STEPS: StepInfo[] = [
  { id: 1, title: 'Product Identity', sub: 'Name, type, domain' },
  { id: 2, title: 'Ownership', sub: 'Contacts & support' },
  { id: 3, title: 'Connect', sub: 'Source & entitlements' },
  { id: 4, title: 'KDE Semantics', sub: 'Business metadata' },
  { id: 5, title: 'Scope & DQ', sub: 'Fitness & quality rules' },
  { id: 6, title: 'Data Contract', sub: 'Agreement & access' },
  { id: 7, title: 'Lineage', sub: 'Sources & transformations' },
  { id: 8, title: 'Sensitivity', sub: 'Policy & compliance' },
  { id: 9, title: 'AI Readiness', sub: 'Optional analytics' },
  { id: 10, title: 'Submit', sub: 'Attestations & review' },
];

interface SidebarProps {
  currentStep: number;
  onStepClick: (step: number) => void;
  phase: AppPhase;
  hasErrors: boolean;
}

function getStepStatus(stepId: number, currentStep: number, hasErrors: boolean): StepStatus {
  if (stepId === currentStep && hasErrors) return 'error';
  if (stepId === currentStep) return 'active';
  if (stepId < currentStep) return 'completed';
  return 'upcoming';
}

/**
 * Sidebar — Interactive step navigation with UBS branding.
 * Receives currentStep and phase as props for dynamic behavior.
 */
export function Sidebar({ currentStep, onStepClick, phase, hasErrors }: SidebarProps) {
  const totalSteps = STEPS.length;
  const completedSteps = phase === 'submitted' ? totalSteps : currentStep - 1;
  const pct = Math.round((completedSteps / totalSteps) * 100);
  const circumference = 2 * Math.PI * 56; // r=56

  return (
    <div className="w-80 bg-gradient-to-br from-[#fafafa] to-[#f4f4f4] border-r border-[#d9d9d9] p-6 flex flex-col overflow-y-auto shadow-lg">
      {/* UBS Logo */}
      <div className="flex items-center gap-2 mb-12 animate-fade-in">
        <img src={ubsLogo} alt="UBS" style={{ height: '54px' }} className="flex-shrink-0" />
        <span className="flex flex-col text-[#e60028]">
          <span className="text-xl font-bold text-[#000000]">Data</span>
          <span className="text-sm font-semibold">Product Registration</span>
        </span>
      </div>

      {/* Progress Circle */}
      <div className="mb-8 animate-fade-in">
        <div className="relative w-32 h-32 mx-auto">
          <svg className="transform -rotate-90 w-32 h-32">
            <circle cx="64" cy="64" r="56" stroke="#f4f4f4" strokeWidth="8" fill="none" />
            <circle
              cx="64" cy="64" r="56"
              stroke="url(#sidebarGradient)" strokeWidth="8" fill="none"
              strokeDasharray={`${(completedSteps / totalSteps) * circumference} ${circumference}`}
              strokeLinecap="round"
              className="transition-all duration-700"
            />
            <defs>
              <linearGradient id="sidebarGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#e60028" />
                <stop offset="100%" stopColor="#ff1744" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center flex-col">
            <span className="text-3xl font-bold text-[#e60028]">{pct}%</span>
            <span className="text-xs text-[#5a5a5a]">Complete</span>
          </div>
        </div>
      </div>

      {/* Registration Steps */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-4">
          <h3 className="text-xs text-[#5a5a5a] uppercase font-bold tracking-wider">Registration Steps</h3>
          <div className="flex-1 h-px bg-gradient-to-r from-[#d9d9d9] to-transparent"></div>
        </div>
        <ol className="space-y-2 relative">
          {/* Connector line */}
          <div className="absolute left-[13px] top-6 bottom-6 w-0.5 bg-gradient-to-b from-[#e60028] via-[#d9d9d9] to-[#d9d9d9]"></div>

          {STEPS.map((step) => (
            <StepperItem
              key={step.id}
              step={step}
              status={phase === 'submitted' ? 'completed' : getStepStatus(step.id, currentStep, hasErrors)}
              onClick={() => phase !== 'submitted' && onStepClick(step.id)}
            />
          ))}
        </ol>
      </div>

      {/* Status */}
      <div className="mb-6 animate-fade-in">
        <div className="flex items-center gap-2 mb-4">
          <h3 className="text-xs text-[#5a5a5a] uppercase font-bold tracking-wider">Status</h3>
          <div className="flex-1 h-px bg-gradient-to-r from-[#d9d9d9] to-transparent"></div>
        </div>
        <div className="space-y-3">
          <StatusPill
            label={phase === 'submitted' ? 'Submitted' : 'In Progress'}
            variant={phase === 'submitted' ? 'success' : 'progress'}
          />
          <div className="text-sm text-[#5a5a5a] text-center font-medium">
            {phase === 'submitted'
              ? 'Registration submitted'
              : `Step ${currentStep} of ${totalSteps} \u2022 ${totalSteps - completedSteps} Remaining`}
          </div>
        </div>
      </div>

      {/* Optional */}
      <div className="animate-fade-in">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-4 h-4 text-[#e60028]" />
          <h3 className="text-xs text-[#5a5a5a] uppercase font-bold tracking-wider">Optional Features</h3>
        </div>
        <div className="border-2 border-dashed border-[#e5e5e5] rounded-xl p-4 bg-gradient-to-br from-white to-[#fafafa] hover:border-[#e60028] hover:shadow-lg transition-all duration-300">
          <div className="font-semibold text-sm mb-1 text-[#000000]">Enterprise Catalog</div>
          <div className="text-xs text-[#5a5a5a] mb-4">Sync after WMA registration</div>
          <label className="flex items-center gap-3 cursor-pointer group">
            <div className="relative">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-[#d9d9d9] rounded-full peer-checked:bg-gradient-to-r peer-checked:from-[#e60028] peer-checked:to-[#ff1744] transition-all duration-300 shadow-inner"></div>
              <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 peer-checked:translate-x-5 shadow-md"></div>
            </div>
            <span className="text-sm text-[#5a5a5a] group-hover:text-[#000000] transition-colors">Register after publish</span>
          </label>
        </div>
      </div>
    </div>
  );
}
