import { Send } from 'lucide-react';
import { Field } from '../atoms';
import { Badge } from '../atoms';
import { CardWrapper } from '../atoms';
import type { StepFormProps } from './StepFormProps';

/**
 * S-10: Step10Submit — Final attestations before submission.
 * Fields: accuracyAttest, ownershipAttest, policyAttest, additionalNotes.
 */
export function Step10Submit({ data, onUpdate, errors, warnings }: StepFormProps) {
  const v = (field: string) => (typeof data[field] === 'string' ? data[field] as string : '');
  const b = (field: string) => data[field] === true;

  return (
    <CardWrapper>
      <div className="flex items-start justify-between mb-8">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-gradient-to-br from-[#e60028]/10 to-[#ff1744]/10 rounded-xl group-hover:scale-110 transition-transform">
            <Send className="w-6 h-6 text-[#e60028]" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-[#000000] mb-2">Step 10: Attestations & Submit</h2>
            <p className="text-sm text-[#5a5a5a]">Confirm accuracy and submit for review.</p>
          </div>
        </div>
        <Badge variant="required" />
      </div>
      <div className="grid grid-cols-1 gap-4">
        <Field label="Accuracy Attestation" value={b('accuracyAttest')} onChange={(val) => onUpdate('accuracyAttest', val)} type="checkbox" placeholder="I attest that the information provided is accurate and complete" error={errors.accuracyAttest} warning={warnings.accuracyAttest} />
        <Field label="Ownership Attestation" value={b('ownershipAttest')} onChange={(val) => onUpdate('ownershipAttest', val)} type="checkbox" placeholder="I confirm that I am the authorized owner of this data product" error={errors.ownershipAttest} warning={warnings.ownershipAttest} />
        <Field label="Policy Attestation" value={b('policyAttest')} onChange={(val) => onUpdate('policyAttest', val)} type="checkbox" placeholder="I confirm compliance with all applicable data governance policies" error={errors.policyAttest} warning={warnings.policyAttest} />
        <Field label="Additional Notes" value={v('additionalNotes')} onChange={(val) => onUpdate('additionalNotes', val)} type="textarea" placeholder="Any additional information for reviewers" error={errors.additionalNotes} warning={warnings.additionalNotes} />
      </div>
    </CardWrapper>
  );
}
