import { Link2 } from 'lucide-react';
import { Field } from '../atoms';
import { Badge } from '../atoms';
import { CardWrapper } from '../atoms';
import type { StepFormProps } from './StepFormProps';

/**
 * S-03: Step3Connect — Link source system and configure entitlements.
 * Fields: sourceUrl, environment, storageLocation, cidClassification, inputDatasets.
 */
export function Step3Connect({ data, onUpdate, errors, warnings }: StepFormProps) {
  const v = (field: string) => (typeof data[field] === 'string' ? data[field] as string : '');

  return (
    <CardWrapper>
      <div className="flex items-start justify-between mb-8">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-gradient-to-br from-[#e60028]/10 to-[#ff1744]/10 rounded-xl group-hover:scale-110 transition-transform">
            <Link2 className="w-6 h-6 text-[#e60028]" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-[#000000] mb-2">Step 3: Connect to Source & Entitlements</h2>
            <p className="text-sm text-[#5a5a5a]">Link source system and configure entitlements.</p>
          </div>
        </div>
        <Badge variant="required" />
      </div>
      <div className="grid grid-cols-2 gap-6">
        <Field label="Source Application URL" value={v('sourceUrl')} onChange={(val) => onUpdate('sourceUrl', val)} placeholder="https://source-app/" error={errors.sourceUrl} warning={warnings.sourceUrl} />
        <Field label="Environment" value={v('environment')} onChange={(val) => onUpdate('environment', val)} type="select" options={['PROD', 'UAT', 'DEV', 'SIT']} error={errors.environment} warning={warnings.environment} />
        <Field label="Storage Location" value={v('storageLocation')} onChange={(val) => onUpdate('storageLocation', val)} placeholder="adbfs://container@account" error={errors.storageLocation} warning={warnings.storageLocation} />
        <Field label="CID Classification" value={v('cidClassification')} onChange={(val) => onUpdate('cidClassification', val)} type="select" options={['Red', 'Amber', 'Green']} error={errors.cidClassification} warning={warnings.cidClassification} />
        <Field label="Input Datasets" value={v('inputDatasets')} onChange={(val) => onUpdate('inputDatasets', val)} type="textarea" placeholder="Comma-separated dataset names" error={errors.inputDatasets} warning={warnings.inputDatasets} span2 />
      </div>
    </CardWrapper>
  );
}
