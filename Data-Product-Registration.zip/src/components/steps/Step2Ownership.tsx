import { Users } from 'lucide-react';
import { Field } from '../atoms';
import { Badge } from '../atoms';
import { CardWrapper } from '../atoms';
import type { StepFormProps } from './StepFormProps';

/**
 * S-02: Step2Ownership — Define ownership, contacts and support information.
 * Fields: owner, backupOwner, itLead, dataSteward, distributionList, supportHours.
 */
export function Step2Ownership({ data, onUpdate, errors, warnings }: StepFormProps) {
  const v = (field: string) => (typeof data[field] === 'string' ? data[field] as string : '');

  return (
    <CardWrapper>
      <div className="flex items-start justify-between mb-8">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-gradient-to-br from-[#e60028]/10 to-[#ff1744]/10 rounded-xl group-hover:scale-110 transition-transform">
            <Users className="w-6 h-6 text-[#e60028]" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-[#000000] mb-2">Step 2: Ownership & Contacts</h2>
            <p className="text-sm text-[#5a5a5a]">Define ownership, contacts and support information.</p>
          </div>
        </div>
        <Badge variant="required" />
      </div>
      <div className="grid grid-cols-2 gap-6">
        <Field label="Data Product Owner" value={v('owner')} onChange={(val) => onUpdate('owner', val)} placeholder="owner@ubs.com" error={errors.owner} warning={warnings.owner} />
        <Field label="Backup Owner" value={v('backupOwner')} onChange={(val) => onUpdate('backupOwner', val)} placeholder="backup@ubs.com" error={errors.backupOwner} warning={warnings.backupOwner} />
        <Field label="IT Lead" value={v('itLead')} onChange={(val) => onUpdate('itLead', val)} placeholder="itlead@ubs.com" error={errors.itLead} warning={warnings.itLead} />
        <Field label="Data Steward" value={v('dataSteward')} onChange={(val) => onUpdate('dataSteward', val)} placeholder="steward@ubs.com" error={errors.dataSteward} warning={warnings.dataSteward} />
        <Field label="Distribution List" value={v('distributionList')} onChange={(val) => onUpdate('distributionList', val)} placeholder="team-dl@ubs.com" error={errors.distributionList} warning={warnings.distributionList} />
        <Field label="Support Hours" value={v('supportHours')} onChange={(val) => onUpdate('supportHours', val)} type="select" options={['24/7', 'Business Hours (US)', 'Business Hours (APAC)', 'Business Hours (EMEA)', 'From AppDir']} error={errors.supportHours} warning={warnings.supportHours} />
      </div>
    </CardWrapper>
  );
}
