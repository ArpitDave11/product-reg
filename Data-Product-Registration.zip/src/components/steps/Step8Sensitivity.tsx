import { Shield } from 'lucide-react';
import { Field } from '../atoms';
import { Badge } from '../atoms';
import { CardWrapper } from '../atoms';
import type { StepFormProps } from './StepFormProps';

/**
 * S-08: Step8Sensitivity — Data classification, retention, and permitted uses.
 * Fields: classification, retentionReq, permittedUses, restrictedRegions, encryptionReq.
 */
export function Step8Sensitivity({ data, onUpdate, errors, warnings }: StepFormProps) {
  const v = (field: string) => (typeof data[field] === 'string' ? data[field] as string : '');

  return (
    <CardWrapper>
      <div className="flex items-start justify-between mb-8">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-gradient-to-br from-[#e60028]/10 to-[#ff1744]/10 rounded-xl group-hover:scale-110 transition-transform">
            <Shield className="w-6 h-6 text-[#e60028]" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-[#000000] mb-2">Step 8: Sensitivity & Policy</h2>
            <p className="text-sm text-[#5a5a5a]">Define data classification and compliance requirements.</p>
          </div>
        </div>
        <Badge variant="required" />
      </div>
      <div className="grid grid-cols-2 gap-6">
        <Field label="Classification" value={v('classification')} onChange={(val) => onUpdate('classification', val)} type="select" options={['Public', 'Internal', 'Confidential', 'Restricted']} error={errors.classification} warning={warnings.classification} />
        <Field label="Retention Requirement" value={v('retentionReq')} onChange={(val) => onUpdate('retentionReq', val)} type="select" options={['1 year', '3 years', '5 years', '7 years', '10 years', 'Indefinite']} error={errors.retentionReq} warning={warnings.retentionReq} />
        <Field label="Permitted Uses" value={v('permittedUses')} onChange={(val) => onUpdate('permittedUses', val)} type="textarea" placeholder="Describe permitted data usage" error={errors.permittedUses} warning={warnings.permittedUses} span2 />
        <Field label="Restricted Regions" value={v('restrictedRegions')} onChange={(val) => onUpdate('restrictedRegions', val)} placeholder="e.g. EU, APAC" error={errors.restrictedRegions} warning={warnings.restrictedRegions} />
        <Field label="Encryption Required" value={v('encryptionReq')} onChange={(val) => onUpdate('encryptionReq', val)} type="select" options={['At rest', 'In transit', 'Both', 'None']} error={errors.encryptionReq} warning={warnings.encryptionReq} />
      </div>
    </CardWrapper>
  );
}
