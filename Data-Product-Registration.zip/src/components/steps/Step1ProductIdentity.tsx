import { Package } from 'lucide-react';
import { Field } from '../atoms';
import { Badge } from '../atoms';
import { CardWrapper } from '../atoms';
import type { StepFormProps } from './StepFormProps';

/**
 * S-01: Step1ProductIdentity — Define core product identity and characteristics.
 * Fields: productName, productType, businessDomain, shortDescription,
 *         longDescription, businessPurpose, keyKpis, consumerPersonas, sourceSystem.
 */
export function Step1ProductIdentity({ data, onUpdate, errors, warnings }: StepFormProps) {
  const v = (field: string) => (typeof data[field] === 'string' ? data[field] as string : '');

  return (
    <CardWrapper>
      <div className="flex items-start justify-between mb-8">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-gradient-to-br from-[#e60028]/10 to-[#ff1744]/10 rounded-xl group-hover:scale-110 transition-transform">
            <Package className="w-6 h-6 text-[#e60028]" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-[#000000] mb-2">Step 1: Product Identity</h2>
            <p className="text-sm text-[#5a5a5a]">Define core product identity and characteristics.</p>
          </div>
        </div>
        <Badge variant="required" />
      </div>
      <div className="grid grid-cols-2 gap-6">
        <Field label="Product Name" value={v('productName')} onChange={(val) => onUpdate('productName', val)} placeholder="e.g. WMA Account" error={errors.productName} warning={warnings.productName} />
        <Field label="Product Type" value={v('productType')} onChange={(val) => onUpdate('productType', val)} type="select" options={['Composite Data Product', 'Source-Aligned', 'Consumer-Aligned', 'Aggregate']} error={errors.productType} warning={warnings.productType} />
        <Field label="Business Domain" value={v('businessDomain')} onChange={(val) => onUpdate('businessDomain', val)} type="select" options={['Account', 'Client', 'Transaction', 'Portfolio', 'Market Data', 'Reference']} error={errors.businessDomain} warning={warnings.businessDomain} />
        <Field label="Short Description" value={v('shortDescription')} onChange={(val) => onUpdate('shortDescription', val)} placeholder="Brief description" error={errors.shortDescription} warning={warnings.shortDescription} />
        <Field label="Long Description" value={v('longDescription')} onChange={(val) => onUpdate('longDescription', val)} type="textarea" placeholder="Detailed business description" error={errors.longDescription} warning={warnings.longDescription} span2 />
        <Field label="Business Purpose" value={v('businessPurpose')} onChange={(val) => onUpdate('businessPurpose', val)} type="textarea" placeholder="Purpose & objectives" error={errors.businessPurpose} warning={warnings.businessPurpose} span2 />
        <Field label="Key KPIs / Metrics" value={v('keyKpis')} onChange={(val) => onUpdate('keyKpis', val)} placeholder="KPIs linked to measures" error={errors.keyKpis} warning={warnings.keyKpis} />
        <Field label="Consumer Personas" value={v('consumerPersonas')} onChange={(val) => onUpdate('consumerPersonas', val)} placeholder="Data Scientist, Analytics" error={errors.consumerPersonas} warning={warnings.consumerPersonas} />
        <Field label="Source System" value={v('sourceSystem')} onChange={(val) => onUpdate('sourceSystem', val)} type="select" options={['SPP', 'CRM', 'Core Banking', 'Data Lake', 'Other']} error={errors.sourceSystem} warning={warnings.sourceSystem} />
      </div>
    </CardWrapper>
  );
}
