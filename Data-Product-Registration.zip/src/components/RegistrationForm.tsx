import { Package, ArrowRight } from 'lucide-react';
import type { StepData } from '../lib/mockApi';
import {
  Step1ProductIdentity,
  Step2Ownership,
  Step3Connect,
  Step4KdeSemantics,
  Step5ScopeDq,
  Step6DataContract,
  Step7Lineage,
  Step8Sensitivity,
  Step9AiReadiness,
  Step10Submit,
} from './steps';

interface RegistrationFormProps {
  currentStep: number;
  stepData: Record<string, StepData>;
  errors: Record<string, string>;
  warnings: Record<string, string>;
  onUpdate: (field: string, value: string | boolean) => void;
  onBack: () => void;
  onContinue: () => void;
  onSubmit: () => void;
  isLastStep: boolean;
}

const STEP_COMPONENTS = [
  Step1ProductIdentity,
  Step2Ownership,
  Step3Connect,
  Step4KdeSemantics,
  Step5ScopeDq,
  Step6DataContract,
  Step7Lineage,
  Step8Sensitivity,
  Step9AiReadiness,
  Step10Submit,
];

/**
 * RegistrationForm — Renders the active step form with Back/Continue buttons.
 * Routes to the correct step component based on currentStep.
 */
export function RegistrationForm({
  currentStep,
  stepData,
  errors,
  warnings,
  onUpdate,
  onBack,
  onContinue,
  onSubmit,
  isLastStep,
}: RegistrationFormProps) {
  const StepComponent = STEP_COMPONENTS[currentStep - 1];
  const stepKey = `step${currentStep}`;
  const data = stepData[stepKey] || {};
  const totalSteps = STEP_COMPONENTS.length;

  return (
    <div className="space-y-8 max-w-6xl">
      {/* Page Title */}
      <div className="mb-10 animate-fade-in">
        <div className="flex items-center gap-3 mb-3">
          <div className="p-3 bg-gradient-to-br from-[#e60028] to-[#ff1744] rounded-2xl shadow-lg">
            <Package className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-4xl font-bold text-[#000000]">Register Data Product</h1>
            <p className="text-[#5a5a5a] mt-1">Simple, guided registration aligned to WMA governance.</p>
          </div>
        </div>
        {/* Progress bar */}
        <div className="mt-6 bg-[#f4f4f4] rounded-full h-2 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#e60028] to-[#ff1744] transition-all duration-700 shadow-lg"
            style={{ width: `${(currentStep / totalSteps) * 100}%` }}
          ></div>
        </div>
      </div>

      <StepComponent
        data={data}
        onUpdate={onUpdate}
        errors={errors}
        warnings={warnings}
      />

      <div className="flex justify-end gap-4 mt-8">
        {currentStep > 1 && (
          <button
            onClick={onBack}
            className="group px-6 py-3 border-2 border-[#000000] rounded-full text-sm font-semibold hover:bg-[#000000] hover:text-white transition-all duration-300 shadow-sm hover:shadow-lg flex items-center gap-2"
          >
            Back
          </button>
        )}
        {isLastStep ? (
          <button
            onClick={onSubmit}
            className="group px-6 py-3 bg-gradient-to-r from-[#e60028] to-[#ff1744] text-white rounded-full text-sm font-semibold hover:shadow-xl hover:shadow-red-200 transition-all duration-300 hover:scale-105 flex items-center gap-2"
          >
            Submit Registration
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        ) : (
          <button
            onClick={onContinue}
            className="group px-6 py-3 bg-gradient-to-r from-[#e60028] to-[#ff1744] text-white rounded-full text-sm font-semibold hover:shadow-xl hover:shadow-red-200 transition-all duration-300 hover:scale-105 flex items-center gap-2"
          >
            Save & Continue
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        )}
      </div>
    </div>
  );
}
