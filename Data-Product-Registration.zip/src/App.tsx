import { useEffect, useCallback, useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { RegistrationForm } from './components/RegistrationForm';
import { PostSubmissionView } from './components/post';
import { Toast, ApiLogPanel, LoadingOverlay } from './components/atoms';
import { useAppState } from './hooks/useAppState';
import { useAutoSave } from './hooks/useAutoSave';
import { usePolling } from './hooks/usePolling';
import { handleSaveAndContinue, handleSubmit, handleAppInit } from './hooks/handlers';

export default function App() {
  const state = useAppState();
  const [logVisible, setLogVisible] = useState(false);

  // O-02: Auto-save on field changes
  useAutoSave({
    store: state.store,
    logger: state.logger,
    currentStep: state.currentStep,
    stepData: state.stepData,
    addToast: state.addToast,
  });

  // O-03: Poll checks/reviews after submission
  const { checks, checksComplete, reviews } = usePolling({
    store: state.store,
    logger: state.logger,
    active: state.phase === 'submitted',
  });

  // O-06: Initialize on mount
  useEffect(() => {
    handleAppInit(state.store, state.logger, state.addToast, state.setStepData, state.setCurrentStep);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // O-04: Save and continue handler
  const onContinue = useCallback(() => {
    handleSaveAndContinue(
      state.store, state.logger, state.currentStep, state.stepData,
      state.addToast, state.setErrors, state.setWarnings,
      state.setCurrentStep, state.setLoading, state.setLoadingMessage,
    );
  }, [state.store, state.logger, state.currentStep, state.stepData,
      state.addToast, state.setErrors, state.setWarnings,
      state.setCurrentStep, state.setLoading, state.setLoadingMessage]);

  // O-05: Submit handler
  const onSubmit = useCallback(() => {
    handleSubmit(
      state.store, state.logger, state.stepData,
      state.addToast, state.setErrors, state.setWarnings,
      state.setLoading, state.setLoadingMessage, state.setPhase,
    );
  }, [state.store, state.logger, state.stepData,
      state.addToast, state.setErrors, state.setWarnings,
      state.setLoading, state.setLoadingMessage, state.setPhase]);

  const onBack = useCallback(() => {
    if (state.currentStep > 1) {
      state.setCurrentStep(state.currentStep - 1);
      state.setErrors({});
      state.setWarnings({});
    }
  }, [state.currentStep, state.setCurrentStep, state.setErrors, state.setWarnings]);

  const hasErrors = Object.keys(state.errors).length > 0;

  return (
    <>
    <div className="flex min-h-screen bg-gradient-to-br from-white via-[#fafafa] to-[#f4f4f4] relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-gradient-to-br from-[#e60028]/5 to-transparent rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-1/3 w-[600px] h-[600px] bg-gradient-to-tr from-[#ff1744]/3 to-transparent rounded-full blur-3xl pointer-events-none"></div>

      <Sidebar
        currentStep={state.currentStep}
        onStepClick={state.setCurrentStep}
        phase={state.phase}
        hasErrors={hasErrors}
      />

      <div className="flex-1 relative z-10">
        <div className="max-w-7xl mx-auto p-10">
          {state.phase === 'form' ? (
            <RegistrationForm
              currentStep={state.currentStep}
              stepData={state.stepData}
              errors={state.errors}
              warnings={state.warnings}
              onUpdate={state.updateField}
              onBack={onBack}
              onContinue={onContinue}
              onSubmit={onSubmit}
              isLastStep={state.currentStep === 10}
            />
          ) : (
            <PostSubmissionView
              submission={state.store.submission}
              checks={checks}
              checksComplete={checksComplete}
              reviews={reviews}
            />
          )}
        </div>
      </div>

      <Toast toasts={state.toasts} onDismiss={state.dismissToast} />
      <LoadingOverlay visible={state.loading} message={state.loadingMessage} />
    </div>
    <ApiLogPanel logs={state.apiLog} visible={logVisible} onToggle={() => setLogVisible((v) => !v)} />
    </>
  );
}
