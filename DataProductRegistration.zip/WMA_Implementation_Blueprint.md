# WMA Data Product Registration — Stage-by-Stage Developer Instructions

> **Purpose of this document:** These are the exact instructions to hand to a developer for each stage. Every gotcha, every common mistake, every verification step is documented. Follow these in order, verify each gate before moving on, and you get 100% working code.

---

## HOW TO USE THIS DOCUMENT

Each stage has:
- **OBJECTIVE** — What you're building and why
- **PREREQUISITE GATE** — What must be true before you start
- **EXACT FILES** — What to create/modify, in what order
- **CRITICAL RULES** — Things that WILL cause bugs if ignored
- **GOTCHAS** — Non-obvious traps specific to this stage
- **WIRING INSTRUCTIONS** — How this stage connects to others
- **VERIFICATION GATE** — Tests that MUST pass before moving to next stage. Do NOT proceed if any fail.

---

## STAGE 1: Project Setup + Mock Infrastructure

### OBJECTIVE
Get MSW (Mock Service Worker) running so every subsequent stage has fake APIs to develop against. After this stage, the app still looks identical — but the mock plumbing is ready underneath.

### PREREQUISITE GATE
```
□ Project runs with `npm run dev` → wizard UI renders on localhost:3000
□ No console errors
```

### EXACT FILES TO CREATE (in this order)

**Order matters.** Each file depends on the ones above it.

```
1. .env                         ← environment variables
2. src/config/apiConfig.ts      ← API URLs + isMockMode()
3. src/api/types.ts             ← all TypeScript interfaces
4. src/mocks/mockData.ts        ← sample datasets + products
5. src/mocks/handlers.ts        ← MSW request handlers
6. src/mocks/browser.ts         ← MSW worker setup
```

Then modify:
```
7. src/main.tsx                 ← add async init with MSW start
```

### CRITICAL RULES

**Rule 1: Install MSW correctly**
```bash
npm install msw --save-dev
npx msw init public/ --save
```
The second command creates `public/mockServiceWorker.js`. Without this file, MSW cannot intercept requests in the browser. If you skip this, you get silent failures — API calls go to the real URLs (which don't exist locally) and you get network errors with no useful message.

**Rule 2: MSW version matters**
Use MSW v2 syntax (not v1). The import paths changed:
```typescript
// ✅ CORRECT (MSW v2)
import { http, HttpResponse } from "msw";
import { setupWorker } from "msw/browser";

// ❌ WRONG (MSW v1 — will not compile)
import { rest } from "msw";
import { setupWorker } from "msw";
```

**Rule 3: Handler URL matching must include the full base URL**
MSW matches against the FULL URL the browser sees, not just the path:
```typescript
// ✅ CORRECT — full URL
http.get("http://127.0.0.1:8000/metaq-api/health", () => { ... })
http.get("https://dpas.dmeshdev.azpriv-cloud.ubs.net/v1/dataproducts", () => { ... })

// ❌ WRONG — relative path (MSW won't match this)
http.get("/metaq-api/health", () => { ... })
```

**BETTER APPROACH:** Read the base URLs from `apiConfig.ts` so handlers stay in sync:
```typescript
import { API_CONFIG } from "../config/apiConfig";
const METAQ = API_CONFIG.metaq.baseUrl;
const DPAS = API_CONFIG.dpas.baseUrl;

http.get(`${METAQ}/health`, () => { ... })
http.get(`${DPAS}/dataproducts`, () => { ... })
```

**Rule 4: MSW must start BEFORE React renders**
The `main.tsx` must await MSW worker start before calling `createRoot().render()`. If React renders first, any component that fetches data on mount will fire before MSW is ready, causing race conditions.

```typescript
// ✅ CORRECT
async function initApp() {
  if (import.meta.env.VITE_USE_MOCKS === "true") {
    const { worker } = await import("./mocks/browser");
    await worker.start({ onUnhandledRequest: "bypass" });
  }
  createRoot(document.getElementById("root")!).render(<App />);
}
initApp();

// ❌ WRONG — MSW starts in parallel with render
if (import.meta.env.VITE_USE_MOCKS === "true") {
  import("./mocks/browser").then(({ worker }) => worker.start());
}
createRoot(document.getElementById("root")!).render(<App />);
```

**Rule 5: `onUnhandledRequest: "bypass"` is mandatory**
Without this, MSW warns on every request it doesn't have a handler for — including Vite HMR websocket, favicon, CSS files, etc. The console becomes unusable.

### GOTCHAS

**Gotcha 1: `.env` variables must start with `VITE_`**
Vite only exposes environment variables prefixed with `VITE_` to the client. If you name it `USE_MOCKS=true`, it will be `undefined` in the browser.

**Gotcha 2: `.env` changes require dev server restart**
After creating or editing `.env`, you must stop and restart `npm run dev`. Vite reads `.env` at startup only.

**Gotcha 3: Vite dev server runs on port 3000**
The existing `vite.config.ts` sets `server.port: 3000` (not the default 5173). All redirect URIs and CORS configs must use `http://localhost:3000`.

**Gotcha 4: MSW POST handler must parse the body correctly**
```typescript
// ✅ CORRECT — cast the parsed body
http.post(`${DPAS}/dataproducts`, async ({ request }) => {
  const body = (await request.json()) as Record<string, unknown>;
  // use body.title, body.owner, etc.
})

// ❌ WRONG — request.body is a ReadableStream, not JSON
http.post(`${DPAS}/dataproducts`, ({ request }) => {
  const body = request.body; // This is a ReadableStream!
})
```

**Gotcha 5: MSW handler for PATCH with path params**
```typescript
// ✅ CORRECT — use :id param
http.patch(`${DPAS}/dataproducts/:id`, async ({ params, request }) => {
  const { id } = params;
  const body = (await request.json()) as Record<string, unknown>;
  // ...
})
```

### MOCK DATA SPECIFICATIONS

**MetaQ datasets — create exactly 8 entries with this variety:**

| # | dataset_title | cidstaterag | Has description? | Has kde? | Has dqobject? |
|---|--------------|-------------|-----------------|----------|--------------|
| 1 | `rcat0100` | `Green` | Yes | Yes | Yes |
| 2 | `wma-account-master` | `Green` | Yes | Yes | No |
| 3 | `client-positions` | `Amber` | Yes | No | No |
| 4 | `trade-executions` | `Red` | Yes | No | Yes |
| 5 | `ref-securities` | `Green` | Yes | Yes | Yes |
| 6 | `market-data-feed` | `Amber` | No | No | No |
| 7 | `compliance-alerts` | `Red` | Yes | No | No |
| 8 | `portfolio-analytics` | `Green` | Yes | Yes | No |

Why this variety? It tests: null field handling, all 3 CID colors, search filtering, and pre-fill with missing data.

**DPAS products — create exactly 3 entries:**

| # | title | status | owner |
|---|-------|--------|-------|
| 1 | `wma-account-master` | `published` | `adam.udovich@ubs.com` |
| 2 | `client-risk-profile` | `draft` | `arpit.dave@ubs.com` |
| 3 | `legacy-reporting-set` | `retired` | `adam.udovich@ubs.com` |

Why? Tests all 3 status values.

**MSW POST handler — must generate realistic response:**
```
On POST /dataproducts:
  1. Read body
  2. Check if title matches any existing mock product → return 409 Conflict
  3. Generate a UUID (use crypto.randomUUID() or hardcode a pattern)
  4. Return 201 with full DataProduct shape including resource_id, resource_iri, created_at, updated_at
  5. Set status to "draft" if not provided
```

**MSW PATCH handler — must validate immutable fields:**
```
On PATCH /dataproducts/:id:
  1. Read body
  2. If body contains "title" → return 422 with message "title is immutable"
  3. If body contains "resource_id" or "created_at" → return 422
  4. Otherwise merge body with existing mock data → return 200
```

### VERIFICATION GATE

After completing Stage 1, run these checks:

```
□ `npm run dev` → app starts, no console errors
□ Browser console shows: "[MSW] Mocking enabled" (or similar MSW startup message)
□ Open Network tab → no failed requests (no red entries)
□ In browser console, run:
    fetch("http://127.0.0.1:8000/metaq-api/health").then(r => r.json()).then(console.log)
    → should print { status: "ok" }
□ In browser console, run:
    fetch("https://dpas.dmeshdev.azpriv-cloud.ubs.net/v1/dataproducts").then(r => r.json()).then(console.log)
    → should print { items: [...], total: 3, page: 1, pageSize: 25 }
□ The wizard UI still looks and works exactly the same as before (no visual changes)
```

**If any check fails → DO NOT proceed to Stage 2. Fix first.**

---

## STAGE 2: Authentication Layer

### OBJECTIVE
Build the MSAL auth integration with a mock bypass. In mock mode, the user is auto-logged-in as the mock user. In real mode, MSAL handles Azure AD login.

### PREREQUISITE GATE
```
□ Stage 1 verification gate passed
□ MSW is running and intercepting requests
```

### EXACT FILES TO CREATE (in this order)

```
1. src/mocks/mockAuth.ts         ← fake user object
2. src/config/authConfig.ts       ← MSAL configuration
3. src/auth/useAuth.ts            ← hook: login, logout, user info
4. src/auth/useAccessToken.ts     ← hook: getToken() function
5. src/auth/MsalProviderWrapper.tsx ← MSAL React provider
6. src/auth/AuthGuard.tsx         ← conditional rendering based on auth state
7. src/components/LoginPage.tsx   ← login screen
8. src/components/LoadingSpinner.tsx ← loading indicator
```

Then modify:
```
9. src/main.tsx                   ← wrap render in providers
```

### CRITICAL RULES

**Rule 1: Mock mode must completely bypass MSAL**
MSAL requires a real Azure AD tenant to initialize. If you try to create a `PublicClientApplication` with fake credentials, it throws errors during initialization. The mock bypass must happen BEFORE any MSAL code runs.

**Pattern:**
```typescript
// In main.tsx — the render tree changes based on mode:

if (isMockMode()) {
  // NO MsalProvider at all — skip it entirely
  render(
    <QueryClientProvider>
      <App />           // App renders directly, no AuthGuard
    </QueryClientProvider>
  );
} else {
  render(
    <MsalProviderWrapper>
      <QueryClientProvider>
        <AuthGuard>
          <App />
        </AuthGuard>
      </QueryClientProvider>
    </MsalProviderWrapper>
  );
}
```

**Rule 2: `useAuth` hook must work in BOTH modes**
The hook should internally check `isMockMode()`:
```typescript
// ✅ CORRECT
export function useAuth() {
  if (isMockMode()) {
    return {
      login: async () => {},
      logout: async () => {},
      user: mockUser,
      isAuthenticated: true,
    };
  }
  // Real MSAL logic below...
  const { instance, accounts } = useMsal();
  // ...
}
```

**Why this matters:** `Header.tsx` will call `useAuth()` to get the user name. If this hook crashes in mock mode (because MSAL context doesn't exist), the entire app breaks.

**Rule 3: `useAccessToken` hook must return a fake token in mock mode**
```typescript
export function useAccessToken() {
  if (isMockMode()) {
    return async () => "mock-bearer-token-for-local-dev";
  }
  // Real MSAL acquireTokenSilent logic...
}
```

**Rule 4: MSAL `PublicClientApplication` must be created OUTSIDE of React**
It's a singleton — creating it inside a component causes re-initialization on every render:
```typescript
// ✅ CORRECT — module-level singleton
const msalInstance = new PublicClientApplication(msalConfig);
export function MsalProviderWrapper({ children }) {
  return <MsalProvider instance={msalInstance}>{children}</MsalProvider>;
}

// ❌ WRONG — creates new instance on every render
export function MsalProviderWrapper({ children }) {
  const msalInstance = new PublicClientApplication(msalConfig); // BUG!
  return <MsalProvider instance={msalInstance}>{children}</MsalProvider>;
}
```

**Rule 5: MSAL `initialize()` must complete before `handleRedirectPromise()`**
MSAL v2 requires explicit initialization:
```typescript
// ✅ CORRECT — await initialize first
await msalInstance.initialize();
await msalInstance.handleRedirectPromise();

// ❌ WRONG — handleRedirectPromise before initialize
await msalInstance.handleRedirectPromise(); // Throws: BrowserAuthError
```

### GOTCHAS

**Gotcha 1: `useMsal()` hook ONLY works inside `<MsalProvider>`**
If you call `useMsal()` in a component that isn't wrapped by `<MsalProvider>`, you get:
```
Error: No provider configured for MsalContext
```
This is why mock mode must NOT use `MsalProvider` at all — and `useAuth` must have the mock bypass BEFORE calling `useMsal()`.

**Gotcha 2: `handleRedirectPromise()` must be called exactly ONCE on page load**
If called multiple times (e.g., in a `useEffect` that re-runs), it can cause infinite redirect loops. Put it in the singleton initialization, not in a component.

**Gotcha 3: The login redirect URL must match Azure AD app registration EXACTLY**
Including trailing slashes. `http://localhost:3000` ≠ `http://localhost:3000/`. This is a remote desktop concern, but document it now.

**Gotcha 4: `import.meta.env` values are always strings**
```typescript
// ❌ WRONG — this is a string comparison bug
if (import.meta.env.VITE_USE_MOCKS) { ... }  // "false" is truthy!

// ✅ CORRECT
if (import.meta.env.VITE_USE_MOCKS === "true") { ... }
```

### WIRING INSTRUCTIONS

**`mockAuth.ts` exports:**
```
mockUser: { name: string, email: string, initials: string }
```

**`useAuth` returns (both modes):**
```
{ login: () => Promise<void>, logout: () => Promise<void>, user: { name, email, initials } | null, isAuthenticated: boolean }
```

**`useAccessToken` returns (both modes):**
```
getToken: () => Promise<string>
```

### VERIFICATION GATE

```
□ App starts → wizard renders immediately (no login screen in mock mode)
□ No console errors related to MSAL
□ Open browser console, run:
    import { useAuth } from './auth/useAuth'
    → no import errors
□ In a React component (or React DevTools), verify useAuth() returns:
    { user: { name: "Arpit Dave", email: "arpit.dave@ubs.com", initials: "AD" }, isAuthenticated: true }
□ The wizard UI still looks identical to before
□ In `.env`, temporarily set VITE_USE_MOCKS=false → app should show LoginPage
    (it won't actually log in — just verify the conditional rendering works)
□ Set VITE_USE_MOCKS back to "true" → wizard appears again
```

---

## STAGE 3: HTTP Client + API Services

### OBJECTIVE
Build the Axios HTTP client and both API service files. After this stage, you can call `dpasService.list()` from the browser console and get mock data back through the full chain: Axios → MSW → mock response.

### PREREQUISITE GATE
```
□ Stage 2 verification gate passed
□ useAccessToken hook returns a token (mock or real)
```

### EXACT FILES TO CREATE (in this order)

```
1. src/api/httpClient.ts     ← Axios instances with interceptor
2. src/api/dpasService.ts    ← DPAS CRUD methods
3. src/api/metaqService.ts   ← MetaQ read methods
```

### CRITICAL RULES

**Rule 1: The request interceptor must handle mock mode**
In mock mode, there's no MSAL instance to call `acquireTokenSilent` on. The interceptor must check:
```typescript
// In the request interceptor:
if (isMockMode()) {
  config.headers.Authorization = "Bearer mock-bearer-token";
  return config;
}
// else: real MSAL token acquisition...
```

**Rule 2: Import the MSAL instance, NOT the hook, in httpClient**
`httpClient.ts` is NOT a React component — you cannot use hooks here. Import the singleton directly:
```typescript
// ✅ CORRECT — import the singleton instance
import { msalInstance } from "../auth/MsalProviderWrapper";

// ❌ WRONG — hooks only work inside React components
import { useAccessToken } from "../auth/useAccessToken";
```

**But in mock mode, `msalInstance` doesn't exist** (we skip MsalProvider entirely). So the interceptor must guard:
```typescript
async (config) => {
  if (isMockMode()) {
    config.headers.Authorization = "Bearer mock-token";
    return config;
  }

  // Only access msalInstance in real mode
  const { msalInstance } = await import("../auth/MsalProviderWrapper");
  const account = msalInstance.getActiveAccount();
  // ...
}
```

**Or cleaner approach:** Export `msalInstance` only in real mode; import it lazily.

**Rule 3: Create TWO separate Axios instances**
They have different `baseURL` values. Do NOT use one instance and pass full URLs — that defeats the purpose of `baseURL`:
```typescript
export const metaqClient = axios.create({ baseURL: API_CONFIG.metaq.baseUrl });
export const dpasClient = axios.create({ baseURL: API_CONFIG.dpas.baseUrl });
```

**Rule 4: The response interceptor must extract the error message**
DPAS API returns errors as `{ error: "...", message: "...", timestamp: "..." }`. Without extraction, the user sees Axios's generic "Request failed with status code 422" instead of the useful "The field 'owner' must be a valid UBS email address".
```typescript
// Response error interceptor:
(error) => {
  if (error.response?.data?.message) {
    error.message = error.response.data.message;
  }
  return Promise.reject(error);
}
```

**Rule 5: `dpasService.getById` must extract the ETag header**
```typescript
async getById(id: string) {
  const response = await dpasClient.get(`/dataproducts/${id}`);
  return {
    data: response.data,
    etag: response.headers["etag"] ?? null,   // lowercase "etag"
  };
}
```
**Why lowercase?** Axios normalizes all response header names to lowercase. Even if the server sends `ETag`, Axios stores it as `etag`.

**Rule 6: `dpasService.update` must send If-Match only when etag is provided**
```typescript
async update(id, payload, etag?) {
  const headers: Record<string, string> = {};
  if (etag) {
    headers["If-Match"] = etag;
  }
  const response = await dpasClient.patch(`/dataproducts/${id}`, payload, { headers });
  return response.data;
}
```

**Rule 7: `metaqService.listDatasets` must handle variable response shapes**
The MetaQ API might return a bare array `[{...}, {...}]` or a wrapped object `{ items: [...], count: 100 }`. Handle both:
```typescript
async listDatasets(params?) {
  const response = await metaqClient.get("/datasets", { params });
  const data = response.data;
  return Array.isArray(data) ? data : (data.items ?? data.results ?? []);
}
```

**Rule 8: `metaqService.getByTitle` must URL-encode the title**
```typescript
async getByTitle(title: string) {
  const response = await metaqClient.get(`/dataset/${encodeURIComponent(title)}`);
  // ...
}
```
Titles like `rcat 0100` (with spaces) break without encoding.

### GOTCHAS

**Gotcha 1: Axios timeout default is 0 (infinite)**
Set an explicit timeout to prevent hanging requests:
```typescript
axios.create({ baseURL: "...", timeout: 30000 })  // 30 seconds
```

**Gotcha 2: MSW intercepts Axios requests correctly — no special config needed**
Axios uses `XMLHttpRequest` under the hood (in the browser). MSW intercepts at the `XMLHttpRequest` level. It just works. You do NOT need to configure Axios adapters or anything special.

**Gotcha 3: Don't add `Content-Type` header globally if you might send FormData later**
For now JSON-only is fine. Just be aware for future file upload features.

### VERIFICATION GATE

Open the browser console on the running app and test each service method:

```javascript
// Test 1: MetaQ health
const { metaqService } = await import('./api/metaqService');
await metaqService.health();
// Expected: { status: "ok" }

// Test 2: MetaQ datasets
const datasets = await metaqService.listDatasets();
console.log(datasets.length);
// Expected: 8 (your mock data count)
console.log(datasets[0].dataset_title);
// Expected: "rcat0100"

// Test 3: MetaQ search
const results = await metaqService.getByTitle("rcat");
console.log(results.length);
// Expected: 1 (or more if multiple titles contain "rcat")

// Test 4: DPAS list
const { dpasService } = await import('./api/dpasService');
const list = await dpasService.list();
console.log(list.items.length);
// Expected: 3
console.log(list.items[0].title);
// Expected: "wma-account-master"

// Test 5: DPAS create
const created = await dpasService.create({
  title: "new-test-product",
  owner: "test@ubs.com",
  source_system_code: "TEST"
});
console.log(created.resource_id);
// Expected: a UUID string
console.log(created.status);
// Expected: "draft"

// Test 6: DPAS create duplicate → should get 409
try {
  await dpasService.create({
    title: "wma-account-master",  // already exists in mock
    owner: "test@ubs.com",
    source_system_code: "TEST"
  });
} catch (e) {
  console.log(e.response.status);
  // Expected: 409
}

// Test 7: DPAS update
const updated = await dpasService.update(
  list.items[0].resource_id,
  { description: "Updated via test" }
);
console.log(updated.description);
// Expected: "Updated via test"

// Test 8: Check Network tab
// All 8 requests above should appear in Network tab
// All should show status 200/201 (except test 6 which is 409)
// All should have "Authorization: Bearer mock-bearer-token" header
```

**All 8 tests must pass. If any fail → fix before Stage 4.**

---

## STAGE 4: Zustand State Management

### OBJECTIVE
Build the central store that holds all 31 form fields and 5 metadata fields. After this stage, you can update form state from the console and see it reflected.

### PREREQUISITE GATE
```
□ Stage 3 verification gate passed
□ api/types.ts has WizardFormState interface defined
```

### EXACT FILES TO CREATE (in this order)

```
1. src/utils/fieldMapping.ts            ← pure functions for payload conversion
2. src/stores/useRegistrationStore.ts   ← Zustand store
3. src/hooks/useFormPersistence.ts      ← localStorage save/restore
```

### CRITICAL RULES

**Rule 1: Store keys must exactly match the field inventory table**
Cross-reference every key in the store with Section B.1 of the Blueprint. If there's a typo (`productname` instead of `productName`), the wiring in Stage 6 will silently fail — the input writes to the wrong key and the value never appears.

**Rule 2: Default values for select fields must match the first `<option>` value exactly**
The existing UI has selects like:
```html
<select>
  <option>PROD</option>
  <option>DEV</option>
</select>
```
The default value in the store must be `"PROD"` (not `"prod"`, not `"Production"`, not `""`). If the store default doesn't match the option text, the select renders with nothing selected after the first re-render.

**Here are all the exact default values for selects (copy these exactly):**

| Store Key | Default | Options |
|-----------|---------|---------|
| `environment` | `"PROD"` | `"PROD"`, `"DEV"`, `"UAT"` |
| `accessControl` | `"Role-Based"` | `"Role-Based"`, `"Attribute-Based"`, `"Group-Based"` |
| `dataScope` | `"Global"` | `"Global"`, `"Regional"`, `"Local"` |
| `refreshFrequency` | `"Real-time"` | `"Real-time"`, `"Hourly"`, `"Daily"`, `"Weekly"` |
| `slaTier` | `"Gold (99.9%)"` | `"Gold (99.9%)"`, `"Silver (99.5%)"`, `"Bronze (99%)"` |
| `dataRetention` | `"7 years"` | `"7 years"`, `"5 years"`, `"3 years"`, `"1 year"` |
| `dataClassification` | `"Highly Confidential"` | `"Highly Confidential"`, `"Confidential"`, `"Internal"`, `"Public"` |
| `containsPII` | `"Yes"` | `"Yes"`, `"No"` |
| `mlFeatureStore` | `"Not Applicable"` | `"Not Applicable"`, `"Enabled"` |
| `vectorEmbeddings` | `"Not Applicable"` | `"Not Applicable"`, `"Supported"` |

**Rule 3: `getStepCompletion` must count select-with-default as filled**
Fields like `environment` and `dataScope` have default values. They should count as "filled" because the user implicitly accepted the default. Only text/textarea/checkbox fields with empty string or `false` should count as unfilled.

**Implementation:** Check if the field is a known select key. If yes and the value is one of the valid options → filled. Or simpler: any non-empty string → filled.

```typescript
const isFilled = (val: unknown): boolean => {
  if (typeof val === "string") return val.trim().length > 0;
  if (typeof val === "boolean") return val === true;
  return val != null;
};
```

This works because all select defaults are non-empty strings.

**Rule 4: `updateFields` must merge shallowly, not replace the entire state**
```typescript
// ✅ CORRECT
updateFields: (fields) => set((state) => ({ ...state, ...fields })),

// ❌ WRONG — this replaces ALL state with just the new fields
updateFields: (fields) => set(fields),
```

**Rule 5: `prefillFromMetaq` must only overwrite fields that have non-null values**
```typescript
prefillFromMetaq: (dataset) => set((state) => ({
  ...state,
  // Only overwrite if MetaQ has a value
  productName: dataset.dataset_title ?? dataset.name ?? state.productName,
  shortDescription: dataset.description ?? state.shortDescription,
  // ... etc
}))
```
If a MetaQ field is `null`, the user's existing input must be preserved.

**Rule 6: `fieldMapping.ts` — toDpasCreatePayload must map `environment` to `source_system_code`**
The DPAS API field `source_system_code` maps to the `environment` select in the form. This is a naming mismatch. Make it explicit:
```typescript
export function toDpasCreatePayload(state: WizardFormState): DataProductCreatePayload {
  return {
    title: state.productName,
    owner: state.owner,
    source_system_code: state.environment,  // "PROD", "DEV", or "UAT"
    description: state.shortDescription || undefined,
  };
}
```

**Rule 7: localStorage persistence must strip functions before serializing**
Zustand stores contain both data and actions. `JSON.stringify` on functions returns `undefined` and corrupts the JSON. Extract only data fields:
```typescript
// ✅ CORRECT — destructure out actions, serialize only data
const { updateFields, prefillFromMetaq, markSavedToDpas, reset,
        getStepCompletion, ...formData } = useRegistrationStore.getState();
localStorage.setItem(KEY, JSON.stringify(formData));
```

**Rule 8: localStorage restore must be wrapped in try-catch**
If the stored JSON is corrupted (user manually edited it, schema changed between versions), parsing will throw. Catch it and start fresh:
```typescript
try {
  const saved = localStorage.getItem(KEY);
  if (saved) {
    const parsed = JSON.parse(saved);
    useRegistrationStore.getState().updateFields(parsed);
  }
} catch {
  localStorage.removeItem(KEY);  // Clear corrupted data
}
```

### GOTCHAS

**Gotcha 1: `useFormPersistence` must only restore ONCE on mount**
Use a `useEffect` with empty deps `[]`. If you depend on store state, it re-runs every time the store changes, causing an infinite loop (restore → update store → trigger persistence → restore again).

**Gotcha 2: The 2-second debounce must use the LATEST state**
If the user types quickly, each keystroke triggers the save timer. Use `setTimeout` + `clearTimeout` pattern in a `useEffect` that depends on the store state.

**Gotcha 3: Zustand `getState()` is synchronous and always returns current state**
You can call it outside React components. This is useful for `fieldMapping.ts` and inside the store's own actions.

### VERIFICATION GATE

```javascript
// In browser console:

// Test 1: Basic state
const store = (await import('./stores/useRegistrationStore')).useRegistrationStore;
console.log(store.getState().productName);
// Expected: "" (empty default)

// Test 2: Update fields
store.getState().updateFields({ productName: "Test Product", owner: "user@ubs.com" });
console.log(store.getState().productName);
// Expected: "Test Product"
console.log(store.getState().businessDomain);
// Expected: "" (other fields untouched)

// Test 3: Step completion
const completion = store.getState().getStepCompletion();
console.log(completion[0]);
// Expected: { filled: 1, total: 5 } (only productName filled in Step 1)
console.log(completion[2]);
// Expected: { filled: 3, total: 4 } (environment, accessControl, dataScope have defaults... 
// wait, accessControl and dataScope are Steps 3 and 5 not 3 — check your mapping!)
// Step 3 has: sourceUrl (empty), environment (PROD=filled), cidClassification (empty), accessControl (Role-Based=filled)
// Expected: { filled: 2, total: 4 }

// Test 4: Reset
store.getState().reset();
console.log(store.getState().productName);
// Expected: ""

// Test 5: localStorage persistence
store.getState().updateFields({ productName: "Persist Test" });
// Wait 3 seconds (debounce + buffer)
setTimeout(() => {
  console.log(localStorage.getItem("wma-registration-draft"));
  // Expected: JSON string containing "Persist Test"
}, 3000);

// Test 6: Refresh page → check if restored
// Refresh the page, then:
console.log(store.getState().productName);
// Expected: "Persist Test"

// Test 7: Prefill from MetaQ
store.getState().prefillFromMetaq({
  dataset_title: "rcat0100",
  name: "RCAT 0100",
  description: "Reference data",
  cidstaterag: "Green",
  ontologyname: "Account Ontology",
  kde: "account_id, category_code",
  dqobject: null,  // null should NOT overwrite
});
console.log(store.getState().productName);        // "rcat0100"
console.log(store.getState().shortDescription);    // "Reference data"
console.log(store.getState().cidClassification);   // "Green"
console.log(store.getState().businessEntity);      // "Account Ontology"
console.log(store.getState().glossaryTerms);       // "account_id, category_code"
console.log(store.getState().qualityRules);        // "" (not overwritten because dqobject was null)
console.log(store.getState().metaqSource);         // "rcat0100"
```

---

## STAGE 5: React Query Hooks

### OBJECTIVE
Wrap the service layer in React Query hooks that provide loading states, caching, error handling, and mutation side effects.

### PREREQUISITE GATE
```
□ Stage 4 verification gate passed
□ dpasService and metaqService both work from console
```

### EXACT FILES TO CREATE

```
1. src/hooks/useDataProducts.ts    ← queries + mutations for DPAS
2. src/hooks/useMetaqDatasets.ts   ← queries for MetaQ
```

### CRITICAL RULES

**Rule 1: `QueryClientProvider` must wrap the app in `main.tsx`**
Add this in Stage 2's `main.tsx` changes (or do it now if not done yet):
```typescript
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,
      retry: 2,
      refetchOnWindowFocus: false,
    },
  },
});
```

**Rule 2: `useCreateDataProduct` mutation must update the Zustand store on success**
```typescript
onSuccess: (data) => {
  // CRITICAL: store the resource_id so we know to PATCH next time (not POST)
  useRegistrationStore.getState().markSavedToDpas(
    data.resource_id,
    data.resource_iri,
    null  // no etag from POST response
  );
  queryClient.invalidateQueries({ queryKey: ["dataProducts"] });
}
```

**Rule 3: `useMetaqDatasetByTitle` must only execute when search term is ≥ 2 characters**
```typescript
useQuery({
  queryKey: ["metaq-dataset", title],
  queryFn: () => metaqService.getByTitle(title),
  enabled: title.length >= 2,  // prevents firing on empty string or single char
});
```
Without `enabled`, the query fires on mount with `title=""`, which sends `GET /dataset/` (missing param) and returns an error.

**Rule 4: Mutations must NOT have automatic retry**
Queries can retry (idempotent GETs). But POST mutations must NOT retry — you'd create duplicate records:
```typescript
// React Query default is retry: 3 for mutations too — override it:
useMutation({
  mutationFn: ...,
  retry: false,  // ← explicit
})
```

### GOTCHAS

**Gotcha 1: `useQuery` enabled=false means it never runs until enabled becomes true**
Don't set `enabled: !!someVariable` if `someVariable` starts as `undefined` and you expect the query to run anyway.

**Gotcha 2: `invalidateQueries` is async but usually doesn't need to be awaited**
It triggers a background refetch. The UI updates when the refetch completes.

**Gotcha 3: React Query DevTools are incredibly useful during development**
```bash
npm install @tanstack/react-query-devtools --save-dev
```
Add `<ReactQueryDevtools />` inside `QueryClientProvider`. Remove before production.

### VERIFICATION GATE

These hooks will be fully tested in Stage 6 when they're wired to the UI. For now, just verify they compile:
```
□ No TypeScript errors on `npm run dev`
□ No import errors in console
```

---

## STAGE 6: Wire Up the Wizard UI

### OBJECTIVE
This is the big one. Convert all 10 Step components from uncontrolled to controlled, wire Save & Continue to real API calls, wire Sidebar/Header/SummaryPanel to real state.

### PREREQUISITE GATE
```
□ All previous stages' verification gates passed
□ Store, services, hooks all work independently
```

### FILES TO MODIFY (in this order)

```
1. src/App.tsx                        ← add useFormPersistence()
2. src/components/Header.tsx          ← useAuth() for user info
3. src/components/Sidebar.tsx         ← store.getStepCompletion()
4. src/components/SummaryPanel.tsx    ← store field values
5. src/components/RegistrationForm.tsx ← ALL step components + save logic
```

**Do them in this order.** Header, Sidebar, SummaryPanel are simpler — get them right first. RegistrationForm is the complex one.

### CRITICAL RULES

**Rule 1: Convert EVERY `defaultValue` to `value` + `onChange`**
This is the #1 source of bugs. `defaultValue` makes the input uncontrolled (React doesn't track it). `value` makes it controlled (React owns the state).

```typescript
// ❌ UNCONTROLLED — React doesn't know when this changes
<input defaultValue="WMA Account" />

// ✅ CONTROLLED — React tracks every keystroke
<input value={store.productName} onChange={(e) => store.updateFields({ productName: e.target.value })} />
```

**IMPORTANT:** You cannot mix. If an input has `value` but no `onChange`, React throws a warning and the field becomes read-only. Always pair them.

**Rule 2: Select elements need explicit `value` attribute on each `<option>`**
```typescript
// ❌ WRONG — option value defaults to inner text, which may have whitespace issues
<select value={store.environment}>
  <option>PROD</option>
</select>

// ✅ CORRECT — explicit value attribute
<select value={store.environment} onChange={(e) => store.updateFields({ environment: e.target.value })}>
  <option value="PROD">PROD</option>
  <option value="DEV">DEV</option>
  <option value="UAT">UAT</option>
</select>
```

**Rule 3: Checkboxes use `checked` not `value`**
```typescript
// ✅ CORRECT
<input
  type="checkbox"
  checked={store.attestAccuracy}
  onChange={(e) => store.updateFields({ attestAccuracy: e.target.checked })}
/>

// ❌ WRONG
<input type="checkbox" value={store.attestAccuracy} />  // value is for the submit value, not checked state
```

**Rule 4: `handleContinue` must be async and handle errors**
The current `handleContinue` just calls `onStepChange(currentStep + 1)`. The new version must:
1. Call the API (which is async)
2. Handle success (advance step)
3. Handle failure (show error, do NOT advance)

```typescript
// ❌ WRONG — fire-and-forget, user advances even if API fails
const handleContinue = () => {
  createMutation.mutate(payload);  // async, no await
  onStepChange(currentStep + 1);   // runs immediately regardless of API result
};

// ✅ CORRECT — await, only advance on success
const handleContinue = async () => {
  try {
    await createMutation.mutateAsync(payload);
    onStepChange(currentStep + 1);  // only runs if API succeeded
  } catch (error) {
    toast.error(error.message);     // stays on current step
  }
};
```

**Rule 5: API call should only happen when DPAS-required fields are present**
Not every step has DPAS-compatible fields. The API call should only fire when `productName`, `owner`, and `environment` are all non-empty. Otherwise, just advance the step without calling the API.

```typescript
const canSaveToDpas = store.productName.trim() && store.owner.trim() && store.environment.trim();

if (canSaveToDpas) {
  if (!store.dpasResourceId) {
    // First time → POST
  } else {
    // Subsequent → PATCH
  }
}
// Always advance step (even if no API call)
onStepChange(currentStep + 1);
```

**Rule 6: Import `toast` from sonner for notifications**
```typescript
import { toast } from "sonner";
```
And add `<Toaster />` component in `App.tsx` or `main.tsx`:
```typescript
import { Toaster } from "sonner";
// In JSX:
<Toaster position="top-right" richColors />
```

**Rule 7: The Sidebar must NOT call `useRegistrationStore` inside the step mapping**
Call the hook once at the top of the component, not inside `.map()`:
```typescript
// ✅ CORRECT
export function Sidebar({ currentStep, onStepChange }) {
  const getStepCompletion = useRegistrationStore((s) => s.getStepCompletion);
  const completion = getStepCompletion();  // called once

  const steps = [
    { id: 1, ..., filled: completion[0].filled, total: completion[0].total },
    // ...
  ];
}
```

**Rule 8: Each Step component should use a Zustand selector to avoid full re-renders**
```typescript
// ✅ GOOD — only re-renders when these specific fields change
function Step1() {
  const productName = useRegistrationStore((s) => s.productName);
  const productType = useRegistrationStore((s) => s.productType);
  const updateFields = useRegistrationStore((s) => s.updateFields);
  // ...
}

// ❌ BAD — re-renders on ANY store change (including Step 5 fields)
function Step1() {
  const store = useRegistrationStore();
  // ...
}
```
The second pattern works but causes unnecessary re-renders across all steps.

### GOTCHAS

**Gotcha 1: `sonner` toast component must be rendered in the tree**
If you call `toast.success("Saved!")` but `<Toaster />` isn't in the component tree, nothing appears. No error, just silence.

**Gotcha 2: `mutateAsync` vs `mutate`**
- `mutate()` — fire-and-forget, callbacks via `onSuccess`/`onError`
- `mutateAsync()` — returns a Promise, can be `await`ed in try/catch

Use `mutateAsync` in `handleContinue` because you need to wait for the result before advancing.

**Gotcha 3: The SummaryPanel reads ALL fields — use `useRegistrationStore()` without selector**
Unlike Step components (which should use selectors), SummaryPanel genuinely needs all fields. It's OK to subscribe to the entire store here.

**Gotcha 4: Title immutability warning after first save**
After the first POST, `dpasResourceId` becomes non-null. At that point, the Product Name field should show a warning and ideally become `readOnly`:
```typescript
const isCreated = !!useRegistrationStore((s) => s.dpasResourceId);
<input
  value={productName}
  onChange={isCreated ? undefined : (e) => updateFields({ productName: e.target.value })}
  readOnly={isCreated}
  className={`${inputClass} ${isCreated ? "bg-[#f9fafb] cursor-not-allowed" : ""}`}
/>
{isCreated && <p className="text-[11px] text-[#f59e0b] mt-1">Cannot be changed after initial save</p>}
```

### VERIFICATION GATE

This is the most thorough gate. Test every interaction:

```
FORM BINDING:
□ Step 1: Type "My Product" in Product Name → SummaryPanel shows "My Product" instantly
□ Step 1: Clear the field → SummaryPanel shows "—"
□ Step 2: Type an email in Owner → SummaryPanel updates
□ Step 3: Change Environment dropdown to "DEV" → SummaryPanel shows "DEV"
□ Step 8: Change Data Classification dropdown → SummaryPanel updates
□ Step 10: Check/uncheck attestation boxes → state updates correctly

SIDEBAR PROGRESS:
□ Fill all 5 fields in Step 1 → Sidebar shows 5/5 and green checkmark
□ Fill 3 of 6 fields in Step 2 → Sidebar shows 3/6 with amber progress bar
□ Step 3 with defaults → should show 2/4 (environment and accessControl pre-filled)

SAVE & CONTINUE:
□ Fill Step 1 + Step 2 owner → click Save & Continue → Network tab shows POST /dataproducts
□ POST body contains: { title, owner, source_system_code, description }
□ After POST success → toast shows "Created" or similar
□ Step advances to Step 2
□ Click Save & Continue on Step 2 → Network tab shows PATCH /dataproducts/{id}
□ PATCH body contains: { description, owner, source_system_code }
□ PATCH does NOT contain "title" (immutable)

SUBMIT:
□ Reach Step 10 → check both boxes → click Submit Registration
□ Network shows PATCH with { status: "published" }
□ Toast shows success
□ Form resets, localStorage cleared

PERSISTENCE:
□ Fill several fields → close tab → reopen → all fields restored
□ After successful submit → close tab → reopen → form is empty (draft was cleared)

HEADER:
□ Shows mock user name "Arpit Dave" (not hardcoded, from useAuth hook)
□ "Saved" indicator shows appropriate state

ERROR HANDLING:
□ Fill Product Name with a title that already exists in mock data ("wma-account-master")
□ Click Save → should get 409 error → toast shows "already exists" → stays on current step
```

---

## STAGE 7: Validation

### PREREQUISITE GATE
```
□ Stage 6 verification gate passed completely
□ Form save/submit flow working end-to-end
```

### EXACT FILES TO CREATE

```
1. src/validation/schemas.ts
```

Then modify:
```
2. src/components/RegistrationForm.tsx  ← add validation before API calls
```

### CRITICAL RULES

**Rule 1: Validate BEFORE the API call, not after**
```typescript
// In handleContinue:
const validation = validateStep(currentStep, relevantFields);
if (!validation.success) {
  setErrors(validation.errors);
  toast.error("Please fix the highlighted fields");
  return; // ← STOP HERE
}
setErrors({});
// then proceed with API call...
```

**Rule 2: The `@ubs.com` regex must handle edge cases**
```typescript
// ✅ Covers: firstname.lastname@ubs.com, f.last-name@ubs.com, first_last@ubs.com
const ubsEmailPattern = /^[a-zA-Z0-9_.%-]+@ubs\.com$/;

// ❌ Too permissive — allows @ubs.com.evil.com
const ubsEmailPattern = /@ubs\.com/;  // missing ^ and $
```

**Rule 3: Validation errors must clear when user starts typing**
Add an `onChange` wrapper that clears the specific field's error:
```typescript
const handleFieldChange = (key: string, value: string) => {
  store.updateFields({ [key]: value });
  if (errors[key]) {
    setErrors((prev) => { const next = { ...prev }; delete next[key]; return next; });
  }
};
```

**Rule 4: Step 9 has NO validation (optional step)**
`validateStep(9, data)` should return `{ success: true, errors: {} }`.

**Rule 5: `validateStep` must extract only that step's fields from the store**
Don't pass the entire store — pass only the fields for the current step. This prevents cross-step validation pollution.

### VERIFICATION GATE

```
□ Step 1: Leave Product Name empty → click Save → red border + "required" error below field
□ Step 2: Type "bad@gmail.com" as owner → Save → "Must be a @ubs.com email"
□ Step 2: Type "valid@ubs.com" → error disappears as you type
□ Step 2: Slack channel without # → "Must start with #"
□ Step 3: Leave Source URL empty → "required" error
□ Step 9: No validation → Save always passes
□ Step 10: Uncheck attestation → Submit blocked with error
□ All valid data → Save works normally, no spurious errors
```

---

## STAGE 8: MetaQ Dataset Browser

### PREREQUISITE GATE
```
□ Stage 7 verification gate passed
□ metaqService.listDatasets() and getByTitle() work
□ store.prefillFromMetaq() works
```

### EXACT FILES TO CREATE

```
1. src/components/DatasetBrowser.tsx
```

Then modify:
```
2. src/components/RegistrationForm.tsx  ← add button + modal state
```

### CRITICAL RULES

**Rule 1: The modal must prevent body scroll when open**
```typescript
useEffect(() => {
  if (isOpen) {
    document.body.style.overflow = "hidden";
  } else {
    document.body.style.overflow = "";
  }
  return () => { document.body.style.overflow = ""; };
}, [isOpen]);
```

**Rule 2: Search must be debounced**
Don't fire a request on every keystroke. Wait 300ms after the user stops typing:
```typescript
const [searchTerm, setSearchTerm] = useState("");
const [debouncedSearch, setDebouncedSearch] = useState("");

useEffect(() => {
  const timer = setTimeout(() => setDebouncedSearch(searchTerm), 300);
  return () => clearTimeout(timer);
}, [searchTerm]);

// Pass debouncedSearch to the hook, not searchTerm
const { data } = useMetaqDatasetByTitle(debouncedSearch);
```

**Rule 3: Closing the modal must reset search state**
```typescript
const handleClose = () => {
  setSearchTerm("");
  onClose();
};
```

**Rule 4: Empty dataset fields should display gracefully**
Many MetaQ fields are `null`. The dataset card should handle this:
```typescript
{dataset.description ? (
  <p className="text-[12px] text-[#6b7280] line-clamp-2">{dataset.description}</p>
) : (
  <p className="text-[12px] text-[#d1d5db] italic">No description</p>
)}
```

**Rule 5: After selection, the modal closes AND the form should show visual feedback**
Use a toast: `toast.success("Imported from catalog: " + dataset.dataset_title)`.

### VERIFICATION GATE

```
□ "Import from Catalog" button visible above Step 1 form
□ Click button → modal appears with backdrop
□ 8 mock datasets displayed with names and CID badges
□ Type "rcat" → only rcat0100 shows
□ Type "xx" (no match) → "No datasets found" message
□ Clear search → all 8 datasets reappear
□ Click rcat0100 → modal closes → productName = "rcat0100", shortDescription = "Reference data..."
□ CID badge colors: Green=green, Amber=amber, Red=red
□ Click backdrop or X → modal closes without selection
□ Keyboard: Escape closes modal
□ Body doesn't scroll while modal is open
```

---

## STAGE 9: Polish + Error Handling

### PREREQUISITE GATE
```
□ Stage 8 verification gate passed
□ Full flow works: import → fill → save → submit
```

### WHAT TO ADD

No new files. Modify existing components:

1. **Loading spinners on Save/Submit buttons** — disable + show spinner while `mutation.isPending`
2. **Specific error messages by HTTP status** — 409, 412, 422, 5xx
3. **Title immutability lock** — readOnly after first POST
4. **Disable double-submit** — button disabled during API call
5. **Network failure handling** — catch `error.code === "ERR_NETWORK"` → "Connection error"
6. **Auto-focus first error field** after validation failure
7. **Success feedback on submit** — could be a confetti animation, success page, or just a prominent toast

### CRITICAL RULES

**Rule 1: Always disable the button during mutation**
```typescript
<button
  disabled={createMutation.isPending || updateMutation.isPending}
  onClick={handleContinue}
>
```
Without this, users double-click and create duplicate records.

**Rule 2: Check `error.response` exists before accessing `.status`**
Network errors (server down, CORS, timeout) don't have `error.response`:
```typescript
catch (error: any) {
  if (error.response) {
    // Server responded with error status
    switch (error.response.status) {
      case 409: toast.error("Product name already exists"); break;
      case 412: toast.error("Record modified by someone else"); break;
      case 422: toast.error(error.message); break;
      default: toast.error("Server error. Please try again.");
    }
  } else if (error.code === "ERR_NETWORK" || error.code === "ECONNABORTED") {
    toast.error("Cannot connect to server. Please check your connection.");
  } else {
    toast.error("An unexpected error occurred.");
  }
}
```

**Rule 3: The "Saved" indicator in Header should show relative time**
Not just "Saved" — show "Saved 5s ago" or "Saved just now":
```typescript
const lastSaved = useRegistrationStore((s) => s.lastSavedAt);
// Calculate relative time from lastSaved ISO string
```

### VERIFICATION GATE (FINAL)

```
HAPPY PATH:
□ Import dataset from MetaQ → fills form → sidebar updates
□ Complete Step 1 through Step 10 filling all fields
□ Each "Save & Continue" makes appropriate API call (POST first time, PATCH after)
□ Network tab shows correct payloads and headers (Authorization, If-Match, Content-Type)
□ Step 10 submit → status changes to "published" → toast success → form resets
□ localStorage cleared after submit
□ Can start a new registration immediately after submit

ERROR PATHS:
□ Validation errors show red borders + messages, block API call
□ Duplicate title → 409 → specific toast → stays on step
□ Invalid email → 422 → specific toast → stays on step
□ Server error → 500 → generic toast → stays on step
□ Network failure → "Cannot connect" toast
□ Double-click Save → only one API call fires (button disabled during request)

STATE PERSISTENCE:
□ Fill 5 steps → close tab → reopen → all data intact → sidebar shows correct progress
□ Submit → close tab → reopen → clean form (draft cleared)

AUTH (mock mode):
□ Header shows "Arpit Dave" and "arpit.dave@ubs.com"
□ All API calls have "Authorization: Bearer mock-bearer-token" header

PERFORMANCE:
□ No React warnings in console about controlled/uncontrolled component switch
□ No "missing key" warnings in lists
□ No unnecessary re-renders (React DevTools Profiler — each Step re-renders only when its fields change)
□ Typing in fields is responsive (no visible lag)
```

---

## CROSS-STAGE BUG PREVENTION CHECKLIST

Run this checklist at the end of ALL stages:

```
IMPORT CHAIN:
□ No circular imports (A imports B imports A)
□ Every file imports types from api/types.ts (single source of truth)
□ No file imports from mocks/ except main.tsx

TYPESCRIPT:
□ `npm run build` produces zero TypeScript errors
□ No `any` types except in catch blocks (where it's unavoidable)
□ All store keys match the WizardFormState interface exactly

ENVIRONMENT:
□ .env has VITE_USE_MOCKS=true
□ All VITE_ variables are accessed via import.meta.env.VITE_* (not process.env)
□ No hardcoded API URLs anywhere except apiConfig.ts
□ No hardcoded user info anywhere except mockAuth.ts

REACT PATTERNS:
□ No hooks called conditionally (if/else before a hook call)
□ No hooks called inside loops or callbacks
□ All useEffect cleanup functions present where needed (timeouts, event listeners)
□ All arrays in JSX have `key` props

STATE:
□ Every form input is controlled (value + onChange, not defaultValue)
□ Every select has explicit value attributes on options
□ Checkboxes use checked + onChange (not value)
□ Store updateFields merges, does not replace

NETWORK:
□ Every request has Authorization header (check Network tab)
□ POST returns 201, PATCH returns 200
□ Error responses parsed and shown to user
□ No API call without proper error handling (try/catch or .catch)

CONSOLE:
□ Zero errors
□ Zero warnings (except React StrictMode double-render, which is expected)
□ MSW startup message visible: "[MSW] Mocking enabled"
```

---

*Follow these instructions exactly, verify every gate, and you will have 100% working code that cleanly separates mock from real, survives the transition to remote desktop, and handles every edge case.*