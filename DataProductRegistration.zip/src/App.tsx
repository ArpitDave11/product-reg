import { useState } from 'react';
import { Toaster } from 'sonner';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { RegistrationForm } from './components/RegistrationForm';
import { SummaryPanel } from './components/SummaryPanel';
import { useFormPersistence } from './hooks/useFormPersistence';

const stepNames = [
  'Product Identity & Purpose',
  'Ownership & Support',
  'Source & Entitlements',
  'Semantics & Data Quality',
  'Data Contract & Access',
  'Lineage & Transformations',
  'Compliance & AI Readiness',
  'Attestation & Submit',
];

export default function App() {
  const [currentStep, setCurrentStep] = useState(1);
  const [summaryOpen, setSummaryOpen] = useState(false);

  // Activate localStorage save/restore
  useFormPersistence();

  return (
    <div className="flex min-h-screen bg-white">
      <Toaster position="top-right" richColors closeButton />
      {/* Sidebar */}
      <Sidebar currentStep={currentStep} onStepChange={setCurrentStep} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <Header currentStep={currentStep} stepName={stepNames[currentStep - 1]} />

        {/* Content area */}
        <div className="flex-1 overflow-y-auto">
          <div className={`p-8 lg:p-10 transition-all duration-300 ${summaryOpen ? 'pr-[320px]' : ''}`}>
            <RegistrationForm currentStep={currentStep} onStepChange={setCurrentStep} />
          </div>
        </div>
      </div>

      {/* Collapsible Summary Panel — Stripe-inspired live preview */}
      <SummaryPanel isOpen={summaryOpen} onToggle={() => setSummaryOpen(!summaryOpen)} />
    </div>
  );
}