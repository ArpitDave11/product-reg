import { useEffect, useCallback, useState } from 'react';
import type { ReactNode } from 'react';
import {
  Package, Users, Link2, Database, FileText,
  GitBranch, Shield, Send, ArrowRight, ChevronLeft,
  Lightbulb, Info, Loader2, Lock
} from 'lucide-react';
import { toast } from 'sonner';
import { useRegistrationStore } from '../stores/useRegistrationStore';
import { useCreateDataProduct, useUpdateDataProduct } from '../hooks/useDataProducts';
import { toDpasCreatePayload, toDpasUpdatePayload } from '../utils/fieldMapping';
import { clearDraft } from '../hooks/useFormPersistence';
import { validateStep } from '../validation/schemas';
import { DatasetBrowser } from './DatasetBrowser';
import type { MetaqDataset } from '../api/types';

interface RegistrationFormProps {
  currentStep: number;
  onStepChange: (step: number) => void;
}

export function RegistrationForm({ currentStep, onStepChange }: RegistrationFormProps) {
  const [animating, setAnimating] = useState(false);
  const [displayStep, setDisplayStep] = useState(currentStep);
  const [slideDir, setSlideDir] = useState<'left' | 'right'>('right');

  const store = useRegistrationStore();
  const createMutation = useCreateDataProduct();
  const updateMutation = useUpdateDataProduct();
  const isSaving = createMutation.isPending || updateMutation.isPending;

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [catalogOpen, setCatalogOpen] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleCatalogSelect = useCallback((dataset: MetaqDataset) => {
    store.prefillFromMetaq(dataset);
    toast.success('Imported from catalog: ' + dataset.dataset_title);
  }, [store]);

  const handleFieldChange = useCallback(
    (key: string, value: string | boolean) => {
      store.updateFields({ [key]: value });
      if (errors[key]) {
        setErrors((prev) => {
          const next = { ...prev };
          delete next[key];
          return next;
        });
      }
    },
    [errors, store]
  );

  const handleBack = useCallback(() => {
    if (currentStep > 1) onStepChange(currentStep - 1);
  }, [currentStep, onStepChange]);

  const handleContinue = useCallback(async () => {
    if (currentStep >= 8 || isSaving) return;

    // Validate current step before proceeding
    const validation = validateStep(currentStep, store);
    if (!validation.success) {
      setErrors(validation.errors);
      toast.error('Please fix the highlighted fields');
      requestAnimationFrame(() => {
        const firstErr = document.querySelector<HTMLElement>('.text-\\[\\#ef4444\\]');
        const parent = firstErr?.closest('div');
        const input = parent?.querySelector<HTMLElement>('input, textarea, select');
        input?.focus();
      });
      return;
    }
    setErrors({});

    const { productName, owner, environment, dpasResourceId, dpasEtag } = store;
    const hasApiFields = productName.trim() && owner.trim() && environment.trim();

    if (hasApiFields) {
      try {
        if (!dpasResourceId) {
          // First save — POST
          await createMutation.mutateAsync(toDpasCreatePayload(store));
          toast.success('Data product created');
        } else {
          // Subsequent save — PATCH
          await updateMutation.mutateAsync({
            id: dpasResourceId,
            payload: toDpasUpdatePayload(store),
            etag: dpasEtag || undefined,
          });
          toast.success('Saved');
        }
      } catch (err: unknown) {
        const error = err as Error & { response?: { status: number }; code?: string };
        if (error.response) {
          switch (error.response.status) {
            case 409: toast.error('A product with this name already exists'); break;
            case 412: toast.error('Record modified by someone else. Please refresh.'); break;
            case 422: toast.error(error.message || 'Validation error'); break;
            default:  toast.error('Server error. Please try again.');
          }
        } else if (error.code === 'ERR_NETWORK' || error.code === 'ECONNABORTED') {
          toast.error('Cannot connect to server. Please check your connection.');
        } else {
          toast.error('An unexpected error occurred.');
        }
        return; // Don't advance on error
      }
    }

    onStepChange(currentStep + 1);
  }, [currentStep, isSaving, store, createMutation, updateMutation, onStepChange]);

  const handleSubmit = useCallback(async () => {
    if (isSaving) return;

    // Validate Step 8 (attestations)
    const validation = validateStep(8, store);
    if (!validation.success) {
      setErrors(validation.errors);
      toast.error('Please fix the highlighted fields');
      requestAnimationFrame(() => {
        const firstKey = Object.keys(validation.errors)[0];
        const el = document.querySelector<HTMLElement>(`[data-field="${firstKey}"]`);
        el?.focus();
      });
      return;
    }
    setErrors({});

    const { dpasResourceId, dpasEtag } = store;

    if (!dpasResourceId) {
      toast.error('No saved registration. Go back and save first.');
      return;
    }

    try {
      await updateMutation.mutateAsync({
        id: dpasResourceId,
        payload: { status: 'published' },
        etag: dpasEtag || undefined,
      });
      clearDraft();
      store.reset();
      setSubmitSuccess(true);
    } catch (err: unknown) {
      const error = err as Error & { response?: { status: number }; code?: string };
      if (error.response) {
        switch (error.response.status) {
          case 412: toast.error('Modified by someone else. Refresh and try again.'); break;
          default:  toast.error('Server error. Please try again.');
        }
      } else if (error.code === 'ERR_NETWORK' || error.code === 'ECONNABORTED') {
        toast.error('Cannot connect to server. Please check your connection.');
      } else {
        toast.error('Submission failed. Try again.');
      }
    }
  }, [isSaving, store, updateMutation]);

  // Step transition animation + clear errors on step change
  useEffect(() => {
    if (currentStep !== displayStep) {
      setErrors({});
      setSlideDir(currentStep > displayStep ? 'right' : 'left');
      setAnimating(true);
      const timer = setTimeout(() => {
        setDisplayStep(currentStep);
        setAnimating(false);
      }, 200);
      return () => clearTimeout(timer);
    }
  }, [currentStep, displayStep]);

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
        e.preventDefault();
        if (currentStep < 8) handleContinue();
        else handleSubmit();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [handleContinue, handleSubmit, currentStep]);

  const stepInfo = [
    { number: 1, title: 'Product Identity & Purpose', icon: Package, description: 'Define the core identity of your data product — name, type, domain, and business purpose.' },
    { number: 2, title: 'Ownership & Support', icon: Users, description: 'Assign ownership, stewardship, and organizational accountability.' },
    { number: 3, title: 'Source & Entitlements', icon: Link2, description: 'Configure source systems, connections, and access entitlements.' },
    { number: 4, title: 'Semantics & Data Quality', icon: Database, description: 'Map business metadata, quality rules, and fitness targets.' },
    { number: 5, title: 'Data Contract & Access', icon: FileText, description: 'Establish SLAs, retention policies, and consumer onboarding.' },
    { number: 6, title: 'Lineage & Transformations', icon: GitBranch, description: 'Document upstream sources, transformation logic, and data flows.' },
    { number: 7, title: 'Compliance & AI Readiness', icon: Shield, description: 'Classify sensitivity, map regulations, and configure AI capabilities.' },
    { number: 8, title: 'Attestation & Submit', icon: Send, description: 'Review all entries, attest, and submit for governance review.' },
  ];

  const current = stepInfo[currentStep - 1];
  const StepIcon = current.icon;

  // Success screen after submission
  if (submitSuccess) {
    return (
      <div className="max-w-[840px] mx-auto">
        <div className="bg-white rounded-2xl border border-[#e5e7eb] shadow-[0_1px_2px_rgba(0,0,0,0.03),0_2px_8px_rgba(0,0,0,0.04)] p-10 text-center">
          <div className="w-16 h-16 bg-[#f0fdf4] rounded-full flex items-center justify-center mx-auto mb-5 border-2 border-[#dcfce7]">
            <Send className="w-7 h-7 text-[#22c55e]" />
          </div>
          <h2 className="text-[22px] font-semibold text-[#111] mb-2">Registration Submitted</h2>
          <p className="text-[14px] text-[#6b7280] mb-2 max-w-md mx-auto">
            Your data product has been submitted for governance review. You will receive email notifications on status updates.
          </p>
          <p className="text-[13px] text-[#9ca3af] mb-8">Typical review time: 2–3 business days</p>
          <button
            onClick={() => { setSubmitSuccess(false); onStepChange(1); }}
            className="px-6 py-2.5 bg-[#e60028] text-white rounded-lg text-[13px] font-medium hover:bg-[#cc0024] transition-all shadow-[0_1px_3px_rgba(230,0,40,0.2)]"
          >
            Register Another Product
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[840px] mx-auto">
      {/* Import from Catalog — visible on Step 1 only */}
      {currentStep === 1 && (
        <div className="mb-4 flex justify-end">
          <button
            onClick={() => setCatalogOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 text-[13px] font-medium text-[#0284c7] bg-[#f0f9ff] border border-[#e0f2fe] rounded-lg hover:bg-[#e0f2fe] hover:border-[#bae6fd] transition-all"
          >
            <Database className="w-3.5 h-3.5" />
            Import from Catalog
          </button>
        </div>
      )}

      <DatasetBrowser
        isOpen={catalogOpen}
        onClose={() => setCatalogOpen(false)}
        onSelect={handleCatalogSelect}
      />

      {/* Step header */}
      <div className="mb-6">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex items-center gap-3.5">
            <div className="p-2.5 bg-[#fef2f2] rounded-xl border border-[#fecaca]">
              <StepIcon className="w-5 h-5 text-[#e60028]" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-[20px] font-semibold text-[#111] tracking-tight">
                  {current.title}
                </h1>
              </div>
              <p className="text-[13px] text-[#6b7280] mt-1">{current.description}</p>
            </div>
          </div>
          <span className="text-[13px] text-[#b0b0b0] font-medium whitespace-nowrap mt-1">
            {currentStep} / 8
          </span>
        </div>

        {/* Step progress bar */}
        <div className="w-full bg-[#f0f0f0] rounded-full h-[5px] overflow-hidden">
          <div
            className="bg-[#e60028] h-full rounded-full transition-all duration-500 ease-out"
            style={{ width: `${(currentStep / 8) * 100}%` }}
          />
        </div>
      </div>

      {/* Form card */}
      <div className="bg-white rounded-2xl border border-[#e5e7eb] shadow-[0_1px_2px_rgba(0,0,0,0.03),0_2px_8px_rgba(0,0,0,0.04)] p-8 lg:p-10">
        {/* Animated step content */}
        <div
          className={`transition-all duration-200 ease-out ${
            animating
              ? slideDir === 'right'
                ? 'opacity-0 translate-x-3'
                : 'opacity-0 -translate-x-3'
              : 'opacity-100 translate-x-0'
          }`}
        >
          {displayStep === 1 && <Step1 errors={errors} onChange={handleFieldChange} titleLocked={!!store.dpasResourceId} />}
          {displayStep === 2 && <Step2 errors={errors} onChange={handleFieldChange} />}
          {displayStep === 3 && <Step3 errors={errors} onChange={handleFieldChange} />}
          {displayStep === 4 && <Step4 errors={errors} onChange={handleFieldChange} />}
          {displayStep === 5 && <Step5 errors={errors} onChange={handleFieldChange} />}
          {displayStep === 6 && <Step6 errors={errors} onChange={handleFieldChange} />}
          {displayStep === 7 && <Step7 errors={errors} onChange={handleFieldChange} />}
          {displayStep === 8 && <Step8 errors={errors} onChange={handleFieldChange} />}
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-10 pt-7 border-t border-[#f0f0f0]">
          <button
            onClick={handleBack}
            disabled={currentStep === 1}
            className={`px-4 py-2.5 rounded-lg text-[13px] font-medium transition-all duration-200 flex items-center gap-2 border ${
              currentStep === 1
                ? 'bg-[#fafafa] text-[#c0c0c0] border-[#f0f0f0] cursor-not-allowed'
                : 'bg-white text-[#374151] border-[#e5e7eb] hover:border-[#9ca3af] hover:bg-[#f9fafb]'
            }`}
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            Back
          </button>

          {currentStep < 8 ? (
            <button
              onClick={handleContinue}
              disabled={isSaving}
              className="px-5 py-2.5 bg-[#e60028] text-white rounded-lg text-[13px] font-medium hover:bg-[#cc0024] transition-all duration-200 flex items-center gap-2 shadow-[0_1px_3px_rgba(230,0,40,0.2)] disabled:opacity-60"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  Save &amp; Continue
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={isSaving}
              className="px-5 py-2.5 bg-[#22c55e] text-white rounded-lg text-[13px] font-medium hover:bg-[#16a34a] transition-all duration-200 flex items-center gap-2 shadow-[0_1px_3px_rgba(34,197,94,0.2)] disabled:opacity-60"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  Submit Registration
                  <Send className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ─── Shared helpers ──────────────────────────────────────── */

function SectionHeader({ title, description }: { title: string; description?: string }) {
  return (
    <div className="mb-5 pb-3 border-b border-[#f0f0f0]">
      <h3 className="text-[14px] font-semibold text-[#111]">{title}</h3>
      {description && <p className="text-[12px] text-[#9ca3af] mt-1">{description}</p>}
    </div>
  );
}

function HelpTip({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-[#f8f9fa] border border-[#f0f0f0] mb-6">
      <Lightbulb className="w-4 h-4 text-[#f59e0b] flex-shrink-0 mt-0.5" />
      <p className="text-[12px] text-[#6b7280] leading-relaxed">{children}</p>
    </div>
  );
}

function InfoTip({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-[#f0f9ff] border border-[#e0f2fe] mb-6">
      <Info className="w-4 h-4 text-[#0284c7] flex-shrink-0 mt-0.5" />
      <p className="text-[12px] text-[#0369a1] leading-relaxed">{children}</p>
    </div>
  );
}

interface StepProps {
  errors: Record<string, string>;
  onChange: (key: string, value: string | boolean) => void;
  titleLocked?: boolean;
}

const inputBase = "w-full border rounded-lg px-3.5 py-2.5 text-[13px] text-[#111] bg-white focus:ring-2 focus:outline-none transition-all placeholder:text-[#c0c0c0]";
const inputOk = `${inputBase} border-[#e5e7eb] hover:border-[#c0c0c0] focus:border-[#e60028] focus:ring-[#e60028]/10`;
const inputErr = `${inputBase} border-[#ef4444] hover:border-[#dc2626] focus:border-[#ef4444] focus:ring-[#ef4444]/10`;

function fieldClass(errors: Record<string, string>, key: string) {
  return errors[key] ? inputErr : inputOk;
}

const labelClass = "block text-[13px] font-medium text-[#374151] mb-1.5";

function FieldError({ message }: { message?: string }) {
  if (!message) return null;
  return <p className="text-[11px] text-[#ef4444] mt-1">{message}</p>;
}

/* ─── Step 1: Product Identity & Purpose (8 fields) ──────── */

function Step1({ errors, onChange, titleLocked }: StepProps) {
  const s = useRegistrationStore();
  return (
    <div>
      <SectionHeader title="Core Information" description="These fields establish the primary identity of your data product in the WMA catalog." />
      <HelpTip>Choose a descriptive, unique product name. It will appear in search results and data catalogs across the organization.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label className={labelClass}>
            Product Name <span className="text-[#e60028]">*</span>
            {titleLocked && <Lock className="inline w-3 h-3 ml-1 text-[#9ca3af]" />}
          </label>
          <input
            type="text"
            data-field="productName"
            value={s.productName}
            onChange={e => onChange('productName', e.target.value)}
            placeholder="e.g. WMA Account"
            readOnly={titleLocked}
            className={`${fieldClass(errors, 'productName')} ${titleLocked ? 'bg-[#f9fafb] text-[#6b7280] cursor-not-allowed' : ''}`}
          />
          {titleLocked && <p className="text-[11px] text-[#9ca3af] mt-1">Title cannot be changed after first save</p>}
          <FieldError message={errors.productName} />
        </div>
        <div>
          <label className={labelClass}>Product Type <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.productType} onChange={e => onChange('productType', e.target.value)} placeholder="e.g. Composite Data Product" className={fieldClass(errors, 'productType')} />
          <FieldError message={errors.productType} />
        </div>
        <div>
          <label className={labelClass}>Business Domain <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.businessDomain} onChange={e => onChange('businessDomain', e.target.value)} placeholder="e.g. Account" className={fieldClass(errors, 'businessDomain')} />
          <FieldError message={errors.businessDomain} />
        </div>
        <div>
          <label className={labelClass}>Short Description <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.shortDescription} onChange={e => onChange('shortDescription', e.target.value)} placeholder="Brief description" className={fieldClass(errors, 'shortDescription')} />
          <FieldError message={errors.shortDescription} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Long Description <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.longDescription} onChange={e => onChange('longDescription', e.target.value)} placeholder="Detailed business description..." className={`${fieldClass(errors, 'longDescription')} resize-y`} />
          <FieldError message={errors.longDescription} />
        </div>
        <div>
          <label className={labelClass}>Product Version <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.productVersion} onChange={e => onChange('productVersion', e.target.value)} placeholder="e.g. 1.0.0" className={fieldClass(errors, 'productVersion')} />
          <FieldError message={errors.productVersion} />
        </div>
        <div>
          <label className={labelClass}>Data Category <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.dataCategory} onChange={e => onChange('dataCategory', e.target.value)} placeholder="e.g. Master Data" className={fieldClass(errors, 'dataCategory')} />
          <FieldError message={errors.dataCategory} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Business Purpose <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.businessPurpose} onChange={e => onChange('businessPurpose', e.target.value)} placeholder="Describe the business purpose this data product serves..." className={`${fieldClass(errors, 'businessPurpose')} resize-y`} />
          <FieldError message={errors.businessPurpose} />
        </div>
      </div>
    </div>
  );
}

/* ─── Step 2: Ownership & Support (7 fields) ─────────────── */

function Step2({ errors, onChange }: StepProps) {
  const s = useRegistrationStore();
  return (
    <div>
      <SectionHeader title="Ownership & Support" description="Define who is accountable for this data product and how consumers can reach support." />
      <HelpTip>Ensure backup owners are from a different team for business continuity. All contacts must use @ubs.com email addresses.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label className={labelClass}>Data Product Owner <span className="text-[#e60028]">*</span></label>
          <input type="email" value={s.owner} onChange={e => onChange('owner', e.target.value)} placeholder="owner@ubs.com" className={fieldClass(errors, 'owner')} />
          <FieldError message={errors.owner} />
        </div>
        <div>
          <label className={labelClass}>Backup Owner <span className="text-[#e60028]">*</span></label>
          <input type="email" value={s.backupOwner} onChange={e => onChange('backupOwner', e.target.value)} placeholder="backup@ubs.com" className={fieldClass(errors, 'backupOwner')} />
          <FieldError message={errors.backupOwner} />
        </div>
        <div>
          <label className={labelClass}>IT Lead <span className="text-[#e60028]">*</span></label>
          <input type="email" value={s.itLead} onChange={e => onChange('itLead', e.target.value)} placeholder="itlead@ubs.com" className={fieldClass(errors, 'itLead')} />
          <FieldError message={errors.itLead} />
        </div>
        <div>
          <label className={labelClass}>Data Steward <span className="text-[#e60028]">*</span></label>
          <input type="email" value={s.dataSteward} onChange={e => onChange('dataSteward', e.target.value)} placeholder="steward@ubs.com" className={fieldClass(errors, 'dataSteward')} />
          <FieldError message={errors.dataSteward} />
        </div>
        <div>
          <label className={labelClass}>Support Email <span className="text-[#e60028]">*</span></label>
          <input type="email" value={s.supportEmail} onChange={e => onChange('supportEmail', e.target.value)} placeholder="support@ubs.com" className={fieldClass(errors, 'supportEmail')} />
          <FieldError message={errors.supportEmail} />
        </div>
        <div>
          <label className={labelClass}>Business Unit <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.businessUnit} onChange={e => onChange('businessUnit', e.target.value)} placeholder="e.g. Wealth Management Americas" className={fieldClass(errors, 'businessUnit')} />
          <FieldError message={errors.businessUnit} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Cost Center <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.costCenter} onChange={e => onChange('costCenter', e.target.value)} placeholder="e.g. CC-12345" className={fieldClass(errors, 'costCenter')} />
          <FieldError message={errors.costCenter} />
        </div>
      </div>
    </div>
  );
}

/* ─── Step 3: Source & Entitlements (13 fields, 2 sections) ─ */

function Step3({ errors, onChange }: StepProps) {
  const s = useRegistrationStore();
  return (
    <div>
      <SectionHeader title="Section A: Source Configuration" description="Configure the upstream source system and connection details." />
      <HelpTip>Use the production URL for the canonical source. CID classification determines what downstream consumers can access.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5 mb-8">
        <div className="col-span-2">
          <label className={labelClass}>Source Application URL <span className="text-[#e60028]">*</span></label>
          <input type="url" value={s.sourceUrl} onChange={e => onChange('sourceUrl', e.target.value)} placeholder="https://source-app/" className={fieldClass(errors, 'sourceUrl')} />
          <FieldError message={errors.sourceUrl} />
        </div>
        <div>
          <label className={labelClass}>Environment <span className="text-[#e60028]">*</span></label>
          <select value={s.environment} onChange={e => onChange('environment', e.target.value)} className={fieldClass(errors, 'environment')}>
            <option value="PROD">PROD</option>
            <option value="DEV">DEV</option>
            <option value="UAT">UAT</option>
          </select>
          <FieldError message={errors.environment} />
        </div>
        <div>
          <label className={labelClass}>Source System <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.sourceSystem} onChange={e => onChange('sourceSystem', e.target.value)} placeholder="e.g. Oracle EBS" className={fieldClass(errors, 'sourceSystem')} />
          <FieldError message={errors.sourceSystem} />
        </div>
        <div>
          <label className={labelClass}>Source Database <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.sourceDatabase} onChange={e => onChange('sourceDatabase', e.target.value)} placeholder="e.g. PROD_WMA_DB" className={fieldClass(errors, 'sourceDatabase')} />
          <FieldError message={errors.sourceDatabase} />
        </div>
        <div>
          <label className={labelClass}>Source Schema <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.sourceSchema} onChange={e => onChange('sourceSchema', e.target.value)} placeholder="e.g. dbo" className={fieldClass(errors, 'sourceSchema')} />
          <FieldError message={errors.sourceSchema} />
        </div>
        <div>
          <label className={labelClass}>Connection Type <span className="text-[#e60028]">*</span></label>
          <select value={s.connectionType} onChange={e => onChange('connectionType', e.target.value)} className={fieldClass(errors, 'connectionType')}>
            <option value="JDBC">JDBC</option>
            <option value="ODBC">ODBC</option>
            <option value="REST API">REST API</option>
            <option value="SFTP">SFTP</option>
            <option value="Kafka">Kafka</option>
          </select>
          <FieldError message={errors.connectionType} />
        </div>
        <div>
          <label className={labelClass}>Refresh Schedule <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.refreshSchedule} onChange={e => onChange('refreshSchedule', e.target.value)} placeholder="e.g. Every 6 hours" className={fieldClass(errors, 'refreshSchedule')} />
          <FieldError message={errors.refreshSchedule} />
        </div>
      </div>

      <SectionHeader title="Section B: Entitlements" description="Define access control and entitlement policies." />
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label className={labelClass}>CID Classification <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.cidClassification} onChange={e => onChange('cidClassification', e.target.value)} placeholder="e.g. Green" className={fieldClass(errors, 'cidClassification')} />
          <FieldError message={errors.cidClassification} />
        </div>
        <div>
          <label className={labelClass}>Access Control <span className="text-[#e60028]">*</span></label>
          <select value={s.accessControl} onChange={e => onChange('accessControl', e.target.value)} className={fieldClass(errors, 'accessControl')}>
            <option value="Role-Based">Role-Based</option>
            <option value="Attribute-Based">Attribute-Based</option>
            <option value="Group-Based">Group-Based</option>
          </select>
          <FieldError message={errors.accessControl} />
        </div>
        <div>
          <label className={labelClass}>High Performant <span className="text-[#e60028]">*</span></label>
          <select value={s.highPerformant} onChange={e => onChange('highPerformant', e.target.value)} className={fieldClass(errors, 'highPerformant')}>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
          <FieldError message={errors.highPerformant} />
        </div>
        <div>
          <label className={labelClass}>Own Entitlement Process <span className="text-[#e60028]">*</span></label>
          <select value={s.ownEntitlementProcess} onChange={e => onChange('ownEntitlementProcess', e.target.value)} className={fieldClass(errors, 'ownEntitlementProcess')}>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
          <FieldError message={errors.ownEntitlementProcess} />
        </div>
        <div>
          <label className={labelClass}>Entitlement Group <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.entitlementGroup} onChange={e => onChange('entitlementGroup', e.target.value)} placeholder="e.g. WMA-Data-Consumers" className={fieldClass(errors, 'entitlementGroup')} />
          <FieldError message={errors.entitlementGroup} />
        </div>
        <div>
          <label className={labelClass}>Entitlement Approver <span className="text-[#e60028]">*</span></label>
          <input type="email" value={s.entitlementApprover} onChange={e => onChange('entitlementApprover', e.target.value)} placeholder="approver@ubs.com" className={fieldClass(errors, 'entitlementApprover')} />
          <FieldError message={errors.entitlementApprover} />
        </div>
      </div>
    </div>
  );
}

/* ─── Step 4: Semantics & Data Quality (15 fields, 2 sections) */

function Step4({ errors, onChange }: StepProps) {
  const s = useRegistrationStore();
  return (
    <div>
      <SectionHeader title="Section A: Semantics" description="Link business glossary terms, ontologies, and semantic relationships." />
      <InfoTip>This step requires detailed input. You can save your progress and return later — all data is auto-saved.</InfoTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5 mb-8">
        <div>
          <label className={labelClass}>Business Entity <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.businessEntity} onChange={e => onChange('businessEntity', e.target.value)} placeholder="e.g. Customer Account" className={fieldClass(errors, 'businessEntity')} />
          <FieldError message={errors.businessEntity} />
        </div>
        <div>
          <label className={labelClass}>Glossary Terms <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.glossaryTerms} onChange={e => onChange('glossaryTerms', e.target.value)} placeholder="Link business glossary terms" className={fieldClass(errors, 'glossaryTerms')} />
          <FieldError message={errors.glossaryTerms} />
        </div>
        <div>
          <label className={labelClass}>Ontology Mapping <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.ontologyMapping} onChange={e => onChange('ontologyMapping', e.target.value)} placeholder="e.g. FIBO:Account" className={fieldClass(errors, 'ontologyMapping')} />
          <FieldError message={errors.ontologyMapping} />
        </div>
        <div>
          <label className={labelClass}>Semantic Tags <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.semanticTags} onChange={e => onChange('semanticTags', e.target.value)} placeholder="e.g. finance, accounts, WMA" className={fieldClass(errors, 'semanticTags')} />
          <FieldError message={errors.semanticTags} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Domain Model <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.domainModel} onChange={e => onChange('domainModel', e.target.value)} placeholder="Describe the domain model or link to documentation..." className={`${fieldClass(errors, 'domainModel')} resize-y`} />
          <FieldError message={errors.domainModel} />
        </div>
      </div>

      <SectionHeader title="Section B: Data Quality & Fitness" description="Define quality rules, targets, and fitness scoring." />
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label className={labelClass}>Data Scope <span className="text-[#e60028]">*</span></label>
          <select value={s.dataScope} onChange={e => onChange('dataScope', e.target.value)} className={fieldClass(errors, 'dataScope')}>
            <option value="Global">Global</option>
            <option value="Regional">Regional</option>
            <option value="Local">Local</option>
          </select>
          <FieldError message={errors.dataScope} />
        </div>
        <div>
          <label className={labelClass}>Refresh Frequency <span className="text-[#e60028]">*</span></label>
          <select value={s.refreshFrequency} onChange={e => onChange('refreshFrequency', e.target.value)} className={fieldClass(errors, 'refreshFrequency')}>
            <option value="Real-time">Real-time</option>
            <option value="Hourly">Hourly</option>
            <option value="Daily">Daily</option>
            <option value="Weekly">Weekly</option>
          </select>
          <FieldError message={errors.refreshFrequency} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Quality Rules <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.qualityRules} onChange={e => onChange('qualityRules', e.target.value)} placeholder="Define data quality validation rules..." className={`${fieldClass(errors, 'qualityRules')} resize-y`} />
          <FieldError message={errors.qualityRules} />
        </div>
        <div>
          <label className={labelClass}>Completeness Target <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.completenessTarget} onChange={e => onChange('completenessTarget', e.target.value)} placeholder="e.g. 99.5%" className={fieldClass(errors, 'completenessTarget')} />
          <FieldError message={errors.completenessTarget} />
        </div>
        <div>
          <label className={labelClass}>Accuracy Target <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.accuracyTarget} onChange={e => onChange('accuracyTarget', e.target.value)} placeholder="e.g. 99.9%" className={fieldClass(errors, 'accuracyTarget')} />
          <FieldError message={errors.accuracyTarget} />
        </div>
        <div>
          <label className={labelClass}>Timeliness Target <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.timelinessTarget} onChange={e => onChange('timelinessTarget', e.target.value)} placeholder="e.g. < 15 minutes" className={fieldClass(errors, 'timelinessTarget')} />
          <FieldError message={errors.timelinessTarget} />
        </div>
        <div>
          <label className={labelClass}>Consistency Rules <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.consistencyRules} onChange={e => onChange('consistencyRules', e.target.value)} placeholder="Define cross-field consistency" className={fieldClass(errors, 'consistencyRules')} />
          <FieldError message={errors.consistencyRules} />
        </div>
        <div>
          <label className={labelClass}>Uniqueness Rules <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.uniquenessRules} onChange={e => onChange('uniquenessRules', e.target.value)} placeholder="Define uniqueness constraints" className={fieldClass(errors, 'uniquenessRules')} />
          <FieldError message={errors.uniquenessRules} />
        </div>
        <div>
          <label className={labelClass}>Validity Rules <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.validityRules} onChange={e => onChange('validityRules', e.target.value)} placeholder="Define validity constraints" className={fieldClass(errors, 'validityRules')} />
          <FieldError message={errors.validityRules} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Fitness Score <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.fitnessScore} onChange={e => onChange('fitnessScore', e.target.value)} placeholder="e.g. 85/100" className={fieldClass(errors, 'fitnessScore')} />
          <FieldError message={errors.fitnessScore} />
        </div>
      </div>
    </div>
  );
}

/* ─── Step 5: Data Contract & Access (8 fields) ─────────── */

function Step5({ errors, onChange }: StepProps) {
  const s = useRegistrationStore();
  return (
    <div>
      <SectionHeader title="Service Level Agreement" description="Set the contractual guarantees between this data product and its consumers." />
      <HelpTip>Retention periods must comply with regulatory minimums for your data classification. Change notification days define advance notice required for breaking changes.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label className={labelClass}>Data Retention <span className="text-[#e60028]">*</span></label>
          <select value={s.dataRetention} onChange={e => onChange('dataRetention', e.target.value)} className={fieldClass(errors, 'dataRetention')}>
            <option value="7 years">7 years</option>
            <option value="5 years">5 years</option>
            <option value="3 years">3 years</option>
            <option value="1 year">1 year</option>
          </select>
          <FieldError message={errors.dataRetention} />
        </div>
        <div>
          <label className={labelClass}>SLA Uptime <span className="text-[#e60028]">*</span></label>
          <select value={s.slaUptime} onChange={e => onChange('slaUptime', e.target.value)} className={fieldClass(errors, 'slaUptime')}>
            <option value="99.9%">99.9%</option>
            <option value="99.5%">99.5%</option>
            <option value="99%">99%</option>
            <option value="95%">95%</option>
          </select>
          <FieldError message={errors.slaUptime} />
        </div>
        <div>
          <label className={labelClass}>Support Hours <span className="text-[#e60028]">*</span></label>
          <select value={s.supportHours} onChange={e => onChange('supportHours', e.target.value)} className={fieldClass(errors, 'supportHours')}>
            <option value="24/7">24/7</option>
            <option value="Business Hours">Business Hours</option>
            <option value="Extended Hours">Extended Hours</option>
          </select>
          <FieldError message={errors.supportHours} />
        </div>
        <div>
          <label className={labelClass}>Change Notification <span className="text-[#e60028]">*</span></label>
          <select value={s.changeNotificationDays} onChange={e => onChange('changeNotificationDays', e.target.value)} className={fieldClass(errors, 'changeNotificationDays')}>
            <option value="30 days">30 days</option>
            <option value="14 days">14 days</option>
            <option value="7 days">7 days</option>
            <option value="90 days">90 days</option>
          </select>
          <FieldError message={errors.changeNotificationDays} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Access Agreement <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.accessAgreement} onChange={e => onChange('accessAgreement', e.target.value)} placeholder="Define terms of data access and usage..." className={`${fieldClass(errors, 'accessAgreement')} resize-y`} />
          <FieldError message={errors.accessAgreement} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Escalation Path <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.escalationPath} onChange={e => onChange('escalationPath', e.target.value)} placeholder="e.g. L1 → Support Email → IT Lead → Owner" className={fieldClass(errors, 'escalationPath')} />
          <FieldError message={errors.escalationPath} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Breaking Changes Policy <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.breakingChangesPolicy} onChange={e => onChange('breakingChangesPolicy', e.target.value)} placeholder="Describe how breaking changes will be communicated..." className={`${fieldClass(errors, 'breakingChangesPolicy')} resize-y`} />
          <FieldError message={errors.breakingChangesPolicy} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Consumer Onboarding <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.consumerOnboarding} onChange={e => onChange('consumerOnboarding', e.target.value)} placeholder="Describe the onboarding process for new consumers..." className={`${fieldClass(errors, 'consumerOnboarding')} resize-y`} />
          <FieldError message={errors.consumerOnboarding} />
        </div>
      </div>
    </div>
  );
}

/* ─── Step 6: Lineage & Transformations (7 fields) ──────── */

function Step6({ errors, onChange }: StepProps) {
  const s = useRegistrationStore();
  return (
    <div>
      <SectionHeader title="Data Lineage" description="Document upstream sources and how data flows through transformation pipelines." />
      <HelpTip>Include all upstream dependencies, even indirect ones. This helps the platform trace impact when upstream sources change.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div className="col-span-2">
          <label className={labelClass}>Upstream Sources <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.upstreamSources} onChange={e => onChange('upstreamSources', e.target.value)} placeholder="List all upstream data sources..." className={`${fieldClass(errors, 'upstreamSources')} resize-y`} />
          <FieldError message={errors.upstreamSources} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Transformation Logic <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.transformationLogic} onChange={e => onChange('transformationLogic', e.target.value)} placeholder="Describe data transformations applied..." className={`${fieldClass(errors, 'transformationLogic')} resize-y`} />
          <FieldError message={errors.transformationLogic} />
        </div>
        <div>
          <label className={labelClass}>Upstream Owner <span className="text-[#e60028]">*</span></label>
          <input type="email" value={s.upstreamOwner} onChange={e => onChange('upstreamOwner', e.target.value)} placeholder="upstream-owner@ubs.com" className={fieldClass(errors, 'upstreamOwner')} />
          <FieldError message={errors.upstreamOwner} />
        </div>
        <div>
          <label className={labelClass}>Data Flow Diagram <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.dataFlowDiagram} onChange={e => onChange('dataFlowDiagram', e.target.value)} placeholder="Link to diagram or description" className={fieldClass(errors, 'dataFlowDiagram')} />
          <FieldError message={errors.dataFlowDiagram} />
        </div>
        <div>
          <label className={labelClass}>Processing Engine <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.processingEngine} onChange={e => onChange('processingEngine', e.target.value)} placeholder="e.g. Apache Spark, dbt" className={fieldClass(errors, 'processingEngine')} />
          <FieldError message={errors.processingEngine} />
        </div>
        <div>
          <label className={labelClass}>Latency Requirement <span className="text-[#e60028]">*</span></label>
          <input type="text" value={s.latencyRequirement} onChange={e => onChange('latencyRequirement', e.target.value)} placeholder="e.g. < 5 seconds" className={fieldClass(errors, 'latencyRequirement')} />
          <FieldError message={errors.latencyRequirement} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Error Handling <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.errorHandling} onChange={e => onChange('errorHandling', e.target.value)} placeholder="Describe error handling and retry strategies..." className={`${fieldClass(errors, 'errorHandling')} resize-y`} />
          <FieldError message={errors.errorHandling} />
        </div>
      </div>
    </div>
  );
}

/* ─── Step 7: Compliance & AI Readiness (11 fields, 2 sections) */

function Step7({ errors, onChange }: StepProps) {
  const s = useRegistrationStore();
  return (
    <div>
      <SectionHeader title="Section A: Compliance" description="Classify sensitivity and map to applicable regulatory frameworks." />
      <HelpTip>If the product contains PII, additional DLP controls will be automatically applied by the platform governance engine.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5 mb-8">
        <div>
          <label className={labelClass}>Data Classification <span className="text-[#e60028]">*</span></label>
          <select value={s.dataClassification} onChange={e => onChange('dataClassification', e.target.value)} className={fieldClass(errors, 'dataClassification')}>
            <option value="Highly Confidential">Highly Confidential</option>
            <option value="Confidential">Confidential</option>
            <option value="Internal">Internal</option>
            <option value="Public">Public</option>
          </select>
          <FieldError message={errors.dataClassification} />
        </div>
        <div>
          <label className={labelClass}>Contains PII <span className="text-[#e60028]">*</span></label>
          <select value={s.containsPII} onChange={e => onChange('containsPII', e.target.value)} className={fieldClass(errors, 'containsPII')}>
            <option value="Yes">Yes</option>
            <option value="No">No</option>
          </select>
          <FieldError message={errors.containsPII} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Regulatory Requirements <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.regulatoryRequirements} onChange={e => onChange('regulatoryRequirements', e.target.value)} placeholder="List applicable regulations (GDPR, SOX, etc.)..." className={`${fieldClass(errors, 'regulatoryRequirements')} resize-y`} />
          <FieldError message={errors.regulatoryRequirements} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>PII Handling Procedure <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} value={s.piiHandlingProcedure} onChange={e => onChange('piiHandlingProcedure', e.target.value)} placeholder="Describe PII masking, encryption, and handling procedures..." className={`${fieldClass(errors, 'piiHandlingProcedure')} resize-y`} />
          <FieldError message={errors.piiHandlingProcedure} />
        </div>
        <div>
          <label className={labelClass}>DPA Required <span className="text-[#e60028]">*</span></label>
          <select value={s.dpaRequired} onChange={e => onChange('dpaRequired', e.target.value)} className={fieldClass(errors, 'dpaRequired')}>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
          <FieldError message={errors.dpaRequired} />
        </div>
      </div>

      {/* Section B: AI Readiness — optional with muted bg */}
      <div className="rounded-xl bg-[#f9fafb] border border-[#f0f0f0] p-6">
        <div className="flex items-center gap-2.5 mb-4 pb-3 border-b border-[#e8e8ec]">
          <h3 className="text-[14px] font-semibold text-[#111]">Section B: AI Readiness</h3>
          <span className="text-[10px] font-semibold text-[#0284c7] bg-[#f0f9ff] border border-[#e0f2fe] px-2 py-0.5 rounded-full uppercase tracking-wide">
            Optional
          </span>
        </div>
        <InfoTip>Configure only if this data product will be consumed by AI/ML pipelines or feature stores.</InfoTip>
        <div className="grid grid-cols-2 gap-x-6 gap-y-5">
          <div>
            <label className={labelClass}>ML Feature Store</label>
            <select value={s.mlFeatureStore} onChange={e => onChange('mlFeatureStore', e.target.value)} className={inputOk}>
              <option value="Not Applicable">Not Applicable</option>
              <option value="Enabled">Enabled</option>
            </select>
          </div>
          <div>
            <label className={labelClass}>AI Model Usage</label>
            <select value={s.aiModelUsage} onChange={e => onChange('aiModelUsage', e.target.value)} className={inputOk}>
              <option value="Not Applicable">Not Applicable</option>
              <option value="Training">Training</option>
              <option value="Inference">Inference</option>
              <option value="Both">Both</option>
            </select>
          </div>
          <div>
            <label className={labelClass}>Embedding Support</label>
            <select value={s.embeddingSupport} onChange={e => onChange('embeddingSupport', e.target.value)} className={inputOk}>
              <option value="Not Applicable">Not Applicable</option>
              <option value="Supported">Supported</option>
            </select>
          </div>
          <div>
            <label className={labelClass}>Bias Assessment</label>
            <select value={s.biasAssessment} onChange={e => onChange('biasAssessment', e.target.value)} className={inputOk}>
              <option value="Not Applicable">Not Applicable</option>
              <option value="Completed">Completed</option>
              <option value="In Progress">In Progress</option>
              <option value="Required">Required</option>
            </select>
          </div>
          <div>
            <label className={labelClass}>Explainability Requirement</label>
            <select value={s.explainabilityRequirement} onChange={e => onChange('explainabilityRequirement', e.target.value)} className={inputOk}>
              <option value="Not Applicable">Not Applicable</option>
              <option value="Required">Required</option>
              <option value="Preferred">Preferred</option>
            </select>
          </div>
          <div>
            <label className={labelClass}>Model Governance</label>
            <select value={s.modelGovernance} onChange={e => onChange('modelGovernance', e.target.value)} className={inputOk}>
              <option value="Not Applicable">Not Applicable</option>
              <option value="Centralized">Centralized</option>
              <option value="Federated">Federated</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Step 8: Attestation & Submit (3 checkboxes + computed) ─ */

function Step8({ errors, onChange }: StepProps) {
  const s = useRegistrationStore();
  const stepCompletion = s.getStepCompletion();

  // Compute completion across steps 1-7
  const requiredSteps = stepCompletion.slice(0, 7);
  const totalFilled = requiredSteps.reduce((sum, step) => sum + step.filled, 0);
  const totalFields = requiredSteps.reduce((sum, step) => sum + step.total, 0);
  const allComplete = totalFilled === totalFields;

  // Computed reviewers from owner + dataSteward
  const reviewers = [s.owner, s.dataSteward].filter(Boolean).join(', ') || 'Not assigned';

  return (
    <div>
      <SectionHeader title="Final Review" description="Verify all information and submit for governance team review." />

      {/* Completion status banner */}
      <div className={`p-4 rounded-xl border mb-6 ${
        allComplete
          ? 'bg-[#f0fdf4] border-[#dcfce7]'
          : 'bg-[#fffbeb] border-[#fef3c7]'
      }`}>
        <h4 className={`text-[13px] font-semibold mb-1 ${
          allComplete ? 'text-[#15803d]' : 'text-[#92400e]'
        }`}>
          {allComplete ? 'Registration Ready' : 'Incomplete Fields'}
        </h4>
        <p className="text-[12px] text-[#6b7280]">
          {allComplete
            ? 'All required fields have been completed. Review your submission below.'
            : `${totalFilled} of ${totalFields} required fields completed across steps 1–7. Go back to fill missing fields.`}
        </p>
      </div>

      {/* Reviewers (computed read-only) */}
      <div className="mb-6 p-4 rounded-xl bg-[#f9fafb] border border-[#f0f0f0]">
        <label className="block text-[13px] font-medium text-[#374151] mb-1">Reviewers</label>
        <p className="text-[13px] text-[#6b7280]">{reviewers}</p>
        <p className="text-[11px] text-[#9ca3af] mt-1">Auto-populated from Owner and Data Steward</p>
      </div>

      {/* Attestation checkboxes */}
      <div className={`rounded-xl border p-5 space-y-4 ${
        errors.attestAccuracy || errors.attestOwnership || errors.attestPolicyCompliance
          ? 'border-[#ef4444]'
          : 'border-[#e8e8ec]'
      }`}>
        <h4 className="text-[13px] font-semibold text-[#111]">Attestation</h4>
        <div>
          <label className="flex items-start gap-3 cursor-pointer group">
            <input
              type="checkbox"
              data-field="attestAccuracy"
              checked={s.attestAccuracy}
              onChange={e => onChange('attestAccuracy', e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded border-[#d1d5db] text-[#e60028] focus:ring-[#e60028]"
            />
            <span className="text-[13px] text-[#6b7280]">
              I attest that the information provided is accurate and complete to the best of my knowledge.
            </span>
          </label>
          <FieldError message={errors.attestAccuracy} />
        </div>
        <div>
          <label className="flex items-start gap-3 cursor-pointer group">
            <input
              type="checkbox"
              data-field="attestOwnership"
              checked={s.attestOwnership}
              onChange={e => onChange('attestOwnership', e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded border-[#d1d5db] text-[#e60028] focus:ring-[#e60028]"
            />
            <span className="text-[13px] text-[#6b7280]">
              I confirm that I am the authorized owner or delegate for this data product registration.
            </span>
          </label>
          <FieldError message={errors.attestOwnership} />
        </div>
        <div>
          <label className="flex items-start gap-3 cursor-pointer group">
            <input
              type="checkbox"
              data-field="attestPolicyCompliance"
              checked={s.attestPolicyCompliance}
              onChange={e => onChange('attestPolicyCompliance', e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded border-[#d1d5db] text-[#e60028] focus:ring-[#e60028]"
            />
            <span className="text-[13px] text-[#6b7280]">
              I attest that this data product complies with all applicable UBS data governance policies and regulatory requirements.
            </span>
          </label>
          <FieldError message={errors.attestPolicyCompliance} />
        </div>
      </div>

      <div className="p-4 rounded-xl bg-[#fffbeb] border border-[#fef3c7] mt-6">
        <p className="text-[12px] text-[#92400e]">
          <span className="font-semibold">Next Steps:</span> After submission, your registration will be reviewed within 2-3 business days. You will receive email notifications on status updates.
        </p>
      </div>
    </div>
  );
}
