import { useState, useEffect } from 'react';
import { X, Search, Database, Loader2 } from 'lucide-react';
import { useMetaqDatasets, useMetaqDatasetByTitle } from '../hooks/useMetaqDatasets';
import type { MetaqDataset } from '../api/types';

interface DatasetBrowserProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (dataset: MetaqDataset) => void;
}

const CID_COLORS: Record<string, { bg: string; text: string; dot: string }> = {
  Green:  { bg: 'bg-[#f0fdf4]', text: 'text-[#15803d]', dot: 'bg-[#22c55e]' },
  Amber:  { bg: 'bg-[#fffbeb]', text: 'text-[#92400e]', dot: 'bg-[#f59e0b]' },
  Red:    { bg: 'bg-[#fef2f2]', text: 'text-[#991b1b]', dot: 'bg-[#ef4444]' },
};

export function DatasetBrowser({ isOpen, onClose, onSelect }: DatasetBrowserProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');

  // Debounce search — 300ms
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(searchTerm), 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Prevent body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  // Keyboard: Escape closes modal
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [isOpen]);

  // Fetch all datasets (initial list)
  const allQuery = useMetaqDatasets();
  // Fetch filtered datasets (when searching)
  const searchQuery = useMetaqDatasetByTitle(debouncedSearch);

  const isSearching = debouncedSearch.length >= 2;
  const datasets: MetaqDataset[] = isSearching
    ? (searchQuery.data as MetaqDataset[] | undefined) ?? []
    : (allQuery.data as MetaqDataset[] | undefined) ?? [];
  const isLoading = isSearching ? searchQuery.isLoading : allQuery.isLoading;

  const handleClose = () => {
    setSearchTerm('');
    onClose();
  };

  const handleSelect = (dataset: MetaqDataset) => {
    onSelect(dataset);
    handleClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={handleClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-[720px] max-h-[85vh] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden mx-4">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#e8e8ec]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#f0f9ff] rounded-lg border border-[#e0f2fe]">
              <Database className="w-4 h-4 text-[#0284c7]" />
            </div>
            <div>
              <h2 className="text-[15px] font-semibold text-[#111]">Import from MetaQ Catalog</h2>
              <p className="text-[12px] text-[#9ca3af]">Select a dataset to pre-fill your registration</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 text-[#9ca3af] hover:text-[#374151] hover:bg-[#f3f4f6] rounded-lg transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search */}
        <div className="px-6 py-3 border-b border-[#f0f0f0]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9ca3af]" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search datasets by title or name..."
              className="w-full pl-9 pr-4 py-2.5 text-[13px] border border-[#e5e7eb] rounded-lg bg-white hover:border-[#c0c0c0] focus:border-[#0284c7] focus:ring-2 focus:ring-[#0284c7]/10 focus:outline-none transition-all placeholder:text-[#c0c0c0]"
              autoFocus
            />
          </div>
        </div>

        {/* Dataset list */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12 text-[#9ca3af]">
              <Loader2 className="w-6 h-6 animate-spin mb-2" />
              <p className="text-[13px]">Loading datasets...</p>
            </div>
          ) : datasets.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-[#9ca3af]">
              <Database className="w-8 h-8 mb-2 text-[#d1d5db]" />
              <p className="text-[13px] font-medium">No datasets found</p>
              <p className="text-[12px] mt-1">Try a different search term</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {datasets.map((dataset) => {
                const cid = dataset.cidstaterag ?? '';
                const cidStyle = CID_COLORS[cid] ?? { bg: 'bg-[#f3f4f6]', text: 'text-[#6b7280]', dot: 'bg-[#9ca3af]' };

                return (
                  <button
                    key={dataset.dataset_title}
                    onClick={() => handleSelect(dataset)}
                    className="w-full text-left p-4 rounded-xl border border-[#e5e7eb] hover:border-[#0284c7] hover:bg-[#f8fbff] transition-all group"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        {/* Title + CID badge */}
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[13px] font-semibold text-[#111] group-hover:text-[#0284c7] transition-colors truncate">
                            {dataset.dataset_title}
                          </span>
                          {cid && (
                            <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full ${cidStyle.bg} ${cidStyle.text}`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${cidStyle.dot}`} />
                              {cid}
                            </span>
                          )}
                        </div>

                        {/* Name */}
                        {dataset.name && (
                          <p className="text-[12px] text-[#6b7280] mb-1">{dataset.name}</p>
                        )}

                        {/* Description */}
                        {dataset.description ? (
                          <p className="text-[12px] text-[#6b7280] line-clamp-2">{dataset.description}</p>
                        ) : (
                          <p className="text-[12px] text-[#d1d5db] italic">No description</p>
                        )}

                        {/* Metadata chips */}
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          {dataset.ontologyname && (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-[#f3f4f6] text-[#6b7280] border border-[#e5e7eb]">
                              {dataset.ontologyname}
                            </span>
                          )}
                          {dataset.kde && (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-[#f3f4f6] text-[#6b7280] border border-[#e5e7eb] truncate max-w-[200px]">
                              KDE: {dataset.kde}
                            </span>
                          )}
                          {dataset.cidcategory && (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-[#f3f4f6] text-[#6b7280] border border-[#e5e7eb]">
                              {dataset.cidcategory}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Select indicator */}
                      <span className="text-[11px] font-medium text-[#0284c7] opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap mt-1">
                        Select &rarr;
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#f0f0f0] bg-[#fafafa]">
          <p className="text-[11px] text-[#9ca3af]">
            {datasets.length} dataset{datasets.length !== 1 ? 's' : ''} available
            {isSearching && ` matching "${debouncedSearch}"`}
          </p>
        </div>
      </div>
    </div>
  );
}
