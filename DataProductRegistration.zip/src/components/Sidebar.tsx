import ubsLogo from 'figma:asset/00ac1239b9b421f7eee8b4e260132b1ac860676a.png';
import { CheckCircle2, Clock } from 'lucide-react';
import { useRegistrationStore } from '../stores/useRegistrationStore';

interface SidebarProps {
  currentStep: number;
  onStepChange: (step: number) => void;
}

const STEP_META = [
  { title: "Identity & Purpose", sub: "Name, type, domain, version", required: true },
  { title: "Ownership", sub: "Contacts, unit & cost center", required: true },
  { title: "Source & Entitle.", sub: "Connection & access control", required: true },
  { title: "Semantics & DQ", sub: "Metadata, quality & fitness", required: true },
  { title: "Contract & Access", sub: "SLA, retention & onboarding", required: true },
  { title: "Lineage", sub: "Sources & transformations", required: true },
  { title: "Compliance & AI", sub: "Policy, PII & AI readiness", required: true },
  { title: "Submit", sub: "Attestations & review", required: true },
];

export function Sidebar({ currentStep, onStepChange }: SidebarProps) {
  const store = useRegistrationStore();
  const stepCompletion = store.getStepCompletion();

  const steps = STEP_META.map((meta, i) => ({
    id: i + 1,
    ...meta,
    filled: stepCompletion[i]?.filled ?? 0,
    total: stepCompletion[i]?.total ?? 1,
  }));

  const requiredSteps = steps.filter(s => s.required);
  const totalFilled = requiredSteps.reduce((sum, step) => sum + step.filled, 0);
  const totalFields = requiredSteps.reduce((sum, step) => sum + step.total, 0);
  const overallProgress = Math.round((totalFilled / totalFields) * 100);

  // Circular progress
  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (overallProgress / 100) * circumference;

  const getStepAccessibility = (stepId: number) => {
    if (stepId === 1) return true;
    const previousSteps = steps.filter(s => s.id < stepId && s.required);
    return previousSteps.every(s => s.filled === s.total);
  };

  const handleStepClick = (stepId: number) => {
    if (getStepAccessibility(stepId)) {
      onStepChange(stepId);
    }
  };

  return (
    <div className="w-[290px] min-w-[290px] bg-white flex flex-col overflow-y-auto border-r border-[#e8e8ec]">
      {/* Logo Section — clean divider treatment */}
      <div className="h-14 min-h-14 px-5 flex items-center border-b border-[#e8e8ec]">
        <div className="flex items-center gap-3">
          <img src={ubsLogo} alt="UBS" className="h-8" />
          <div className="w-px h-6 bg-[#e0e0e0]" />
          <div className="flex flex-col">
            <span className="text-[13px] font-semibold text-[#111] tracking-tight leading-tight">WMA Data Platform</span>
            <span className="text-[11px] text-[#9ca3af] font-medium leading-tight">Product Registration</span>
          </div>
        </div>
      </div>

      {/* Circular Progress */}
      <div className="flex flex-col items-center py-6 border-b border-[#f0f0f0]">
        <div className="relative w-[120px] h-[120px]">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 112 112">
            {/* Defs for 3D tube gradients and filters */}
            <defs>
              {/* Background track tube gradient — light from top */}
              <linearGradient id="tubeTrackGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#ececec" />
                <stop offset="35%" stopColor="#f5f5f6" />
                <stop offset="65%" stopColor="#ededee" />
                <stop offset="100%" stopColor="#dcdcdd" />
              </linearGradient>
              {/* Red arc tube gradient — highlight on top, shadow on bottom */}
              <linearGradient id="tubeRedGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#ff5a6a" />
                <stop offset="30%" stopColor="#e60028" />
                <stop offset="70%" stopColor="#d40024" />
                <stop offset="100%" stopColor="#a3001d" />
              </linearGradient>
              {/* Highlight overlay gradient for specular reflection */}
              <linearGradient id="tubeHighlight" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="white" stopOpacity="0.45" />
                <stop offset="50%" stopColor="white" stopOpacity="0" />
                <stop offset="100%" stopColor="black" stopOpacity="0.08" />
              </linearGradient>
              {/* Subtle drop shadow for depth */}
              <filter id="tubeShadow" x="-10%" y="-10%" width="120%" height="120%">
                <feDropShadow dx="0" dy="1" stdDeviation="1.2" floodColor="#000" floodOpacity="0.08" />
              </filter>
            </defs>

            {/* Background track — shadow layer */}
            <circle
              cx="56" cy="56" r={radius}
              fill="rgba(230, 0, 40, 0.03)"
              stroke="url(#tubeTrackGrad)" strokeWidth="8"
              strokeLinecap="round"
              filter="url(#tubeShadow)"
            />
            {/* Background track — highlight overlay */}
            <circle
              cx="56" cy="56" r={radius}
              fill="none"
              stroke="url(#tubeHighlight)" strokeWidth="8"
              strokeLinecap="round"
            />

            {/* Red progress arc — main 3D tube */}
            <circle
              cx="56" cy="56" r={radius}
              fill="none" stroke="url(#tubeRedGrad)" strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              filter="url(#tubeShadow)"
              className="transition-all duration-700 ease-out"
            />
            {/* Red progress arc — specular highlight layer */}
            <circle
              cx="56" cy="56" r={radius}
              fill="none"
              stroke="url(#tubeHighlight)" strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              className="transition-all duration-700 ease-out"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-[26px] font-bold text-[#e60028] leading-none">{overallProgress}%</span>
            <span className="text-[11px] text-[#9ca3af] mt-1">Complete</span>
          </div>
        </div>
        {/* removed "X of Y required fields" text */}
      </div>

      {/* Steps */}
      <div className="flex-1 px-3.5 pt-4 pb-4">
        <div className="px-1.5 mb-3">
          <span className="text-[10px] text-[#b0b0b0] uppercase tracking-[0.1em] font-semibold">Registration Steps</span>
        </div>
        <ol className="space-y-1.5">
          {steps.map((step) => {
            const isCompleted = step.filled === step.total;
            const isActive = step.id === currentStep;
            const isInProgress = step.filled > 0 && step.filled < step.total;
            const progressPercent = Math.round((step.filled / step.total) * 100);
            const isAccessible = getStepAccessibility(step.id);

            return (
              <li
                key={step.id}
                onClick={() => handleStepClick(step.id)}
                className={`rounded-xl p-3 transition-all duration-200 ${
                  isAccessible ? 'cursor-pointer' : 'cursor-not-allowed opacity-40'
                } ${
                  isActive
                    ? 'bg-white border-2 border-[#e60028] shadow-[0_2px_12px_rgba(230,0,40,0.08)]'
                    : isCompleted
                    ? 'bg-[#f0fdf4] border border-[#dcfce7] hover:border-[#86efac]'
                    : isInProgress
                    ? 'bg-white border border-[#fef3c7] hover:border-[#fbbf24]'
                    : 'bg-[#fafafa] border border-[#f0f0f0] hover:bg-white hover:border-[#e0e0e0]'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  {/* Step circle */}
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-bold flex-shrink-0 mt-0.5 ${
                    isCompleted
                      ? 'bg-[#22c55e] text-white'
                      : isActive
                      ? 'bg-[#e60028] text-white'
                      : isInProgress
                      ? 'bg-[#fbbf24] text-white'
                      : 'bg-white border-2 border-[#e0e0e0] text-[#b0b0b0]'
                  }`}>
                    {isCompleted ? <CheckCircle2 className="w-3.5 h-3.5" /> : step.id}
                  </div>

                  {/* Step info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <span className={`text-[13px] font-semibold truncate ${
                        isCompleted ? 'text-[#16a34a]' : isActive ? 'text-[#111]' : 'text-[#333]'
                      }`}>
                        {step.title}
                      </span>
                      {!step.required && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#f0f9ff] text-[#0284c7] border border-[#e0f2fe] font-semibold uppercase flex-shrink-0">opt</span>
                      )}
                      {isActive && (
                        <Clock className="w-3.5 h-3.5 text-[#d1d5db] flex-shrink-0" />
                      )}
                    </div>
                    <span className="text-[11px] text-[#9ca3af] block mt-0.5">{step.sub}</span>
                    {/* Progress row */}
                    <div className="flex items-center justify-between mt-2">
                      <span className={`text-[11px] font-medium ${
                        isCompleted ? 'text-[#16a34a]' : isInProgress ? 'text-[#f59e0b]' : 'text-[#c0c0c0]'
                      }`}>
                        {step.filled}/{step.total} fields
                      </span>
                      <span className={`text-[11px] font-semibold ${
                        isCompleted ? 'text-[#16a34a]' : isInProgress ? 'text-[#f59e0b]' : 'text-[#c0c0c0]'
                      }`}>
                        {progressPercent}%
                      </span>
                    </div>
                    {/* Mini progress bar */}
                    <div className={`h-1 rounded-full overflow-hidden mt-1.5 ${
                      isCompleted ? 'bg-[#dcfce7]' : 'bg-[#f3f4f6]'
                    }`}>
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isCompleted ? 'bg-[#22c55e]' : isInProgress ? 'bg-[#fbbf24]' : 'bg-[#e5e7eb]'
                        }`}
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>
                  </div>
                </div>
              </li>
            );
          })}
        </ol>
      </div>

      {/* Bottom status */}
      <div className="px-5 py-4 border-t border-[#f0f0f0]">
        <div className="flex items-center gap-2 mb-2">
          <div className={`w-2 h-2 rounded-full ${overallProgress === 100 ? 'bg-[#22c55e]' : 'bg-[#e60028] animate-pulse'}`} />
          <span className="text-[12px] text-[#6b7280] font-medium">
            {overallProgress === 100 ? 'Ready to Submit' : 'Draft — In Progress'}
          </span>
        </div>
        <span className="text-[11px] text-[#b0b0b0]">Step {currentStep} of 8 · {8 - currentStep} remaining</span>
      </div>
    </div>
  );
}