import { ChevronRight, ChevronLeft, Package, Users, Link2, Database, FileText, GitBranch, Shield, Send } from 'lucide-react';
import { useRegistrationStore } from '../stores/useRegistrationStore';

interface SummaryPanelProps {
  isOpen: boolean;
  onToggle: () => void;
}

export function SummaryPanel({ isOpen, onToggle }: SummaryPanelProps) {
  const s = useRegistrationStore();
  const emDash = '\u2014';
  const v = (val: string) => val?.trim() || emDash;

  const sections = [
    {
      icon: Package,
      title: 'Identity & Purpose',
      fields: [
        { label: 'Name', value: v(s.productName) },
        { label: 'Type', value: v(s.productType) },
        { label: 'Domain', value: v(s.businessDomain) },
        { label: 'Short Desc', value: v(s.shortDescription) },
        { label: 'Long Desc', value: v(s.longDescription) },
        { label: 'Version', value: v(s.productVersion) },
        { label: 'Category', value: v(s.dataCategory) },
        { label: 'Purpose', value: v(s.businessPurpose) },
      ],
    },
    {
      icon: Users,
      title: 'Ownership & Support',
      fields: [
        { label: 'Owner', value: v(s.owner) },
        { label: 'Backup', value: v(s.backupOwner) },
        { label: 'IT Lead', value: v(s.itLead) },
        { label: 'Steward', value: v(s.dataSteward) },
        { label: 'Support Email', value: v(s.supportEmail) },
        { label: 'Business Unit', value: v(s.businessUnit) },
        { label: 'Cost Center', value: v(s.costCenter) },
      ],
    },
    {
      icon: Link2,
      title: 'Source & Entitlements',
      fields: [
        { label: 'Source URL', value: v(s.sourceUrl) },
        { label: 'Environment', value: v(s.environment) },
        { label: 'Source System', value: v(s.sourceSystem) },
        { label: 'Database', value: v(s.sourceDatabase) },
        { label: 'Schema', value: v(s.sourceSchema) },
        { label: 'Connection', value: v(s.connectionType) },
        { label: 'Refresh', value: v(s.refreshSchedule) },
        { label: 'CID Class', value: v(s.cidClassification) },
        { label: 'Access', value: v(s.accessControl) },
        { label: 'High Perf.', value: v(s.highPerformant) },
        { label: 'Own Entitle.', value: v(s.ownEntitlementProcess) },
        { label: 'Entitle. Group', value: v(s.entitlementGroup) },
        { label: 'Approver', value: v(s.entitlementApprover) },
      ],
    },
    {
      icon: Database,
      title: 'Semantics & DQ',
      fields: [
        { label: 'Entity', value: v(s.businessEntity) },
        { label: 'Terms', value: v(s.glossaryTerms) },
        { label: 'Ontology', value: v(s.ontologyMapping) },
        { label: 'Tags', value: v(s.semanticTags) },
        { label: 'Domain Model', value: v(s.domainModel) },
        { label: 'Scope', value: v(s.dataScope) },
        { label: 'Refresh Freq', value: v(s.refreshFrequency) },
        { label: 'Quality Rules', value: v(s.qualityRules) },
        { label: 'Completeness', value: v(s.completenessTarget) },
        { label: 'Accuracy', value: v(s.accuracyTarget) },
        { label: 'Timeliness', value: v(s.timelinessTarget) },
        { label: 'Consistency', value: v(s.consistencyRules) },
        { label: 'Uniqueness', value: v(s.uniquenessRules) },
        { label: 'Validity', value: v(s.validityRules) },
        { label: 'Fitness Score', value: v(s.fitnessScore) },
      ],
    },
    {
      icon: FileText,
      title: 'Contract & Access',
      fields: [
        { label: 'Retention', value: v(s.dataRetention) },
        { label: 'Agreement', value: v(s.accessAgreement) },
        { label: 'SLA Uptime', value: v(s.slaUptime) },
        { label: 'Support Hours', value: v(s.supportHours) },
        { label: 'Escalation', value: v(s.escalationPath) },
        { label: 'Change Notice', value: v(s.changeNotificationDays) },
        { label: 'Breaking Chg', value: v(s.breakingChangesPolicy) },
        { label: 'Onboarding', value: v(s.consumerOnboarding) },
      ],
    },
    {
      icon: GitBranch,
      title: 'Lineage',
      fields: [
        { label: 'Upstream', value: v(s.upstreamSources) },
        { label: 'Transform', value: v(s.transformationLogic) },
        { label: 'Upstream Owner', value: v(s.upstreamOwner) },
        { label: 'Flow Diagram', value: v(s.dataFlowDiagram) },
        { label: 'Engine', value: v(s.processingEngine) },
        { label: 'Latency', value: v(s.latencyRequirement) },
        { label: 'Error Handling', value: v(s.errorHandling) },
      ],
    },
    {
      icon: Shield,
      title: 'Compliance & AI',
      fields: [
        { label: 'Classification', value: v(s.dataClassification) },
        { label: 'PII', value: v(s.containsPII) },
        { label: 'Regulatory', value: v(s.regulatoryRequirements) },
        { label: 'PII Handling', value: v(s.piiHandlingProcedure) },
        { label: 'DPA Required', value: v(s.dpaRequired) },
        { label: 'Feature Store', value: v(s.mlFeatureStore) },
        { label: 'AI Model', value: v(s.aiModelUsage) },
        { label: 'Embeddings', value: v(s.embeddingSupport) },
        { label: 'Bias', value: v(s.biasAssessment) },
        { label: 'Explainability', value: v(s.explainabilityRequirement) },
        { label: 'Model Gov.', value: v(s.modelGovernance) },
      ],
    },
    {
      icon: Send,
      title: 'Attestation',
      fields: [
        { label: 'Accuracy', value: s.attestAccuracy ? 'Attested' : emDash },
        { label: 'Ownership', value: s.attestOwnership ? 'Attested' : emDash },
        { label: 'Policy', value: s.attestPolicyCompliance ? 'Attested' : emDash },
      ],
    },
  ];

  return (
    <>
      {/* Toggle button */}
      <button
        onClick={onToggle}
        className="fixed top-1/2 -translate-y-1/2 z-30 flex items-center gap-1 px-1.5 py-3 bg-white border border-r-0 border-[#e5e7eb] rounded-l-lg shadow-sm hover:bg-[#f9fafb] transition-all"
        style={{ right: isOpen ? '300px' : '0px' }}
      >
        {isOpen ? (
          <ChevronRight className="w-3.5 h-3.5 text-[#6b7280]" />
        ) : (
          <ChevronLeft className="w-3.5 h-3.5 text-[#6b7280]" />
        )}
      </button>

      {/* Panel */}
      <div
        className="fixed right-0 top-0 h-full w-[300px] bg-white border-l border-[#e8e8ec] z-20 transition-transform duration-300 ease-out"
        style={{
          transform: isOpen ? 'translateX(0)' : 'translateX(100%)',
          boxShadow: isOpen ? '-4px 0 24px rgba(0,0,0,0.04)' : 'none',
        }}
      >
        <div className="h-full overflow-y-auto">
          {/* Header */}
          <div className="sticky top-0 bg-white px-5 pt-5 pb-3 border-b border-[#f0f0f0]">
            <div className="flex items-center justify-between">
              <h3 className="text-[14px] font-semibold text-[#111]">Registration Summary</h3>
              <span className="text-[11px] text-[#9ca3af] font-medium bg-[#f3f4f6] px-2 py-0.5 rounded">Live Preview</span>
            </div>
          </div>

          {/* Sections */}
          <div className="px-5 py-4 space-y-4">
            {sections.map((section) => {
              const Icon = section.icon;
              const hasData = section.fields.some(f => f.value !== emDash && f.value !== '');
              return (
                <div key={section.title} className="rounded-lg border border-[#f0f0f0] overflow-hidden">
                  {/* Section header */}
                  <div className={`flex items-center gap-2 px-3.5 py-2.5 ${hasData ? 'bg-[#f0fdf4]' : 'bg-[#fafafa]'}`}>
                    <Icon className={`w-3.5 h-3.5 ${hasData ? 'text-[#22c55e]' : 'text-[#c0c0c0]'}`} />
                    <span className={`text-[12px] font-semibold ${hasData ? 'text-[#15803d]' : 'text-[#999]'}`}>
                      {section.title}
                    </span>
                    {hasData && (
                      <span className="ml-auto text-[10px] text-[#22c55e] font-medium">
                        {section.fields.filter(f => f.value !== emDash).length}/{section.fields.length}
                      </span>
                    )}
                  </div>

                  {/* Fields */}
                  {section.fields.length > 0 ? (
                    <div className="px-3.5 py-2 space-y-1.5">
                      {section.fields.map((field) => (
                        <div key={field.label} className="flex items-baseline justify-between gap-2">
                          <span className="text-[11px] text-[#9ca3af] flex-shrink-0">{field.label}</span>
                          <span className={`text-[11px] text-right truncate max-w-[150px] ${
                            field.value === emDash ? 'text-[#d1d5db] italic' : 'text-[#374151] font-medium'
                          }`}>
                            {field.value}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="px-3.5 py-2.5">
                      <span className="text-[11px] text-[#d1d5db] italic">Not started</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
