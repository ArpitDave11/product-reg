import { Shield } from "lucide-react";
import { useAuth } from "../auth/useAuth";

export default function LoginPage() {
  const { login } = useAuth();

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-[#f8f8fa]">
      <div className="w-full max-w-[400px] mx-4">
        <div className="bg-white rounded-xl shadow-[0_2px_16px_rgba(0,0,0,0.08)] p-8 text-center">
          {/* Branding */}
          <div className="mb-6">
            <div className="w-12 h-12 mx-auto mb-4 rounded-xl bg-[#e60028] flex items-center justify-center">
              <span className="text-white font-bold text-[18px]">W</span>
            </div>
            <h1 className="text-[20px] font-semibold text-[#111]">
              WMA Data Platform
            </h1>
            <p className="mt-1 text-[14px] text-[#6b7280]">
              Product Registration Portal
            </p>
          </div>

          {/* Sign in button */}
          <button
            onClick={() => login()}
            className="w-full flex items-center justify-center gap-2.5 px-4 py-3 bg-[#111] text-white text-[14px] font-medium rounded-lg hover:bg-[#333] transition-colors cursor-pointer"
          >
            <svg width="18" height="18" viewBox="0 0 21 21" fill="none">
              <rect x="1" y="1" width="9" height="9" fill="#F25022" />
              <rect x="11" y="1" width="9" height="9" fill="#7FBA00" />
              <rect x="1" y="11" width="9" height="9" fill="#00A4EF" />
              <rect x="11" y="11" width="9" height="9" fill="#FFB900" />
            </svg>
            Sign in with Microsoft
          </button>

          {/* Footer */}
          <div className="mt-6 flex items-center justify-center gap-1.5 text-[12px] text-[#9ca3af]">
            <Shield className="w-3.5 h-3.5" />
            <span>Protected by Azure Active Directory</span>
          </div>
        </div>
      </div>
    </div>
  );
}
