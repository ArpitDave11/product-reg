interface LoadingSpinnerProps {
  message?: string;
}

export default function LoadingSpinner({
  message = "Loading...",
}: LoadingSpinnerProps) {
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-white">
      <div className="w-10 h-10 border-[3px] border-[#e5e7eb] border-t-[#e60028] rounded-full animate-spin" />
      <p className="mt-4 text-[14px] text-[#6b7280] font-medium">{message}</p>
    </div>
  );
}
