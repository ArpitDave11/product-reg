import axios from "axios";
import { API_CONFIG, isMockMode } from "../config/apiConfig";
import { tokenRequest } from "../config/authConfig";

// ── Axios Instances ─────────────────────────────────────────────

export const metaqClient = axios.create({
  baseURL: API_CONFIG.metaq.baseUrl,
  headers: { Accept: "application/json" },
  timeout: 30_000,
});

export const dpasClient = axios.create({
  baseURL: API_CONFIG.dpas.baseUrl,
  headers: { Accept: "application/json" },
  timeout: 30_000,
});

// ── Request Interceptor: Attach Bearer Token ────────────────────

async function attachToken(config: import("axios").InternalAxiosRequestConfig) {
  if (isMockMode()) {
    const { MOCK_TOKEN } = await import("../mocks/mockAuth");
    config.headers.Authorization = `Bearer ${MOCK_TOKEN}`;
    return config;
  }

  // Real mode: import msalInstance and acquire token silently
  try {
    const { msalInstance } = await import("../auth/MsalProviderWrapper");
    const account = msalInstance.getActiveAccount();
    if (account) {
      const response = await msalInstance.acquireTokenSilent({
        ...tokenRequest,
        account,
      });
      config.headers.Authorization = `Bearer ${response.accessToken}`;
    }
  } catch (error) {
    console.error("[HTTP] Token acquisition failed:", error);
  }

  return config;
}

metaqClient.interceptors.request.use(attachToken);
dpasClient.interceptors.request.use(attachToken);

// ── Response Interceptor: Handle Errors ─────────────────────────

function handleResponseError(error: unknown) {
  if (!axios.isAxiosError(error) || !error.response) {
    return Promise.reject(error);
  }

  const { status, data } = error.response;

  // 401: trigger re-auth in real mode
  if (status === 401 && !isMockMode()) {
    import("../auth/MsalProviderWrapper").then(({ msalInstance }) => {
      msalInstance.loginRedirect();
    });
  }

  // Enhance the original error with API message while preserving response
  const apiMessage =
    data?.message || data?.error || `Request failed with status ${status}`;
  error.message = apiMessage;
  (error as typeof error & { status: number }).status = status;

  return Promise.reject(error);
}

metaqClient.interceptors.response.use((r) => r, handleResponseError);
dpasClient.interceptors.response.use((r) => r, handleResponseError);
