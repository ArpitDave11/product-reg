import { metaqClient } from "./httpClient";
import { API_CONFIG } from "../config/apiConfig";
import type { MetaqDataset, MetaqHealthResponse } from "./types";

const { endpoints } = API_CONFIG.metaq;

interface ListParams {
  limit?: number;
  offset?: number;
}

interface UpsertPayload {
  p_dataset_data: {
    resource_iri: string;
    title: string;
    description: string;
    status: string;
  };
  p_internal: {
    source_system_code: string;
    owner_team: string;
  };
}

export const metaqService = {
  /** GET /health */
  async health(): Promise<MetaqHealthResponse> {
    const { data } = await metaqClient.get<MetaqHealthResponse>(
      endpoints.health
    );
    return data;
  },

  /** GET /datasets — returns array of datasets. Handles both array and { items: [...] } response shapes. */
  async listDatasets(params?: ListParams): Promise<MetaqDataset[]> {
    const { data } = await metaqClient.get(endpoints.datasets, {
      params: { limit: params?.limit ?? 100, offset: params?.offset ?? 0 },
    });
    // Handle varying response shapes
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.items)) return data.items;
    if (Array.isArray(data?.results)) return data.results;
    return [];
  },

  /** GET /dataset/:title — search by title. Handles single object or array response. */
  async getByTitle(title: string): Promise<MetaqDataset[]> {
    const { data } = await metaqClient.get(endpoints.datasetByTitle(title));
    if (Array.isArray(data)) return data;
    if (data && typeof data === "object") return [data as MetaqDataset];
    return [];
  },

  /** POST / — upsert enriched metadata back to MetaQ */
  async upsertDataset(payload: UpsertPayload): Promise<unknown> {
    const { data } = await metaqClient.post(endpoints.upsert, payload);
    return data;
  },
};
