// ── DPAS Types ──────────────────────────────────────────────────

export type DataProductStatus = "draft" | "published" | "retired";

export interface DataProduct {
  resource_iri: string;
  resource_id: string;
  title: string;
  description: string | null;
  status: DataProductStatus;
  source_system_code: string;
  owner: string;
  created_at: string;
  updated_at: string;
}

export interface DataProductCreatePayload {
  title: string;
  owner: string;
  source_system_code: string;
  description?: string;
  status?: DataProductStatus;
}

export interface DataProductUpdatePayload {
  description?: string;
  status?: DataProductStatus;
  source_system_code?: string;
  owner?: string;
}

export interface DataProductListResponse {
  items: DataProduct[];
  total: number;
  page: number;
  pageSize: number;
}

export interface ApiErrorResponse {
  error: string;
  message: string;
  timestamp: string;
}

// ── MetaQ Types ─────────────────────────────────────────────────

export interface MetaqDataset {
  dataset_title: string | null;
  name: string | null;
  description: string | null;
  sourcedescription: string | null;
  aigenerateddescription: string | null;
  ontologyid: string | null;
  ontologyname: string | null;
  cidstaterag: string | null;
  cidcategory: string | null;
  cidjustification: string | null;
  kde: string | null;
  dqobject: string | null;
  recommendedusage: string | null;
  [key: string]: unknown;
}

export interface MetaqHealthResponse {
  status: string;
}

// ── Wizard Form State (8 Steps, 72 stored fields) ──────────────

export interface WizardFormState {
  // Step 1 – Product Identity & Purpose (8 fields)
  productName: string;
  productType: string;
  businessDomain: string;
  shortDescription: string;
  longDescription: string;
  productVersion: string;
  dataCategory: string;
  businessPurpose: string;

  // Step 2 – Ownership & Support (7 fields)
  owner: string;
  backupOwner: string;
  itLead: string;
  dataSteward: string;
  supportEmail: string;
  businessUnit: string;
  costCenter: string;

  // Step 3 – Source & Entitlements (13 fields)
  // Section A: Source Config
  sourceUrl: string;
  environment: string;
  sourceSystem: string;
  sourceDatabase: string;
  sourceSchema: string;
  connectionType: string;
  refreshSchedule: string;
  // Section B: Entitlements
  cidClassification: string;
  accessControl: string;
  highPerformant: string;
  ownEntitlementProcess: string;
  entitlementGroup: string;
  entitlementApprover: string;

  // Step 4 – Semantics & Data Quality (15 fields)
  // Section A: Semantics
  businessEntity: string;
  glossaryTerms: string;
  ontologyMapping: string;
  semanticTags: string;
  domainModel: string;
  // Section B: DQ & Fitness
  dataScope: string;
  refreshFrequency: string;
  qualityRules: string;
  completenessTarget: string;
  accuracyTarget: string;
  timelinessTarget: string;
  consistencyRules: string;
  uniquenessRules: string;
  validityRules: string;
  fitnessScore: string;

  // Step 5 – Data Contract & Access (8 fields)
  dataRetention: string;
  accessAgreement: string;
  slaUptime: string;
  supportHours: string;
  escalationPath: string;
  changeNotificationDays: string;
  breakingChangesPolicy: string;
  consumerOnboarding: string;

  // Step 6 – Lineage & Transformations (7 fields)
  upstreamSources: string;
  transformationLogic: string;
  upstreamOwner: string;
  dataFlowDiagram: string;
  processingEngine: string;
  latencyRequirement: string;
  errorHandling: string;

  // Step 7 – Compliance & AI Readiness (11 fields)
  // Section A: Compliance
  dataClassification: string;
  containsPII: string;
  regulatoryRequirements: string;
  piiHandlingProcedure: string;
  dpaRequired: string;
  // Section B: AI Readiness (optional)
  mlFeatureStore: string;
  aiModelUsage: string;
  embeddingSupport: string;
  biasAssessment: string;
  explainabilityRequirement: string;
  modelGovernance: string;

  // Step 8 – Attestation & Submit (3 checkboxes)
  attestAccuracy: boolean;
  attestOwnership: boolean;
  attestPolicyCompliance: boolean;

  // ── Metadata (set programmatically) ───────────────────────────
  dpasResourceId: string | null;
  dpasResourceIri: string | null;
  dpasEtag: string | null;
  metaqSource: string | null;
  lastSavedAt: string | null;
}
