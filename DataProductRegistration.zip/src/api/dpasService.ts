import { dpasClient } from "./httpClient";
import { API_CONFIG } from "../config/apiConfig";
import type {
  DataProduct,
  DataProductCreatePayload,
  DataProductUpdatePayload,
  DataProductListResponse,
} from "./types";

const { endpoints } = API_CONFIG.dpas;

interface ListParams {
  page?: number;
  pageSize?: number;
  status?: string;
  owner?: string;
}

export const dpasService = {
  /** GET /dataproducts — paginated list with optional filters */
  async list(params?: ListParams): Promise<DataProductListResponse> {
    const { data } = await dpasClient.get<DataProductListResponse>(
      endpoints.dataProducts,
      { params }
    );
    return data;
  },

  /** GET /dataproducts/:id — single product + ETag header */
  async getById(
    id: string
  ): Promise<{ data: DataProduct; etag: string | null }> {
    const response = await dpasClient.get<DataProduct>(
      endpoints.dataProductById(id)
    );
    return {
      data: response.data,
      etag: response.headers["etag"] || null,
    };
  },

  /** POST /dataproducts — create new product (status defaults to "draft") */
  async create(payload: DataProductCreatePayload): Promise<DataProduct> {
    const { data } = await dpasClient.post<DataProduct>(
      endpoints.dataProducts,
      payload
    );
    return data;
  },

  /** PATCH /dataproducts/:id — update mutable fields. Sends If-Match if etag provided. */
  async update(
    id: string,
    payload: DataProductUpdatePayload,
    etag?: string
  ): Promise<DataProduct> {
    const headers: Record<string, string> = {};
    if (etag) headers["If-Match"] = etag;

    const { data } = await dpasClient.patch<DataProduct>(
      endpoints.dataProductById(id),
      payload,
      { headers }
    );
    return data;
  },

  /** DELETE /dataproducts/:id — soft delete (sets status to "retired") */
  async delete(id: string): Promise<DataProduct> {
    const { data } = await dpasClient.delete<DataProduct>(
      endpoints.dataProductById(id)
    );
    return data;
  },
};
