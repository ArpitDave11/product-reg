import { create } from "zustand";
import type { WizardFormState, MetaqDataset } from "../api/types";
import { fromMetaq } from "../utils/fieldMapping";

// ── Default Values ──────────────────────────────────────────────

const DEFAULTS: WizardFormState = {
  // Step 1 – Product Identity & Purpose
  productName: "",
  productType: "",
  businessDomain: "",
  shortDescription: "",
  longDescription: "",
  productVersion: "",
  dataCategory: "",
  businessPurpose: "",

  // Step 2 – Ownership & Support
  owner: "",
  backupOwner: "",
  itLead: "",
  dataSteward: "",
  supportEmail: "",
  businessUnit: "",
  costCenter: "",

  // Step 3 – Source & Entitlements
  sourceUrl: "",
  environment: "PROD",
  sourceSystem: "",
  sourceDatabase: "",
  sourceSchema: "",
  connectionType: "JDBC",
  refreshSchedule: "",
  cidClassification: "",
  accessControl: "Role-Based",
  highPerformant: "No",
  ownEntitlementProcess: "No",
  entitlementGroup: "",
  entitlementApprover: "",

  // Step 4 – Semantics & Data Quality
  businessEntity: "",
  glossaryTerms: "",
  ontologyMapping: "",
  semanticTags: "",
  domainModel: "",
  dataScope: "Global",
  refreshFrequency: "Real-time",
  qualityRules: "",
  completenessTarget: "",
  accuracyTarget: "",
  timelinessTarget: "",
  consistencyRules: "",
  uniquenessRules: "",
  validityRules: "",
  fitnessScore: "",

  // Step 5 – Data Contract & Access
  dataRetention: "7 years",
  accessAgreement: "",
  slaUptime: "99.9%",
  supportHours: "24/7",
  escalationPath: "",
  changeNotificationDays: "30 days",
  breakingChangesPolicy: "",
  consumerOnboarding: "",

  // Step 6 – Lineage & Transformations
  upstreamSources: "",
  transformationLogic: "",
  upstreamOwner: "",
  dataFlowDiagram: "",
  processingEngine: "",
  latencyRequirement: "",
  errorHandling: "",

  // Step 7 – Compliance & AI Readiness
  dataClassification: "Highly Confidential",
  containsPII: "Yes",
  regulatoryRequirements: "",
  piiHandlingProcedure: "",
  dpaRequired: "No",
  mlFeatureStore: "Not Applicable",
  aiModelUsage: "Not Applicable",
  embeddingSupport: "Not Applicable",
  biasAssessment: "Not Applicable",
  explainabilityRequirement: "Not Applicable",
  modelGovernance: "Not Applicable",

  // Step 8 – Attestation & Submit
  attestAccuracy: false,
  attestOwnership: false,
  attestPolicyCompliance: false,

  // Metadata
  dpasResourceId: null,
  dpasResourceIri: null,
  dpasEtag: null,
  metaqSource: null,
  lastSavedAt: null,
};

// ── Step Field Definitions ──────────────────────────────────────

const STEP_FIELDS: (keyof WizardFormState)[][] = [
  // Step 1 – Product Identity & Purpose
  ["productName", "productType", "businessDomain", "shortDescription", "longDescription", "productVersion", "dataCategory", "businessPurpose"],
  // Step 2 – Ownership & Support
  ["owner", "backupOwner", "itLead", "dataSteward", "supportEmail", "businessUnit", "costCenter"],
  // Step 3 – Source & Entitlements
  ["sourceUrl", "environment", "sourceSystem", "sourceDatabase", "sourceSchema", "connectionType", "refreshSchedule", "cidClassification", "accessControl", "highPerformant", "ownEntitlementProcess", "entitlementGroup", "entitlementApprover"],
  // Step 4 – Semantics & Data Quality
  ["businessEntity", "glossaryTerms", "ontologyMapping", "semanticTags", "domainModel", "dataScope", "refreshFrequency", "qualityRules", "completenessTarget", "accuracyTarget", "timelinessTarget", "consistencyRules", "uniquenessRules", "validityRules", "fitnessScore"],
  // Step 5 – Data Contract & Access
  ["dataRetention", "accessAgreement", "slaUptime", "supportHours", "escalationPath", "changeNotificationDays", "breakingChangesPolicy", "consumerOnboarding"],
  // Step 6 – Lineage & Transformations
  ["upstreamSources", "transformationLogic", "upstreamOwner", "dataFlowDiagram", "processingEngine", "latencyRequirement", "errorHandling"],
  // Step 7 – Compliance & AI Readiness (optional AI fields counted too)
  ["dataClassification", "containsPII", "regulatoryRequirements", "piiHandlingProcedure", "dpaRequired", "mlFeatureStore", "aiModelUsage", "embeddingSupport", "biasAssessment", "explainabilityRequirement", "modelGovernance"],
  // Step 8 – Attestation & Submit
  ["attestAccuracy", "attestOwnership", "attestPolicyCompliance"],
];

// Fields with non-empty default values (always count as filled)
const FIELDS_WITH_DEFAULTS = new Set<keyof WizardFormState>([
  "environment",
  "connectionType",
  "accessControl",
  "highPerformant",
  "ownEntitlementProcess",
  "dataScope",
  "refreshFrequency",
  "dataRetention",
  "slaUptime",
  "supportHours",
  "changeNotificationDays",
  "dataClassification",
  "containsPII",
  "dpaRequired",
]);

// Optional fields: filled only when NOT "Not Applicable"
const OPTIONAL_FIELDS = new Set<keyof WizardFormState>([
  "mlFeatureStore",
  "aiModelUsage",
  "embeddingSupport",
  "biasAssessment",
  "explainabilityRequirement",
  "modelGovernance",
]);

function isFieldFilled(key: keyof WizardFormState, value: unknown): boolean {
  // Fields with non-empty defaults always count as filled
  if (FIELDS_WITH_DEFAULTS.has(key)) return true;

  // Optional AI fields: filled only when changed from "Not Applicable"
  if (OPTIONAL_FIELDS.has(key)) {
    return typeof value === "string" && value !== "Not Applicable";
  }

  if (typeof value === "boolean") return value === true;
  if (typeof value === "string") return value.trim().length > 0;
  return false;
}

// ── Store Actions ───────────────────────────────────────────────

interface RegistrationActions {
  updateFields: (fields: Partial<WizardFormState>) => void;
  prefillFromMetaq: (dataset: MetaqDataset) => void;
  markSavedToDpas: (
    resourceId: string,
    resourceIri: string,
    etag: string | null
  ) => void;
  reset: () => void;
  getStepCompletion: () => Array<{ filled: number; total: number }>;
}

export type RegistrationStore = WizardFormState & RegistrationActions;

export const useRegistrationStore = create<RegistrationStore>((set, get) => ({
  ...DEFAULTS,

  updateFields: (fields) => set(fields),

  prefillFromMetaq: (dataset) => {
    const updates = fromMetaq(dataset);
    set(updates);
  },

  markSavedToDpas: (resourceId, resourceIri, etag) =>
    set({
      dpasResourceId: resourceId,
      dpasResourceIri: resourceIri,
      dpasEtag: etag,
      lastSavedAt: new Date().toISOString(),
    }),

  reset: () => set(DEFAULTS),

  getStepCompletion: () => {
    const state = get();
    return STEP_FIELDS.map((fields) => {
      const total = fields.length;
      const filled = fields.filter((key) =>
        isFieldFilled(key, state[key])
      ).length;
      return { filled, total };
    });
  },
}));
