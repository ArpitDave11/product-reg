import type {
  WizardFormState,
  DataProductCreatePayload,
  DataProductUpdatePayload,
  MetaqDataset,
} from "../api/types";

/**
 * Map form state → DPAS create payload.
 * Only 5 fields go to the API (Section B.3).
 */
export function toDpasCreatePayload(
  state: WizardFormState
): DataProductCreatePayload {
  return {
    title: state.productName,
    owner: state.owner,
    source_system_code: state.environment,
    description: state.shortDescription || undefined,
    status: "draft",
  };
}

/**
 * Map form state → DPAS update payload.
 * title is IMMUTABLE — never included in updates.
 */
export function toDpasUpdatePayload(
  state: WizardFormState
): DataProductUpdatePayload {
  return {
    description: state.shortDescription || undefined,
    owner: state.owner || undefined,
    source_system_code: state.environment || undefined,
  };
}

/**
 * Map MetaQ dataset → partial form state for pre-fill (Section B.4).
 * Only overwrites fields that have non-null values in the dataset.
 */
export function fromMetaq(dataset: MetaqDataset): Partial<WizardFormState> {
  const updates: Partial<WizardFormState> = {
    metaqSource: dataset.dataset_title,
  };

  if (dataset.dataset_title != null) updates.productName = dataset.dataset_title;
  if (dataset.description != null) updates.shortDescription = dataset.description;
  if (dataset.sourcedescription != null) updates.longDescription = dataset.sourcedescription;
  if (dataset.cidstaterag != null) updates.cidClassification = dataset.cidstaterag;
  if (dataset.ontologyname != null) updates.businessEntity = dataset.ontologyname;
  if (dataset.kde != null) updates.glossaryTerms = dataset.kde;
  if (dataset.dqobject != null) updates.qualityRules = dataset.dqobject;

  return updates;
}
