import { useEffect, useRef } from "react";
import { useRegistrationStore } from "../stores/useRegistrationStore";
import type { WizardFormState } from "../api/types";

const STORAGE_KEY = "wma-registration-draft";
const DEBOUNCE_MS = 2000;

// Keys to persist (all form + metadata fields, no actions)
const STATE_KEYS: (keyof WizardFormState)[] = [
  // Step 1 – Product Identity & Purpose
  "productName", "productType", "businessDomain", "shortDescription", "longDescription",
  "productVersion", "dataCategory", "businessPurpose",
  // Step 2 – Ownership & Support
  "owner", "backupOwner", "itLead", "dataSteward", "supportEmail",
  "businessUnit", "costCenter",
  // Step 3 – Source & Entitlements
  "sourceUrl", "environment", "sourceSystem", "sourceDatabase", "sourceSchema",
  "connectionType", "refreshSchedule", "cidClassification", "accessControl",
  "highPerformant", "ownEntitlementProcess", "entitlementGroup", "entitlementApprover",
  // Step 4 – Semantics & Data Quality
  "businessEntity", "glossaryTerms", "ontologyMapping", "semanticTags", "domainModel",
  "dataScope", "refreshFrequency", "qualityRules", "completenessTarget", "accuracyTarget",
  "timelinessTarget", "consistencyRules", "uniquenessRules", "validityRules", "fitnessScore",
  // Step 5 – Data Contract & Access
  "dataRetention", "accessAgreement", "slaUptime", "supportHours", "escalationPath",
  "changeNotificationDays", "breakingChangesPolicy", "consumerOnboarding",
  // Step 6 – Lineage & Transformations
  "upstreamSources", "transformationLogic", "upstreamOwner", "dataFlowDiagram",
  "processingEngine", "latencyRequirement", "errorHandling",
  // Step 7 – Compliance & AI Readiness
  "dataClassification", "containsPII", "regulatoryRequirements", "piiHandlingProcedure",
  "dpaRequired", "mlFeatureStore", "aiModelUsage", "embeddingSupport",
  "biasAssessment", "explainabilityRequirement", "modelGovernance",
  // Step 8 – Attestation & Submit
  "attestAccuracy", "attestOwnership", "attestPolicyCompliance",
  // Metadata
  "dpasResourceId", "dpasResourceIri", "dpasEtag", "metaqSource", "lastSavedAt",
];

function extractState(store: Record<string, unknown>): Partial<WizardFormState> {
  const data: Record<string, unknown> = {};
  for (const key of STATE_KEYS) {
    data[key] = store[key];
  }
  return data as Partial<WizardFormState>;
}

/** Restore saved draft from localStorage into the store. */
function restoreDraft() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const saved = JSON.parse(raw) as Partial<WizardFormState>;
    useRegistrationStore.getState().updateFields(saved);
  } catch {
    // Corrupted data — ignore
    localStorage.removeItem(STORAGE_KEY);
  }
}

let _skipNextSave = false;

/** Clear the saved draft (call after successful submit). */
export function clearDraft() {
  localStorage.removeItem(STORAGE_KEY);
  _skipNextSave = true;
}

/**
 * Hook: auto-saves store to localStorage (debounced 2s) and restores on mount.
 * Call once at the top level (e.g. App.tsx).
 */
export function useFormPersistence() {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Restore on mount
  useEffect(() => {
    restoreDraft();
  }, []);

  // Subscribe to store changes → debounced save
  useEffect(() => {
    const unsub = useRegistrationStore.subscribe((state) => {
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        if (_skipNextSave) { _skipNextSave = false; return; }
        try {
          const data = extractState(state as unknown as Record<string, unknown>);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        } catch {
          // Storage full or unavailable — silent fail
        }
      }, DEBOUNCE_MS);
    });

    return () => {
      unsub();
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);
}
