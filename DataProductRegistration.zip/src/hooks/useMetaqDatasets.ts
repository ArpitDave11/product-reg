import { useQuery } from "@tanstack/react-query";
import { metaqService } from "../api/metaqService";

// ── Query Keys ──────────────────────────────────────────────────

const keys = {
  all: ["metaq"] as const,
  health: () => [...keys.all, "health"] as const,
  datasets: (params?: Record<string, unknown>) =>
    [...keys.all, "datasets", params] as const,
  datasetByTitle: (title: string) =>
    [...keys.all, "dataset", title] as const,
};

// ── Queries ─────────────────────────────────────────────────────

interface DatasetListParams {
  limit?: number;
  offset?: number;
}

export function useMetaqHealth() {
  return useQuery({
    queryKey: keys.health(),
    queryFn: () => metaqService.health(),
    refetchInterval: 60_000, // poll every 60s
  });
}

export function useMetaqDatasets(params?: DatasetListParams) {
  return useQuery({
    queryKey: keys.datasets(params as Record<string, unknown>),
    queryFn: () => metaqService.listDatasets(params),
    staleTime: 10 * 60 * 1000,
  });
}

export function useMetaqDatasetByTitle(title: string) {
  return useQuery({
    queryKey: keys.datasetByTitle(title),
    queryFn: () => metaqService.getByTitle(title),
    enabled: title.length >= 2,
    staleTime: 10 * 60 * 1000,
  });
}
