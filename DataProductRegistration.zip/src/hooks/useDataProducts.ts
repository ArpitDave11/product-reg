import {
  useQuery,
  useMutation,
  useQueryClient,
} from "@tanstack/react-query";
import { dpasService } from "../api/dpasService";
import { useRegistrationStore } from "../stores/useRegistrationStore";
import type {
  DataProductCreatePayload,
  DataProductUpdatePayload,
} from "../api/types";

// ── Query Keys ──────────────────────────────────────────────────

const keys = {
  all: ["dataProducts"] as const,
  list: (params?: Record<string, unknown>) =>
    [...keys.all, "list", params] as const,
  detail: (id: string) => [...keys.all, "detail", id] as const,
};

// ── Queries ─────────────────────────────────────────────────────

interface ListParams {
  page?: number;
  pageSize?: number;
  status?: string;
  owner?: string;
}

export function useDataProductList(params?: ListParams) {
  return useQuery({
    queryKey: keys.list(params as Record<string, unknown>),
    queryFn: () => dpasService.list(params),
    staleTime: 5 * 60 * 1000,
  });
}

export function useDataProduct(id: string | null) {
  return useQuery({
    queryKey: keys.detail(id!),
    queryFn: async () => {
      const result = await dpasService.getById(id!);
      // Store the etag for optimistic concurrency
      useRegistrationStore
        .getState()
        .updateFields({ dpasEtag: result.etag });
      return result;
    },
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
  });
}

// ── Mutations ───────────────────────────────────────────────────

export function useCreateDataProduct() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (payload: DataProductCreatePayload) =>
      dpasService.create(payload),
    retry: false,
    onSuccess: (data) => {
      useRegistrationStore
        .getState()
        .markSavedToDpas(data.resource_id, data.resource_iri, null);
      queryClient.invalidateQueries({ queryKey: keys.all });
    },
  });
}

export function useUpdateDataProduct() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      payload,
      etag,
    }: {
      id: string;
      payload: DataProductUpdatePayload;
      etag?: string;
    }) => dpasService.update(id, payload, etag),
    retry: false,
    onSuccess: (data) => {
      useRegistrationStore.getState().updateFields({
        lastSavedAt: new Date().toISOString(),
      });
      queryClient.invalidateQueries({ queryKey: keys.all });
      queryClient.invalidateQueries({
        queryKey: keys.detail(data.resource_id),
      });
    },
  });
}

export function useDeleteDataProduct() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => dpasService.delete(id),
    retry: false,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: keys.all });
    },
  });
}
