import { createRoot } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App.tsx";
import MsalProviderWrapper from "./auth/MsalProviderWrapper";
import AuthGuard from "./auth/AuthGuard";
import { isMockMode } from "./config/apiConfig";
import "./index.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 2,
      refetchOnWindowFocus: false,
    },
  },
});

async function initApp() {
  if (import.meta.env.VITE_USE_MOCKS === "true") {
    const { worker } = await import("./mocks/browser");
    await worker.start({ onUnhandledRequest: "bypass" });
    console.log("[MOCK] MSW intercepting API calls");
  }

  const root = createRoot(document.getElementById("root")!);

  // In mock mode, skip MsalProvider entirely (no MSAL initialization)
  if (isMockMode()) {
    root.render(
      <QueryClientProvider client={queryClient}>
        <AuthGuard>
          <App />
        </AuthGuard>
      </QueryClientProvider>
    );
  } else {
    root.render(
      <MsalProviderWrapper>
        <QueryClientProvider client={queryClient}>
          <AuthGuard>
            <App />
          </AuthGuard>
        </QueryClientProvider>
      </MsalProviderWrapper>
    );
  }
}

initApp();
