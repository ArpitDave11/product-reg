import { useMsal } from "@azure/msal-react";
import { tokenRequest } from "../config/authConfig";
import { isMockMode } from "../config/apiConfig";
import { MOCK_TOKEN } from "../mocks/mockAuth";

export function useAccessToken() {
  // In mock mode, return a simple function that resolves to the fake token
  if (isMockMode()) {
    return {
      getToken: async (): Promise<string> => MOCK_TOKEN,
    };
  }

  // eslint-disable-next-line react-hooks/rules-of-hooks
  const { instance, accounts } = useMsal();

  const getToken = async (): Promise<string> => {
    const account = accounts[0];
    if (!account) throw new Error("No active account");

    const response = await instance.acquireTokenSilent({
      ...tokenRequest,
      account,
    });
    return response.accessToken;
  };

  return { getToken };
}
