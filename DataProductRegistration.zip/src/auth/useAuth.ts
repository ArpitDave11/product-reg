import { useMsal } from "@azure/msal-react";
import { loginRequest } from "../config/authConfig";
import { isMockMode } from "../config/apiConfig";
import { mockUser } from "../mocks/mockAuth";

interface AuthUser {
  name: string;
  email: string;
  initials: string;
}

interface UseAuthReturn {
  user: AuthUser | null;
  isAuthenticated: boolean;
  login: () => void;
  logout: () => void;
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

function useMsalAuth(): UseAuthReturn {
  const { instance, accounts } = useMsal();
  const account = accounts[0] ?? null;

  const user: AuthUser | null = account
    ? {
        name: account.name || account.username,
        email: account.username,
        initials: getInitials(account.name || account.username),
      }
    : null;

  return {
    user,
    isAuthenticated: !!account,
    login: () => instance.loginRedirect(loginRequest),
    logout: () =>
      instance.logoutRedirect({ postLogoutRedirectUri: "/" }),
  };
}

function useMockAuth(): UseAuthReturn {
  return {
    user: mockUser,
    isAuthenticated: true,
    login: () => console.log("[MOCK] login called"),
    logout: () => console.log("[MOCK] logout called"),
  };
}

export function useAuth(): UseAuthReturn {
  if (isMockMode()) {
    return useMockAuth();
  }
  // eslint-disable-next-line react-hooks/rules-of-hooks
  return useMsalAuth();
}
