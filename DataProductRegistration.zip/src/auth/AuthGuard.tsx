import { type ReactNode } from "react";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useIsAuthenticated,
  useMsal,
} from "@azure/msal-react";
import { InteractionStatus } from "@azure/msal-browser";
import { isMockMode } from "../config/apiConfig";
import LoginPage from "../components/LoginPage";
import LoadingSpinner from "../components/LoadingSpinner";

function RealAuthGuard({ children }: { children: ReactNode }) {
  const { inProgress } = useMsal();
  const isAuthenticated = useIsAuthenticated();

  if (inProgress !== InteractionStatus.None) {
    return <LoadingSpinner message="Authenticating..." />;
  }

  return (
    <>
      <AuthenticatedTemplate>{children}</AuthenticatedTemplate>
      <UnauthenticatedTemplate>
        {!isAuthenticated && <LoginPage />}
      </UnauthenticatedTemplate>
    </>
  );
}

export default function AuthGuard({ children }: { children: ReactNode }) {
  // Mock mode: skip MSAL entirely, render app directly
  if (isMockMode()) {
    return <>{children}</>;
  }

  return <RealAuthGuard>{children}</RealAuthGuard>;
}
