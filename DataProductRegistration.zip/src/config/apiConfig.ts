export const isMockMode = (): boolean =>
  import.meta.env.VITE_USE_MOCKS === "true";

export const API_CONFIG = {
  metaq: {
    baseUrl: import.meta.env.VITE_METAQ_API_BASE_URL || "/metaq-api",
    endpoints: {
      health: "/health",
      datasets: "/datasets",
      datasetByTitle: (title: string) =>
        `/dataset/${encodeURIComponent(title)}`,
      upsert: "/",
    },
  },
  dpas: {
    baseUrl: import.meta.env.VITE_DPAS_API_BASE_URL || "/v1",
    endpoints: {
      dataProducts: "/dataproducts",
      dataProductById: (id: string) => `/dataproducts/${id}`,
    },
  },
} as const;
