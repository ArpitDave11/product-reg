import { Configuration, LogLevel } from "@azure/msal-browser";

export const msalConfig: Configuration = {
  auth: {
    clientId: import.meta.env.VITE_AZURE_CLIENT_ID || "placeholder-client-id",
    authority:
      import.meta.env.VITE_AZURE_AUTHORITY ||
      "https://login.microsoftonline.com/common",
    redirectUri:
      import.meta.env.VITE_AZURE_REDIRECT_URI || "http://localhost:3000",
    postLogoutRedirectUri: "/",
    navigateToLoginRequestUrl: true,
  },
  cache: {
    cacheLocation: "sessionStorage",
    storeAuthStateInCookie: false,
  },
  system: {
    loggerOptions: {
      logLevel: LogLevel.Warning,
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) return;
        if (level === LogLevel.Error) console.error("[MSAL]", message);
        else if (level === LogLevel.Warning) console.warn("[MSAL]", message);
      },
    },
  },
};

export const loginRequest = {
  scopes: [
    import.meta.env.VITE_API_SCOPE || "api://placeholder-client-id/.default",
  ],
};

export const tokenRequest = {
  scopes: [
    import.meta.env.VITE_API_SCOPE || "api://placeholder-client-id/.default",
  ],
};
