import { z } from "zod";

// ── Shared Patterns ─────────────────────────────────────────

const ubsEmail = z
  .string()
  .min(1, "Required")
  .regex(/^[a-zA-Z0-9_.%-]+@ubs\.com$/, "Must be a @ubs.com email");

const requiredString = z.string().min(1, "Required");

const requiredUrl = z
  .string()
  .min(1, "Required")
  .url("Must be a valid URL");

// ── Step Schemas (8 Steps) ──────────────────────────────────

const step1Schema = z.object({
  productName: z.string().min(1, "Required").max(255, "Maximum 255 characters"),
  productType: requiredString,
  businessDomain: requiredString,
  shortDescription: z.string().min(1, "Required").max(1000, "Maximum 1000 characters"),
  longDescription: requiredString,
  productVersion: requiredString,
  dataCategory: requiredString,
  businessPurpose: requiredString,
});

const step2Schema = z.object({
  owner: ubsEmail,
  backupOwner: ubsEmail,
  itLead: ubsEmail,
  dataSteward: ubsEmail,
  supportEmail: ubsEmail,
  businessUnit: requiredString,
  costCenter: requiredString,
});

const step3Schema = z.object({
  sourceUrl: requiredUrl,
  environment: requiredString,
  sourceSystem: requiredString,
  sourceDatabase: requiredString,
  sourceSchema: requiredString,
  connectionType: requiredString,
  refreshSchedule: requiredString,
  cidClassification: requiredString,
  accessControl: requiredString,
  highPerformant: requiredString,
  ownEntitlementProcess: requiredString,
  entitlementGroup: requiredString,
  entitlementApprover: ubsEmail,
});

const step4Schema = z.object({
  businessEntity: requiredString,
  glossaryTerms: requiredString,
  ontologyMapping: requiredString,
  semanticTags: requiredString,
  domainModel: requiredString,
  dataScope: requiredString,
  refreshFrequency: requiredString,
  qualityRules: requiredString,
  completenessTarget: requiredString,
  accuracyTarget: requiredString,
  timelinessTarget: requiredString,
  consistencyRules: requiredString,
  uniquenessRules: requiredString,
  validityRules: requiredString,
  fitnessScore: requiredString,
});

const step5Schema = z.object({
  dataRetention: requiredString,
  accessAgreement: requiredString,
  slaUptime: requiredString,
  supportHours: requiredString,
  escalationPath: requiredString,
  changeNotificationDays: requiredString,
  breakingChangesPolicy: requiredString,
  consumerOnboarding: requiredString,
});

const step6Schema = z.object({
  upstreamSources: requiredString,
  transformationLogic: requiredString,
  upstreamOwner: ubsEmail,
  dataFlowDiagram: requiredString,
  processingEngine: requiredString,
  latencyRequirement: requiredString,
  errorHandling: requiredString,
});

// Step 7: Section A (Compliance) is required; Section B (AI Readiness) is optional — no validation
const step7Schema = z.object({
  dataClassification: requiredString,
  containsPII: requiredString,
  regulatoryRequirements: requiredString,
  piiHandlingProcedure: requiredString,
  dpaRequired: requiredString,
});

const step8Schema = z.object({
  attestAccuracy: z.literal(true, {
    errorMap: () => ({ message: "You must attest to accuracy" }),
  }),
  attestOwnership: z.literal(true, {
    errorMap: () => ({ message: "You must attest to ownership" }),
  }),
  attestPolicyCompliance: z.literal(true, {
    errorMap: () => ({ message: "You must attest to policy compliance" }),
  }),
});

// ── Step Field Keys ─────────────────────────────────────────

const STEP_KEYS: string[][] = [
  ["productName", "productType", "businessDomain", "shortDescription", "longDescription", "productVersion", "dataCategory", "businessPurpose"],
  ["owner", "backupOwner", "itLead", "dataSteward", "supportEmail", "businessUnit", "costCenter"],
  ["sourceUrl", "environment", "sourceSystem", "sourceDatabase", "sourceSchema", "connectionType", "refreshSchedule", "cidClassification", "accessControl", "highPerformant", "ownEntitlementProcess", "entitlementGroup", "entitlementApprover"],
  ["businessEntity", "glossaryTerms", "ontologyMapping", "semanticTags", "domainModel", "dataScope", "refreshFrequency", "qualityRules", "completenessTarget", "accuracyTarget", "timelinessTarget", "consistencyRules", "uniquenessRules", "validityRules", "fitnessScore"],
  ["dataRetention", "accessAgreement", "slaUptime", "supportHours", "escalationPath", "changeNotificationDays", "breakingChangesPolicy", "consumerOnboarding"],
  ["upstreamSources", "transformationLogic", "upstreamOwner", "dataFlowDiagram", "processingEngine", "latencyRequirement", "errorHandling"],
  // Only Section A keys are validated for Step 7
  ["dataClassification", "containsPII", "regulatoryRequirements", "piiHandlingProcedure", "dpaRequired"],
  ["attestAccuracy", "attestOwnership", "attestPolicyCompliance"],
];

const SCHEMAS = [
  step1Schema,
  step2Schema,
  step3Schema,
  step4Schema,
  step5Schema,
  step6Schema,
  step7Schema,
  step8Schema,
];

// ── Public API ──────────────────────────────────────────────

export interface ValidationResult {
  success: boolean;
  errors: Record<string, string>;
}

/**
 * Validates only the fields belonging to a specific step.
 * @param step 1-based step number (1–8)
 * @param storeState The full store state (only step fields are extracted)
 */
export function validateStep(
  step: number,
  storeState: Record<string, unknown>
): ValidationResult {
  const idx = step - 1;
  const schema = SCHEMAS[idx];
  if (!schema) return { success: true, errors: {} };

  // Extract only this step's fields
  const keys = STEP_KEYS[idx];
  const data: Record<string, unknown> = {};
  for (const key of keys) {
    data[key] = storeState[key];
  }

  const result = schema.safeParse(data);

  if (result.success) {
    return { success: true, errors: {} };
  }

  const errors: Record<string, string> = {};
  for (const issue of result.error.issues) {
    const key = issue.path[0] as string;
    if (!errors[key]) {
      errors[key] = issue.message;
    }
  }

  return { success: false, errors };
}
