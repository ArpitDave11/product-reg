import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { RegistrationForm } from './components/RegistrationForm';
import { SummaryPanel } from './components/SummaryPanel';

const stepNames = [
  'Product Identity',
  'Ownership & Contacts',
  'Connect to Source',
  'KDE Semantics',
  'Scope & Data Quality',
  'Data Contract',
  'Data Lineage',
  'Sensitivity & Compliance',
  'AI Readiness',
  'Submit & Attestation',
];

export default function App() {
  const [currentStep, setCurrentStep] = useState(1);
  const [summaryOpen, setSummaryOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-white">
      {/* Sidebar */}
      <Sidebar currentStep={currentStep} onStepChange={setCurrentStep} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <Header currentStep={currentStep} stepName={stepNames[currentStep - 1]} />

        {/* Content area */}
        <div className="flex-1 overflow-y-auto">
          <div className={`p-8 lg:p-10 transition-all duration-300 ${summaryOpen ? 'pr-[320px]' : ''}`}>
            <RegistrationForm currentStep={currentStep} onStepChange={setCurrentStep} />
          </div>
        </div>
      </div>

      {/* Collapsible Summary Panel — Stripe-inspired live preview */}
      <SummaryPanel isOpen={summaryOpen} onToggle={() => setSummaryOpen(!summaryOpen)} />
    </div>
  );
}