import { ChevronRight, ChevronLeft, Package, Users, Link2, Database, ListChecks, FileText, GitBranch, Shield, Sparkles, Send } from 'lucide-react';

interface SummaryPanelProps {
  isOpen: boolean;
  onToggle: () => void;
}

export function SummaryPanel({ isOpen, onToggle }: SummaryPanelProps) {
  const sections = [
    {
      icon: Package,
      title: 'Product Identity',
      fields: [
        { label: 'Name', value: 'WMA Account' },
        { label: 'Type', value: 'Composite Data Product' },
        { label: 'Domain', value: 'Account' },
        { label: 'Short Desc', value: 'Brief description' },
        { label: 'Long Desc', value: 'Detailed business description' },
      ],
    },
    {
      icon: Users,
      title: 'Ownership',
      fields: [
        { label: 'Owner', value: 'owner@ubs.com' },
        { label: 'Backup', value: 'backup@ubs.com' },
        { label: 'IT Lead', value: 'itlead@ubs.com' },
        { label: 'Steward', value: 'steward@ubs.com' },
        { label: 'Support Email', value: '\u2014' },
        { label: 'Slack', value: '\u2014' },
      ],
    },
    {
      icon: Link2,
      title: 'Connect',
      fields: [
        { label: 'Source URL', value: 'https://source-app/' },
        { label: 'Environment', value: 'PROD' },
        { label: 'CID Class', value: 'Red / Green / Amber' },
        { label: 'Access', value: 'Role-Based' },
      ],
    },
    {
      icon: Database,
      title: 'KDE Semantics',
      fields: [],
    },
    {
      icon: ListChecks,
      title: 'Scope & DQ',
      fields: [],
    },
    {
      icon: FileText,
      title: 'Data Contract',
      fields: [],
    },
    {
      icon: GitBranch,
      title: 'Lineage',
      fields: [],
    },
    {
      icon: Shield,
      title: 'Sensitivity',
      fields: [],
    },
    {
      icon: Sparkles,
      title: 'AI Readiness',
      fields: [],
    },
    {
      icon: Send,
      title: 'Submit',
      fields: [],
    },
  ];

  return (
    <>
      {/* Toggle button */}
      <button
        onClick={onToggle}
        className="fixed top-1/2 -translate-y-1/2 z-30 flex items-center gap-1 px-1.5 py-3 bg-white border border-r-0 border-[#e5e7eb] rounded-l-lg shadow-sm hover:bg-[#f9fafb] transition-all"
        style={{ right: isOpen ? '300px' : '0px' }}
      >
        {isOpen ? (
          <ChevronRight className="w-3.5 h-3.5 text-[#6b7280]" />
        ) : (
          <ChevronLeft className="w-3.5 h-3.5 text-[#6b7280]" />
        )}
      </button>

      {/* Panel */}
      <div
        className="fixed right-0 top-0 h-full w-[300px] bg-white border-l border-[#e8e8ec] z-20 transition-transform duration-300 ease-out"
        style={{
          transform: isOpen ? 'translateX(0)' : 'translateX(100%)',
          boxShadow: isOpen ? '-4px 0 24px rgba(0,0,0,0.04)' : 'none',
        }}
      >
        <div className="h-full overflow-y-auto">
          {/* Header */}
          <div className="sticky top-0 bg-white px-5 pt-5 pb-3 border-b border-[#f0f0f0]">
            <div className="flex items-center justify-between">
              <h3 className="text-[14px] font-semibold text-[#111]">Registration Summary</h3>
              <span className="text-[11px] text-[#9ca3af] font-medium bg-[#f3f4f6] px-2 py-0.5 rounded">Live Preview</span>
            </div>
          </div>

          {/* Sections */}
          <div className="px-5 py-4 space-y-4">
            {sections.map((section) => {
              const Icon = section.icon;
              const emDash = '\u2014';
              const hasData = section.fields.some(f => f.value !== emDash && f.value !== '');
              return (
                <div key={section.title} className="rounded-lg border border-[#f0f0f0] overflow-hidden">
                  {/* Section header */}
                  <div className={`flex items-center gap-2 px-3.5 py-2.5 ${hasData ? 'bg-[#f0fdf4]' : 'bg-[#fafafa]'}`}>
                    <Icon className={`w-3.5 h-3.5 ${hasData ? 'text-[#22c55e]' : 'text-[#c0c0c0]'}`} />
                    <span className={`text-[12px] font-semibold ${hasData ? 'text-[#15803d]' : 'text-[#999]'}`}>
                      {section.title}
                    </span>
                    {hasData && (
                      <span className="ml-auto text-[10px] text-[#22c55e] font-medium">
                        {section.fields.filter(f => f.value !== emDash).length}/{section.fields.length}
                      </span>
                    )}
                  </div>

                  {/* Fields */}
                  {section.fields.length > 0 ? (
                    <div className="px-3.5 py-2 space-y-1.5">
                      {section.fields.map((field) => (
                        <div key={field.label} className="flex items-baseline justify-between gap-2">
                          <span className="text-[11px] text-[#9ca3af] flex-shrink-0">{field.label}</span>
                          <span className={`text-[11px] text-right truncate max-w-[150px] ${
                            field.value === emDash ? 'text-[#d1d5db] italic' : 'text-[#374151] font-medium'
                          }`}>
                            {field.value}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="px-3.5 py-2.5">
                      <span className="text-[11px] text-[#d1d5db] italic">Not started</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}