import { useEffect, useCallback, useState } from 'react';
import type { ReactNode } from 'react';
import {
  Package, Users, Link2, Database, ListChecks, FileText,
  GitBranch, Shield, Sparkles, Send, ArrowRight, ChevronLeft,
  Lightbulb, Info
} from 'lucide-react';

interface RegistrationFormProps {
  currentStep: number;
  onStepChange: (step: number) => void;
}

export function RegistrationForm({ currentStep, onStepChange }: RegistrationFormProps) {
  const [animating, setAnimating] = useState(false);
  const [displayStep, setDisplayStep] = useState(currentStep);
  const [slideDir, setSlideDir] = useState<'left' | 'right'>('right');

  const handleBack = useCallback(() => {
    if (currentStep > 1) onStepChange(currentStep - 1);
  }, [currentStep, onStepChange]);

  const handleContinue = useCallback(() => {
    if (currentStep < 10) onStepChange(currentStep + 1);
  }, [currentStep, onStepChange]);

  // Step transition animation
  useEffect(() => {
    if (currentStep !== displayStep) {
      setSlideDir(currentStep > displayStep ? 'right' : 'left');
      setAnimating(true);
      const timer = setTimeout(() => {
        setDisplayStep(currentStep);
        setAnimating(false);
      }, 200);
      return () => clearTimeout(timer);
    }
  }, [currentStep, displayStep]);

  // Keyboard shortcuts — Linear-inspired power-user experience
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
        e.preventDefault();
        handleContinue();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [handleContinue]);

  const stepInfo = [
    { number: 1, title: 'Product Identity', icon: Package, description: 'Define the core identity of your data product — name, type, and domain classification.' },
    { number: 2, title: 'Ownership & Contacts', icon: Users, description: 'Assign ownership, stewardship, and support channels for accountability.' },
    { number: 3, title: 'Connect to Source', icon: Link2, description: 'Link the underlying source system and configure access entitlements.' },
    { number: 4, title: 'KDE Semantics', icon: Database, description: 'Map business metadata, glossary terms, and semantic relationships.' },
    { number: 5, title: 'Scope & Data Quality', icon: ListChecks, description: 'Define data scope boundaries, fitness criteria, and quality validation rules.' },
    { number: 6, title: 'Data Contract', icon: FileText, description: 'Establish SLAs, data retention policies, and access agreements.' },
    { number: 7, title: 'Data Lineage', icon: GitBranch, description: 'Document upstream sources, transformation logic, and data flows.' },
    { number: 8, title: 'Sensitivity & Compliance', icon: Shield, description: 'Classify data sensitivity and map to regulatory requirements.' },
    { number: 9, title: 'AI Readiness', icon: Sparkles, description: 'Optional: Configure AI/ML feature store and analytics capabilities.' },
    { number: 10, title: 'Submit & Attestation', icon: Send, description: 'Review all entries, attest, and submit for governance review.' },
  ];

  const current = stepInfo[currentStep - 1];
  const StepIcon = current.icon;

  return (
    <div className="max-w-[840px] mx-auto">
      {/* Step header */}
      <div className="mb-6">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex items-center gap-3.5">
            <div className="p-2.5 bg-[#fef2f2] rounded-xl border border-[#fecaca]">
              <StepIcon className="w-5 h-5 text-[#e60028]" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-[20px] font-semibold text-[#111] tracking-tight">
                  {current.title}
                </h1>
                {currentStep === 9 && (
                  <span className="text-[10px] font-semibold text-[#0284c7] bg-[#f0f9ff] border border-[#e0f2fe] px-2 py-0.5 rounded-full uppercase tracking-wide">
                    Optional
                  </span>
                )}
              </div>
              <p className="text-[13px] text-[#6b7280] mt-1">{current.description}</p>
            </div>
          </div>
          <span className="text-[13px] text-[#b0b0b0] font-medium whitespace-nowrap mt-1">
            {currentStep} / 10
          </span>
        </div>

        {/* Step progress bar */}
        <div className="w-full bg-[#f0f0f0] rounded-full h-[5px] overflow-hidden">
          <div
            className="bg-[#e60028] h-full rounded-full transition-all duration-500 ease-out"
            style={{ width: `${(currentStep / 10) * 100}%` }}
          />
        </div>
      </div>

      {/* Form card — floating with subtle border on white background */}
      <div className="bg-white rounded-2xl border border-[#e5e7eb] shadow-[0_1px_2px_rgba(0,0,0,0.03),0_2px_8px_rgba(0,0,0,0.04)] p-8 lg:p-10">
        {/* Animated step content */}
        <div
          className={`transition-all duration-200 ease-out ${
            animating
              ? slideDir === 'right'
                ? 'opacity-0 translate-x-3'
                : 'opacity-0 -translate-x-3'
              : 'opacity-100 translate-x-0'
          }`}
        >
          {displayStep === 1 && <Step1 />}
          {displayStep === 2 && <Step2 />}
          {displayStep === 3 && <Step3 />}
          {displayStep === 4 && <Step4 />}
          {displayStep === 5 && <Step5 />}
          {displayStep === 6 && <Step6 />}
          {displayStep === 7 && <Step7 />}
          {displayStep === 8 && <Step8 />}
          {displayStep === 9 && <Step9 />}
          {displayStep === 10 && <Step10 />}
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-10 pt-7 border-t border-[#f0f0f0]">
          <button
            onClick={handleBack}
            disabled={currentStep === 1}
            className={`px-4 py-2.5 rounded-lg text-[13px] font-medium transition-all duration-200 flex items-center gap-2 border ${
              currentStep === 1
                ? 'bg-[#fafafa] text-[#c0c0c0] border-[#f0f0f0] cursor-not-allowed'
                : 'bg-white text-[#374151] border-[#e5e7eb] hover:border-[#9ca3af] hover:bg-[#f9fafb]'
            }`}
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            Back
          </button>

          {currentStep < 10 ? (
            <button
              onClick={handleContinue}
              className="px-5 py-2.5 bg-[#e60028] text-white rounded-lg text-[13px] font-medium hover:bg-[#cc0024] transition-all duration-200 flex items-center gap-2 shadow-[0_1px_3px_rgba(230,0,40,0.2)]"
            >
              Save &amp; Continue
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button className="px-5 py-2.5 bg-[#22c55e] text-white rounded-lg text-[13px] font-medium hover:bg-[#16a34a] transition-all duration-200 flex items-center gap-2 shadow-[0_1px_3px_rgba(34,197,94,0.2)]">
              Submit Registration
              <Send className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ─── Shared helpers ──────────────────────────────────────── */

function SectionHeader({ title, description }: { title: string; description?: string }) {
  return (
    <div className="mb-5 pb-3 border-b border-[#f0f0f0]">
      <h3 className="text-[14px] font-semibold text-[#111]">{title}</h3>
      {description && <p className="text-[12px] text-[#9ca3af] mt-1">{description}</p>}
    </div>
  );
}

function HelpTip({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-[#f8f9fa] border border-[#f0f0f0] mb-6">
      <Lightbulb className="w-4 h-4 text-[#f59e0b] flex-shrink-0 mt-0.5" />
      <p className="text-[12px] text-[#6b7280] leading-relaxed">{children}</p>
    </div>
  );
}

function InfoTip({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-[#f0f9ff] border border-[#e0f2fe] mb-6">
      <Info className="w-4 h-4 text-[#0284c7] flex-shrink-0 mt-0.5" />
      <p className="text-[12px] text-[#0369a1] leading-relaxed">{children}</p>
    </div>
  );
}

const inputClass = "w-full border border-[#e5e7eb] rounded-lg px-3.5 py-2.5 text-[13px] text-[#111] bg-white hover:border-[#c0c0c0] focus:border-[#e60028] focus:ring-2 focus:ring-[#e60028]/10 focus:outline-none transition-all placeholder:text-[#c0c0c0]";
const selectClass = inputClass;
const labelClass = "block text-[13px] font-medium text-[#374151] mb-1.5";

/* ─── Step Components ─────────────────────────────────────── */

function Step1() {
  return (
    <div>
      <SectionHeader title="Core Information" description="These fields establish the primary identity of your data product in the WMA catalog." />
      <HelpTip>Choose a descriptive, unique product name. It will appear in search results and data catalogs across the organization.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label className={labelClass}>Product Name <span className="text-[#e60028]">*</span></label>
          <input type="text" defaultValue="WMA Account" className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>Product Type <span className="text-[#e60028]">*</span></label>
          <input type="text" defaultValue="Composite Data Product" className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>Business Domain <span className="text-[#e60028]">*</span></label>
          <input type="text" defaultValue="Account" className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>Short Description <span className="text-[#e60028]">*</span></label>
          <input type="text" defaultValue="Brief description" className={inputClass} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Long Description <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} defaultValue="Detailed business description" className={`${inputClass} resize-y`} />
        </div>
      </div>
    </div>
  );
}

function Step2() {
  return (
    <div>
      <SectionHeader title="Ownership & Support" description="Define who is accountable for this data product and how consumers can reach support." />
      <HelpTip>Ensure backup owners are from a different team for business continuity. Slack channels should follow the #data-* naming convention.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label className={labelClass}>Data Product Owner <span className="text-[#e60028]">*</span></label>
          <input type="email" defaultValue="owner@ubs.com" className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>Backup Owner <span className="text-[#e60028]">*</span></label>
          <input type="email" defaultValue="backup@ubs.com" className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>IT Lead <span className="text-[#e60028]">*</span></label>
          <input type="email" defaultValue="itlead@ubs.com" className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>Data Steward <span className="text-[#e60028]">*</span></label>
          <input type="email" defaultValue="steward@ubs.com" className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>Support Email <span className="text-[#e60028]">*</span></label>
          <input type="email" placeholder="support@ubs.com" className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>Support Slack Channel <span className="text-[#e60028]">*</span></label>
          <input type="text" placeholder="#data-product-support" className={inputClass} />
        </div>
      </div>
    </div>
  );
}

function Step3() {
  return (
    <div>
      <SectionHeader title="Source Connection" description="Configure the upstream source system and define how access is controlled." />
      <HelpTip>Use the production URL for the canonical source. CID classification determines what downstream consumers can access.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div className="col-span-2">
          <label className={labelClass}>Source Application URL <span className="text-[#e60028]">*</span></label>
          <input type="url" defaultValue="https://source-app/" className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>Environment <span className="text-[#e60028]">*</span></label>
          <select className={selectClass}>
            <option>PROD</option>
            <option>DEV</option>
            <option>UAT</option>
          </select>
        </div>
        <div>
          <label className={labelClass}>CID Classification <span className="text-[#e60028]">*</span></label>
          <input type="text" defaultValue="Red / Green / Amber" className={inputClass} />
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Access Control <span className="text-[#e60028]">*</span></label>
          <select className={selectClass}>
            <option>Role-Based</option>
            <option>Attribute-Based</option>
            <option>Group-Based</option>
          </select>
        </div>
      </div>
    </div>
  );
}

function Step4() {
  return (
    <div>
      <SectionHeader title="Business Metadata" description="Link this data product to enterprise business glossary terms and semantic definitions." />
      <InfoTip>This step requires detailed input. You can save your progress and return later — all data is auto-saved.</InfoTip>
      <div className="space-y-5">
        <div className="p-5 rounded-xl bg-[#fafafa] border border-[#f0f0f0]">
          <p className="text-[12px] text-[#6b7280] mb-4">Define the business metadata fields for this data product. This includes business glossary terms, definitions, and semantic relationships.</p>
          <div className="space-y-5">
            <div>
              <label className={labelClass}>Business Entity <span className="text-[#e60028]">*</span></label>
              <input type="text" placeholder="e.g., Customer Account" className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Business Glossary Terms <span className="text-[#e60028]">*</span></label>
              <textarea rows={2} placeholder="Link relevant business glossary terms..." className={`${inputClass} resize-y`} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Step5() {
  return (
    <div>
      <SectionHeader title="Data Scope & Quality" description="Define how broad the data product's coverage is and what quality rules apply." />
      <HelpTip>Quality rules are enforced during pipeline execution. Choose the refresh frequency that matches your consumers' SLA expectations.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label className={labelClass}>Data Scope <span className="text-[#e60028]">*</span></label>
          <select className={selectClass}>
            <option>Global</option>
            <option>Regional</option>
            <option>Local</option>
          </select>
        </div>
        <div>
          <label className={labelClass}>Refresh Frequency <span className="text-[#e60028]">*</span></label>
          <select className={selectClass}>
            <option>Real-time</option>
            <option>Hourly</option>
            <option>Daily</option>
            <option>Weekly</option>
          </select>
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Data Quality Rules <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} placeholder="Define data quality validation rules..." className={`${inputClass} resize-y`} />
        </div>
      </div>
    </div>
  );
}

function Step6() {
  return (
    <div>
      <SectionHeader title="Service Level Agreement" description="Set the contractual guarantees between this data product and its consumers." />
      <HelpTip>Gold-tier SLAs require designated on-call support. Retention periods must comply with regulatory minimums for your data classification.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label className={labelClass}>SLA Tier <span className="text-[#e60028]">*</span></label>
          <select className={selectClass}>
            <option>Gold (99.9%)</option>
            <option>Silver (99.5%)</option>
            <option>Bronze (99%)</option>
          </select>
        </div>
        <div>
          <label className={labelClass}>Data Retention <span className="text-[#e60028]">*</span></label>
          <select className={selectClass}>
            <option>7 years</option>
            <option>5 years</option>
            <option>3 years</option>
            <option>1 year</option>
          </select>
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Access Agreement <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} placeholder="Define terms of data access and usage..." className={`${inputClass} resize-y`} />
        </div>
      </div>
    </div>
  );
}

function Step7() {
  return (
    <div>
      <SectionHeader title="Data Lineage" description="Document upstream sources and how data flows through transformation pipelines." />
      <HelpTip>Include all upstream dependencies, even indirect ones. This helps the platform trace impact when upstream sources change.</HelpTip>
      <div className="space-y-5">
        <div>
          <label className={labelClass}>Upstream Sources <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} placeholder="List all upstream data sources..." className={`${inputClass} resize-y`} />
        </div>
        <div>
          <label className={labelClass}>Transformation Logic <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} placeholder="Describe data transformations applied..." className={`${inputClass} resize-y`} />
        </div>
      </div>
    </div>
  );
}

function Step8() {
  return (
    <div>
      <SectionHeader title="Data Classification" description="Classify sensitivity and map to applicable regulatory frameworks." />
      <HelpTip>If the product contains PII, additional DLP controls will be automatically applied by the platform governance engine.</HelpTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label className={labelClass}>Data Classification <span className="text-[#e60028]">*</span></label>
          <select className={selectClass}>
            <option>Highly Confidential</option>
            <option>Confidential</option>
            <option>Internal</option>
            <option>Public</option>
          </select>
        </div>
        <div>
          <label className={labelClass}>PII Contains <span className="text-[#e60028]">*</span></label>
          <select className={selectClass}>
            <option>Yes</option>
            <option>No</option>
          </select>
        </div>
        <div className="col-span-2">
          <label className={labelClass}>Regulatory Requirements <span className="text-[#e60028]">*</span></label>
          <textarea rows={2} placeholder="List applicable regulations (GDPR, SOX, etc.)..." className={`${inputClass} resize-y`} />
        </div>
      </div>
    </div>
  );
}

function Step9() {
  return (
    <div>
      <SectionHeader title="AI & ML Configuration" description="Optional analytics capabilities for AI/ML workloads." />
      <InfoTip>This step is optional. Configure only if this data product will be consumed by AI/ML pipelines or feature stores.</InfoTip>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label className={labelClass}>ML Feature Store</label>
          <select className={selectClass}>
            <option>Not Applicable</option>
            <option>Enabled</option>
          </select>
        </div>
        <div>
          <label className={labelClass}>Vector Embeddings</label>
          <select className={selectClass}>
            <option>Not Applicable</option>
            <option>Supported</option>
          </select>
        </div>
      </div>
    </div>
  );
}

function Step10() {
  return (
    <div>
      <SectionHeader title="Final Review" description="Verify all information and submit for governance team review." />
      <div className="space-y-5">
        <div className="p-4 rounded-xl bg-[#f0fdf4] border border-[#dcfce7]">
          <h4 className="text-[13px] font-semibold text-[#15803d] mb-1">Registration Ready</h4>
          <p className="text-[12px] text-[#6b7280]">All required fields have been completed. Review your submission below.</p>
        </div>

        <div className="rounded-xl border border-[#e8e8ec] p-5 space-y-4">
          <h4 className="text-[13px] font-semibold text-[#111]">Attestation</h4>
          <label className="flex items-start gap-3 cursor-pointer group">
            <input type="checkbox" className="mt-0.5 w-4 h-4 rounded border-[#d1d5db] text-[#e60028] focus:ring-[#e60028]" />
            <span className="text-[13px] text-[#6b7280]">
              I attest that the information provided is accurate and complete to the best of my knowledge.
            </span>
          </label>
          <label className="flex items-start gap-3 cursor-pointer group">
            <input type="checkbox" className="mt-0.5 w-4 h-4 rounded border-[#d1d5db] text-[#e60028] focus:ring-[#e60028]" />
            <span className="text-[13px] text-[#6b7280]">
              I understand this registration will be reviewed by the Data Governance team.
            </span>
          </label>
        </div>

        <div className="p-4 rounded-xl bg-[#fffbeb] border border-[#fef3c7]">
          <p className="text-[12px] text-[#92400e]">
            <span className="font-semibold">Next Steps:</span> After submission, your registration will be reviewed within 2-3 business days. You will receive email notifications on status updates.
          </p>
        </div>
      </div>
    </div>
  );
}