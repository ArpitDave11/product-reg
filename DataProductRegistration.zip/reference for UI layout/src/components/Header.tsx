import {
  ChevronRight,
  Check,
  HelpCircle,
  Bell,
} from "lucide-react";

interface HeaderProps {
  currentStep: number;
  stepName: string;
}

export function Header({ currentStep, stepName }: HeaderProps) {
  return (
    <header className="flex items-center justify-between h-14 px-6 border-b border-[#e8e8ec] bg-white">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-1.5 text-[13px]">
        <span className="text-[#6b7280] hover:text-[#111] cursor-pointer transition-colors">
          Data Products
        </span>
        <ChevronRight className="w-3.5 h-3.5 text-[#d1d5db]" />
        <span className="text-[#6b7280] hover:text-[#111] cursor-pointer transition-colors">
          New Registration
        </span>
        <ChevronRight className="w-3.5 h-3.5 text-[#d1d5db]" />
        <span className="text-[#111] font-medium">
          Step {currentStep}: {stepName}
        </span>
      </nav>

      {/* Right side */}
      <div className="flex items-center gap-4">
        {/* Auto-save indicator */}
        <div className="flex items-center gap-1.5 text-[12px] text-[#22c55e] bg-[#f0fdf4] border border-[#dcfce7] px-2.5 py-1 rounded-full">
          <Check className="w-3 h-3" />
          <span className="font-medium">Saved</span>
        </div>

        {/* Keyboard shortcut hint */}
        <div className="hidden lg:flex items-center gap-1 text-[11px] text-[#9ca3af]">
          <kbd className="px-1.5 py-0.5 rounded bg-[#f3f4f6] border border-[#e5e7eb] text-[#6b7280] font-mono text-[10px]">
            Ctrl+Enter
          </kbd>
          <span>to save</span>
        </div>

        <div className="w-px h-5 bg-[#e8e8ec]" />

        {/* Help */}
        <button className="p-1.5 text-[#9ca3af] hover:text-[#6b7280] hover:bg-[#f3f4f6] rounded-lg transition-colors">
          <HelpCircle className="w-4 h-4" />
        </button>

        {/* Notifications */}
        <button className="relative p-1.5 text-[#9ca3af] hover:text-[#6b7280] hover:bg-[#f3f4f6] rounded-lg transition-colors">
          <Bell className="w-4 h-4" />
          <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-[#e60028] rounded-full" />
        </button>

        <div className="w-px h-5 bg-[#e8e8ec]" />

        {/* User avatar */}
        <div className="flex items-center gap-2.5 cursor-pointer group">
          <div className="w-7 h-7 rounded-full bg-black flex items-center justify-center text-white text-[11px] font-semibold">
            AD
          </div>
          <div className="hidden sm:flex flex-col">
            <span className="text-[12px] text-[#111] font-medium group-hover:text-[#e60028] transition-colors">
              Arpit Dave
            </span>
            <span className="text-[11px] text-[#9ca3af]">
              AI Engineer
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}