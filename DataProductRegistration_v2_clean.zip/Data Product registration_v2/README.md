
  # Data Product registration

  This is a code bundle for Data Product registration. The original project is available at https://www.figma.com/design/g5KYFcX1h8mM9yUtD30yYA/Data-Product-registration.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  