import { delay, generateId, getTimestamp, deepClone, createApiLogEntry, validateRequired, validateEmail } from '../lib/foundation';
import type {
  ApiLogEntry, MockStore, Dataset, DraftState, StepData,
  HealthResponse, DatasetsResponse, SaveResponse, ValidationResponse,
  GovernanceResponse, SubmissionResponse, ChecksResponse, ReviewResponse,
  AutomatedCheck, Review, ValidationIssue
} from '../types';

// ─── Static Mock Data ───────────────────────────────────────────────

const MOCK_DATASETS: Dataset[] = [
  {
    dataset_title: 'rcat0100', name: 'ACC_N', description: null,
    sourcedescription: null, aigenerateddescription: null,
    ontologyid: null, ontologyname: null,
    cidstaterag: 'Green', cidcategory: 'NON-CID',
    cidjustification: null, disocidcategory: 'NON-CID',
    disocidstaterag: 'Green', kde: null, dqobject: '[]',
    recommendedusage: null,
  },
  {
    dataset_title: 'rcat0100', name: 'ACC_TYPE', description: null,
    sourcedescription: null, aigenerateddescription: null,
    ontologyid: null, ontologyname: null,
    cidstaterag: 'Green', cidcategory: 'NON-CID',
    cidjustification: null, disocidcategory: 'NON-CID',
    disocidstaterag: 'Green', kde: null, dqobject: '[]',
    recommendedusage: null,
  },
  {
    dataset_title: 'rcat0200', name: 'TXN_AMT', description: 'Transaction amount',
    sourcedescription: 'Core banking', aigenerateddescription: null,
    ontologyid: 'ONT-001', ontologyname: 'Financial',
    cidstaterag: 'Amber', cidcategory: 'CID',
    cidjustification: 'Contains financial data', disocidcategory: 'CID',
    disocidstaterag: 'Amber', kde: 'Yes', dqobject: '["completeness"]',
    recommendedusage: 'Analytics',
  },
  {
    dataset_title: 'rcat0300', name: 'CUST_ID', description: 'Customer identifier',
    sourcedescription: 'CRM system', aigenerateddescription: 'Unique customer ID',
    ontologyid: 'ONT-002', ontologyname: 'Customer',
    cidstaterag: 'Red', cidcategory: 'CID',
    cidjustification: 'PII - customer identification', disocidcategory: 'CID',
    disocidstaterag: 'Red', kde: 'Yes', dqobject: '["uniqueness","completeness"]',
    recommendedusage: 'Reference data',
  },
];

// ─── Validation Rules ───────────────────────────────────────────────

interface ValidationRule {
  required: string[];
  emailFields: string[];
  warnings: string[];
}

const VALIDATION_RULES: Record<string, ValidationRule> = {
  step1: {
    required: ['productName', 'productType', 'businessDomain', 'shortDescription'],
    emailFields: [],
    warnings: ['longDescription', 'businessPurpose'],
  },
  step2: {
    required: ['owner'],
    emailFields: ['owner', 'backupOwner', 'itLead', 'dataSteward'],
    warnings: ['backupOwner', 'itLead', 'dataSteward'],
  },
  step3: {
    required: ['environment', 'cidClassification'],
    emailFields: [],
    warnings: ['sourceUrl', 'inputDatasets'],
  },
  step4: {
    required: [],
    emailFields: [],
    warnings: ['businessDefs', 'kdeMapping'],
  },
  step5: {
    required: ['threshold'],
    emailFields: [],
    warnings: ['coverage', 'completeness'],
  },
  step6: {
    required: ['updateFrequency'],
    emailFields: [],
    warnings: ['accessModes', 'deprecationPolicy'],
  },
  step7: {
    required: [],
    emailFields: [],
    warnings: ['upstreamProducts', 'lineageNarrative'],
  },
  step8: {
    required: ['classification'],
    emailFields: [],
    warnings: ['retentionReq', 'permittedUses'],
  },
  step9: {
    required: [],
    emailFields: [],
    warnings: [],
  },
  step10: {
    required: ['accuracyAttest', 'ownershipAttest', 'policyAttest'],
    emailFields: [],
    warnings: [],
  },
};

// ─── Logger Helper ──────────────────────────────────────────────────

type Logger = (entry: ApiLogEntry) => void;

// ─── A-01: Initialize Mock Store ────────────────────────────────────

/** Initialize the in-memory data store */
export function initMockStore(): MockStore {
  return {
    datasets: deepClone(MOCK_DATASETS),
    draft: null,
    submission: null,
    checksProgress: [],
    reviewStatus: [],
    _simulateErrors: false,
    _checkTick: 0,
  };
}

// ─── A-02: Health Check ─────────────────────────────────────────────

/** Simulate GET /metaq-api/health */
export async function mockGetHealth(store: MockStore, logger: Logger): Promise<HealthResponse> {
  const entry = createApiLogEntry({ method: 'GET', endpoint: '/metaq-api/health', status: 'pending' });
  logger(entry);

  await delay(300);

  if (store._simulateErrors && Math.random() < 0.2) {
    logger({ ...entry, status: 'error', duration: 300 });
    throw new Error('Service unavailable');
  }

  logger({ ...entry, status: 'ok', duration: 300 });
  return { status: 'ok' };
}

// ─── A-03: Get Datasets ─────────────────────────────────────────────

/** Simulate GET /metaq-api/datasets */
export async function mockGetDatasets(store: MockStore, logger: Logger): Promise<DatasetsResponse> {
  const entry = createApiLogEntry({ method: 'GET', endpoint: '/metaq-api/datasets', status: 'pending' });
  logger(entry);

  await delay(800);

  const data = deepClone(store.datasets);
  logger({ ...entry, status: 'ok', duration: 800 });
  return { data, limit: 100, offset: 0, count: data.length };
}

// ─── A-04: Get Dataset by Title ─────────────────────────────────────

/** Simulate GET /metaq-api/dataset/{title} */
export async function mockGetDatasetByTitle(
  store: MockStore, logger: Logger, title: string
): Promise<DatasetsResponse> {
  const entry = createApiLogEntry({
    method: 'GET', endpoint: `/metaq-api/dataset/${title}`, status: 'pending',
  });
  logger(entry);

  await delay(600);

  if (!title) {
    logger({ ...entry, status: 'ok', duration: 600 });
    return { data: [], limit: 100, offset: 0, count: 0 };
  }

  const filtered = deepClone(store.datasets.filter(d => d.dataset_title === title));
  logger({ ...entry, status: 'ok', duration: 600 });
  return { data: filtered, limit: 100, offset: 0, count: filtered.length };
}

// ─── A-05: Get Draft ────────────────────────────────────────────────

/** Simulate GET /metaq-api/registration/{id}/draft */
export async function mockGetDraft(store: MockStore, logger: Logger): Promise<DraftState> {
  const entry = createApiLogEntry({
    method: 'GET', endpoint: '/metaq-api/registration/draft', status: 'pending',
  });
  logger(entry);

  await delay(500);

  if (!store.draft) {
    logger({ ...entry, status: 'ok', duration: 500 });
    return {
      exists: false, registrationId: null, status: null,
      currentStep: 1, lastSaved: null, steps: null,
    };
  }

  logger({ ...entry, status: 'ok', duration: 500 });
  return deepClone(store.draft);
}

// ─── A-06: Save Draft ───────────────────────────────────────────────

/** Simulate PUT /metaq-api/registration/{id}/draft */
export async function mockSaveDraft(
  store: MockStore, logger: Logger, stepKey: string, stepData: StepData
): Promise<SaveResponse> {
  const entry = createApiLogEntry({
    method: 'PUT', endpoint: '/metaq-api/registration/draft', status: 'pending',
  });
  logger(entry);

  await delay(700);

  const validSteps = ['step1','step2','step3','step4','step5','step6','step7','step8','step9','step10'];
  if (!validSteps.includes(stepKey)) {
    logger({ ...entry, status: 'error', duration: 700 });
    return { success: false, message: 'Invalid step key', timestamp: getTimestamp(), registrationId: '' };
  }

  if (!stepData) {
    logger({ ...entry, status: 'error', duration: 700 });
    return { success: false, message: 'No data provided', timestamp: getTimestamp(), registrationId: '' };
  }

  // Initialize draft if first save
  if (!store.draft) {
    store.draft = {
      exists: true,
      registrationId: generateId('draft'),
      status: 'in_progress',
      currentStep: 1,
      lastSaved: getTimestamp(),
      steps: { step1: {}, step2: {}, step3: {}, step4: {}, step5: {},
               step6: {}, step7: {}, step8: {}, step9: {}, step10: {} },
    };
  }

  const stepNumber = parseInt(stepKey.replace('step', ''), 10);
  store.draft.steps![stepKey] = deepClone(stepData);
  store.draft.lastSaved = getTimestamp();
  store.draft.currentStep = Math.max(store.draft.currentStep, stepNumber);

  logger({ ...entry, status: 'ok', duration: 700 });
  return {
    success: true,
    message: `Step '${stepKey}' saved successfully`,
    timestamp: getTimestamp(),
    registrationId: store.draft.registrationId!,
  };
}

// ─── A-07: Validate Step ────────────────────────────────────────────

/** Simulate POST /metaq-api/registration/validate */
export async function mockValidateStep(
  store: MockStore, logger: Logger, stepKey: string, stepData: StepData
): Promise<ValidationResponse> {
  const entry = createApiLogEntry({
    method: 'POST', endpoint: '/metaq-api/registration/validate', status: 'pending',
  });
  logger(entry);

  await delay(400);

  const rules = VALIDATION_RULES[stepKey];
  if (!rules) {
    logger({ ...entry, status: 'ok', duration: 400 });
    return { valid: true, errors: [], warnings: [] };
  }

  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];

  // Check required fields
  for (const field of rules.required) {
    if (!validateRequired(stepData?.[field])) {
      const label = field.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase());
      errors.push({ field, message: `${label} is required` });
    }
  }

  // Check email fields (only if they have a value)
  for (const field of rules.emailFields) {
    const val = stepData?.[field];
    if (val && typeof val === 'string' && val.trim().length > 0 && !validateEmail(val)) {
      errors.push({ field, message: 'Invalid email format' });
    }
  }

  // Check warning fields
  for (const field of rules.warnings) {
    if (!validateRequired(stepData?.[field])) {
      const label = field.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase());
      warnings.push({ field, message: `${label} is recommended for better discoverability` });
    }
  }

  logger({ ...entry, status: 'ok', duration: 400 });
  return { valid: errors.length === 0, errors, warnings };
}

// ─── A-08: Governance Checks ────────────────────────────────────────

/** Simulate POST /metaq-api/registration/{id}/governance */
export async function mockRunGovernanceChecks(store: MockStore, logger: Logger): Promise<GovernanceResponse> {
  const entry = createApiLogEntry({
    method: 'POST', endpoint: '/metaq-api/registration/governance', status: 'pending',
  });
  logger(entry);

  await delay(1200);

  const draft = store.draft;
  const steps = draft?.steps || {};

  const checks = [
    {
      name: 'PII detection',
      status: 'passed' as const,
      detail: 'No PII fields detected',
    },
    {
      name: 'Retention compliance',
      status: validateRequired(steps.step8?.retentionReq) ? 'passed' as const : 'failed' as const,
      detail: validateRequired(steps.step8?.retentionReq) ? 'Meets UBS policy' : 'Retention requirement not specified',
    },
    {
      name: 'Naming conventions',
      status: (steps.step1?.productName && steps.step1.productName.includes(' ')) ? 'warning' as const : 'passed' as const,
      detail: (steps.step1?.productName && steps.step1.productName.includes(' '))
        ? 'Consider aligning to WMA naming standard (no spaces)'
        : 'Name follows conventions',
    },
    {
      name: 'Metadata completeness',
      status: validateRequired(steps.step1?.longDescription) ? 'passed' as const : 'failed' as const,
      detail: validateRequired(steps.step1?.longDescription) ? 'All metadata fields populated' : 'Long description is missing',
    },
    {
      name: 'Entitlement alignment',
      status: validateRequired(steps.step3?.cidClassification) ? 'passed' as const : 'failed' as const,
      detail: validateRequired(steps.step3?.cidClassification) ? 'Aligned with source entitlements' : 'CID classification not set',
    },
  ];

  const hasFailed = checks.some(c => c.status === 'failed');
  const hasWarning = checks.some(c => c.status === 'warning');
  const overallStatus = hasFailed ? 'failed' : hasWarning ? 'passed_with_warnings' : 'passed';

  logger({ ...entry, status: 'ok', duration: 1200 });
  return { overallStatus: overallStatus as GovernanceResponse['overallStatus'], checks };
}

// ─── A-09: Submit Registration ──────────────────────────────────────

/** Simulate POST /metaq-api/registration/{id}/submit */
export async function mockSubmitRegistration(store: MockStore, logger: Logger): Promise<SubmissionResponse> {
  const entry1 = createApiLogEntry({
    method: 'POST', endpoint: '/metaq-api/registration/submit', status: 'pending',
  });
  logger(entry1);

  await delay(1500);

  const draft = store.draft;
  const steps = draft?.steps || {};

  const trackingId = generateId('WMA');
  const submittedAt = getTimestamp();

  const catalogEntry = {
    p_dataset_data: {
      resource_iri: `wma://data-product/${(steps.step1?.productName || 'unnamed').toLowerCase().replace(/\s+/g, '-')}`,
      title: steps.step1?.productName || 'Unnamed Product',
      description: steps.step1?.shortDescription || '',
      status: 'submitted',
    },
    p_internal: {
      source_system_code: 'SPP',
      owner_team: steps.step2?.owner || '',
    },
  };

  logger({ ...entry1, status: 'ok', duration: 1500 });

  // Second call: catalog creation
  const entry2 = createApiLogEntry({
    method: 'POST', endpoint: '/metaq-api/dataset', status: 'pending',
  });
  logger(entry2);

  await delay(500);
  logger({ ...entry2, status: 'ok', duration: 500 });

  const result: SubmissionResponse = {
    success: true,
    trackingId,
    submittedAt,
    eta: '3-5 business days',
    catalogEntry,
  };

  store.submission = result;

  // Initialize checks and reviews
  store.checksProgress = [
    { name: 'Data product qualification', status: 'pending' },
    { name: 'Ontology score (advisory)', status: 'pending' },
    { name: 'Upstream source certification', status: 'pending' },
    { name: 'Entitlement source validation', status: 'pending' },
  ];
  store._checkTick = 0;

  store.reviewStatus = [
    { name: 'Upstream Data Owners', status: 'Waiting', assignedTo: 'upstream-team@ubs.com', sla: '2 days' },
    { name: 'DWO Steward', status: 'Waiting', assignedTo: 'steward@ubs.com', sla: '3 days' },
    { name: 'KDE Reviewer', status: 'Waiting', assignedTo: 'kde-team@ubs.com', sla: '3 days' },
  ];

  return result;
}

// ─── A-10: Get Automated Checks ─────────────────────────────────────

/** Simulate GET /metaq-api/registration/{id}/checks - advances state each call */
export async function mockGetAutomatedChecks(store: MockStore, logger: Logger): Promise<ChecksResponse> {
  const entry = createApiLogEntry({
    method: 'GET', endpoint: '/metaq-api/registration/checks', status: 'pending',
  });
  logger(entry);

  await delay(600);

  if (store.checksProgress.length === 0) {
    logger({ ...entry, status: 'ok', duration: 600 });
    return { status: 'running', checks: [] };
  }

  const tick = (store._checkTick || 0);
  if (tick < store.checksProgress.length) {
    // Advance one check per tick
    for (let i = 0; i < store.checksProgress.length; i++) {
      if (i < tick) {
        // Already passed
        if (store.checksProgress[i].name === 'Ontology score (advisory)') {
          store.checksProgress[i] = { ...store.checksProgress[i], status: 'passed', score: 87 };
        } else if (store.checksProgress[i].name === 'Entitlement source validation') {
          store.checksProgress[i] = { ...store.checksProgress[i], status: 'warning', note: 'Review recommended' };
        } else {
          store.checksProgress[i] = { ...store.checksProgress[i], status: 'passed' };
        }
      } else if (i === tick) {
        store.checksProgress[i] = { ...store.checksProgress[i], status: 'running' };
      }
      // else: remain pending
    }
    store._checkTick = tick + 1;
  } else {
    // All done - finalize last check
    const last = store.checksProgress[store.checksProgress.length - 1];
    if (last.status === 'running') {
      store.checksProgress[store.checksProgress.length - 1] = {
        ...last, status: 'warning', note: 'Review recommended',
      };
    }
  }

  const allDone = store.checksProgress.every(c => c.status !== 'pending' && c.status !== 'running');

  logger({ ...entry, status: 'ok', duration: 600 });
  return { status: allDone ? 'completed' : 'running', checks: deepClone(store.checksProgress) };
}

// ─── A-11: Get Review Status ────────────────────────────────────────

/** Simulate GET /metaq-api/registration/{id}/reviews */
export async function mockGetReviewStatus(store: MockStore, logger: Logger): Promise<ReviewResponse> {
  const entry = createApiLogEntry({
    method: 'GET', endpoint: '/metaq-api/registration/reviews', status: 'pending',
  });
  logger(entry);

  await delay(400);

  // If checks are completed, advance first reviewer to Pending
  const checksCompleted = store.checksProgress.length > 0 &&
    store.checksProgress.every(c => c.status !== 'pending' && c.status !== 'running');

  if (checksCompleted && store.reviewStatus.length > 0) {
    if (store.reviewStatus[0].status === 'Waiting') {
      store.reviewStatus[0] = { ...store.reviewStatus[0], status: 'Pending' };
    }
  }

  logger({ ...entry, status: 'ok', duration: 400 });
  return { reviews: deepClone(store.reviewStatus) };
}
