import { useState, useCallback, useRef, useMemo } from 'react';
import type { AppState, AppPhase, StepData, StepStatus, StepValidation, Toast, ApiLogEntry, SubmissionResponse } from '../types';
import { generateId } from '../lib/foundation';
import { initMockStore } from '../mock/api';
import type { MockStore } from '../types';

const INITIAL_STEPS: Record<string, StepData> = {
  step1: { productName: '', productType: '', businessDomain: '', shortDescription: '', longDescription: '', businessPurpose: '' },
  step2: { owner: '', backupOwner: '', itLead: '', dataSteward: '', distributionList: '', supportHours: '9AM-5PM CET', escalationPath: '' },
  step3: { sourceUrl: '', environment: '', inputDatasets: '', storageLocation: '', schemaPreview: '', ownEntitlement: '', bbsInfo: '', dpasAlignment: '', cidClassification: '' },
  step4: { businessDefs: '', exampleValues: '', kdeMapping: '', aliases: '', timeSemantics: '' },
  step5: { coverage: '', completeness: '', latency: '', knownGaps: '', recommendedUse: '', notRecommended: '', dqRuleName: '', ruleType: '', threshold: '', severityOwner: '' },
  step6: { outputDesc: '', updateFrequency: '', accessModes: '', usageRestrictions: '', deprecationPolicy: '', eligibleRoles: '', fieldRestrictions: '', crossDomainSharing: '' },
  step7: { upstreamProducts: '', upstreamCert: '', upstreamOwner: '', lineageNarrative: '', transformationLogic: '', assumptions: '', lineagePreview: '' },
  step8: { classification: '', permittedUses: '', retentionReq: '', regulatoryRefs: '', legalDisclaimers: '' },
  step9: { labelField: '', leakageNotes: '', biasDrift: '', certifiedMeasures: '', analyticsGrain: '', noviceEnablement: '' },
  step10: { accuracyAttest: false, ownershipAttest: false, policyAttest: false },
};

const INITIAL_STATUSES: Record<string, StepStatus> = {
  step1: 'active', step2: 'upcoming', step3: 'upcoming', step4: 'upcoming', step5: 'upcoming',
  step6: 'upcoming', step7: 'upcoming', step8: 'upcoming', step9: 'upcoming', step10: 'upcoming',
};

const INITIAL_VALIDATION: Record<string, StepValidation> = {};
for (let i = 1; i <= 10; i++) {
  INITIAL_VALIDATION[`step${i}`] = { errors: {}, warnings: {} };
}

export function useAppState() {
  const storeRef = useRef<MockStore>(initMockStore());

  const [state, setState] = useState<AppState>({
    phase: 'loading',
    currentStep: 1,
    steps: { ...INITIAL_STEPS },
    stepStatuses: { ...INITIAL_STATUSES },
    validation: { ...INITIAL_VALIDATION },
    lastSaved: null,
    apiHealth: false,
    submission: null,
    toasts: [],
    apiLogs: [],
    apiLogVisible: false,
  });

  const setPhase = useCallback((phase: AppPhase) => {
    setState(s => ({ ...s, phase }));
  }, []);

  const goToStep = useCallback((step: number) => {
    setState(s => {
      const statuses = { ...s.stepStatuses };
      // When leaving: only revert to 'upcoming' if step was merely 'active'
      // Preserve 'completed' and 'error' statuses
      const currentKey = `step${s.currentStep}`;
      if (statuses[currentKey] === 'active') {
        statuses[currentKey] = 'upcoming';
      }
      // When entering: only set 'active' if not already completed/error
      const targetKey = `step${step}`;
      if (statuses[targetKey] !== 'completed' && statuses[targetKey] !== 'error') {
        statuses[targetKey] = 'active';
      }
      return { ...s, currentStep: step, stepStatuses: statuses };
    });
  }, []);

  const updateStepData = useCallback((stepKey: string, data: StepData) => {
    setState(s => ({
      ...s,
      steps: { ...s.steps, [stepKey]: { ...s.steps[stepKey], ...data } },
    }));
  }, []);

  const setStepStatus = useCallback((stepKey: string, status: StepStatus) => {
    setState(s => ({
      ...s,
      stepStatuses: { ...s.stepStatuses, [stepKey]: status },
    }));
  }, []);

  const setValidation = useCallback((stepKey: string, errors: Record<string, string>, warnings: Record<string, string>) => {
    setState(s => ({
      ...s,
      validation: { ...s.validation, [stepKey]: { errors, warnings } },
    }));
  }, []);

  const setLastSaved = useCallback((ts: string | null) => {
    setState(s => ({ ...s, lastSaved: ts }));
  }, []);

  const setApiHealth = useCallback((health: boolean) => {
    setState(s => ({ ...s, apiHealth: health }));
  }, []);

  const setSubmission = useCallback((sub: SubmissionResponse | null) => {
    setState(s => ({ ...s, submission: sub }));
  }, []);

  const addToast = useCallback((toast: Omit<Toast, 'id'>) => {
    const id = generateId('toast');
    setState(s => ({ ...s, toasts: [...s.toasts, { ...toast, id }] }));
    return id;
  }, []);

  const dismissToast = useCallback((id: string) => {
    setState(s => ({ ...s, toasts: s.toasts.filter(t => t.id !== id) }));
  }, []);

  const addApiLog = useCallback((entry: ApiLogEntry) => {
    setState(s => {
      // Update existing entry with same id, or add new
      const existing = s.apiLogs.findIndex(l => l.id === entry.id);
      if (existing >= 0) {
        const updated = [...s.apiLogs];
        updated[existing] = entry;
        return { ...s, apiLogs: updated };
      }
      return { ...s, apiLogs: [...s.apiLogs, entry] };
    });
  }, []);

  const toggleApiLog = useCallback(() => {
    setState(s => ({ ...s, apiLogVisible: !s.apiLogVisible }));
  }, []);

  const loadDraft = useCallback((draft: any) => {
    if (!draft.exists || !draft.steps) return;
    setState(s => {
      const newSteps = { ...s.steps };
      const newStatuses = { ...s.stepStatuses };
      for (const key of Object.keys(draft.steps)) {
        if (draft.steps[key] && Object.keys(draft.steps[key]).length > 0) {
          newSteps[key] = { ...s.steps[key], ...draft.steps[key] };
          newStatuses[key] = 'completed';
        }
      }
      newStatuses[`step${draft.currentStep}`] = 'active';
      return {
        ...s,
        steps: newSteps,
        stepStatuses: newStatuses,
        currentStep: draft.currentStep,
        lastSaved: draft.lastSaved,
      };
    });
  }, []);

  const actions = useMemo(() => ({
    setPhase, goToStep, updateStepData, setStepStatus, setValidation,
    setLastSaved, setApiHealth, setSubmission, addToast, dismissToast,
    addApiLog, toggleApiLog, loadDraft,
  }), [setPhase, goToStep, updateStepData, setStepStatus, setValidation,
    setLastSaved, setApiHealth, setSubmission, addToast, dismissToast,
    addApiLog, toggleApiLog, loadDraft]);

  return { state, actions, store: storeRef.current };
}
