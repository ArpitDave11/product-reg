import { useEffect, useRef } from 'react';
import type { StepData } from '../types';

export function useAutoSave(
  stepData: StepData,
  stepKey: string,
  saveFn: (stepKey: string, data: StepData) => Promise<void>,
  debounceMs: number = 30000
) {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dataRef = useRef(stepData);
  dataRef.current = stepData;

  useEffect(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      saveFn(stepKey, dataRef.current);
    }, debounceMs);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [stepData, stepKey, saveFn, debounceMs]);
}
