import { useCallback, useRef } from 'react';
import type { AppState, StepData, MockStore, ApiLogEntry } from '../types';
import {
  mockGetHealth, mockGetDraft, mockGetDatasets, mockSaveDraft,
  mockValidateStep, mockRunGovernanceChecks, mockSubmitRegistration,
} from '../mock/api';

type Actions = {
  setPhase: (phase: AppState['phase']) => void;
  goToStep: (step: number) => void;
  setStepStatus: (key: string, status: any) => void;
  setValidation: (key: string, errors: Record<string, string>, warnings: Record<string, string>) => void;
  setLastSaved: (ts: string | null) => void;
  setApiHealth: (h: boolean) => void;
  setSubmission: (s: any) => void;
  addToast: (t: { type: string; message: string }) => string;
  dismissToast: (id: string) => void;
  addApiLog: (entry: ApiLogEntry) => void;
  loadDraft: (draft: any) => void;
};

export function useOrchestration(store: MockStore, actions: Actions) {
  // Use refs to always access latest actions/store without re-creating callbacks
  const storeRef = useRef(store);
  storeRef.current = store;
  const actionsRef = useRef(actions);
  actionsRef.current = actions;

  const logger = useCallback((entry: ApiLogEntry) => {
    actionsRef.current.addApiLog(entry);
  }, []);

  /** O-06: App init — health check, load draft, preload datasets */
  const handleAppInit = useCallback(async () => {
    const a = actionsRef.current;
    const s = storeRef.current;
    a.setPhase('loading');
    try {
      const health = await mockGetHealth(s, logger);
      a.setApiHealth(health.status === 'ok');
    } catch {
      a.setApiHealth(false);
    }

    const draft = await mockGetDraft(s, logger);
    if (draft.exists) {
      a.loadDraft(draft);
      a.addToast({ type: 'success', message: 'Draft loaded' });
    }

    await mockGetDatasets(s, logger);
    a.setPhase('editing');
  }, [logger]);

  /** O-04: Save & Continue — validate, save, advance */
  const handleSaveAndContinue = useCallback(async (currentStep: number, stepData: StepData) => {
    const a = actionsRef.current;
    const s = storeRef.current;
    const stepKey = `step${currentStep}`;
    const loadingId = a.addToast({ type: 'loading', message: 'Validating...' });

    const result = await mockValidateStep(s, logger, stepKey, stepData);

    if (!result.valid) {
      a.dismissToast(loadingId);
      a.addToast({ type: 'error', message: 'Please fix errors before continuing' });

      const errMap: Record<string, string> = {};
      result.errors.forEach(e => { errMap[e.field] = e.message; });
      const warnMap: Record<string, string> = {};
      result.warnings.forEach(w => { warnMap[w.field] = w.message; });
      a.setValidation(stepKey, errMap, warnMap);
      a.setStepStatus(stepKey, 'error');
      return;
    }

    a.dismissToast(loadingId);
    const saveId = a.addToast({ type: 'loading', message: 'Saving...' });

    await mockSaveDraft(s, logger, stepKey, stepData);

    a.dismissToast(saveId);
    a.addToast({ type: 'success', message: 'Step saved' });
    a.setStepStatus(stepKey, 'completed');
    a.setValidation(stepKey, {}, {});
    a.setLastSaved(new Date().toISOString());

    if (result.warnings.length > 0) {
      const warnMap: Record<string, string> = {};
      result.warnings.forEach(w => { warnMap[w.field] = w.message; });
      a.setValidation(stepKey, {}, warnMap);
    }

    if (currentStep < 10) {
      a.goToStep(currentStep + 1);
    }
  }, [logger]);

  /** Save draft only (no navigation) */
  const handleSaveDraft = useCallback(async (currentStep: number, stepData: StepData) => {
    const a = actionsRef.current;
    const s = storeRef.current;
    const stepKey = `step${currentStep}`;
    const loadingId = a.addToast({ type: 'loading', message: 'Saving draft...' });

    await mockSaveDraft(s, logger, stepKey, stepData);

    a.dismissToast(loadingId);
    a.addToast({ type: 'success', message: 'Draft saved' });
    a.setLastSaved(new Date().toISOString());
  }, [logger]);

  /** O-05: Submit — governance checks, then submit */
  const handleSubmit = useCallback(async (state: AppState) => {
    const a = actionsRef.current;
    const s = storeRef.current;
    const step10 = state.steps.step10;
    if (!step10?.accuracyAttest || !step10?.ownershipAttest || !step10?.policyAttest) {
      a.addToast({ type: 'error', message: 'All attestations must be checked before submitting' });
      return;
    }

    a.setPhase('submitting');

    const govId = a.addToast({ type: 'loading', message: 'Running governance checks...' });
    const govResult = await mockRunGovernanceChecks(s, logger);
    a.dismissToast(govId);

    if (govResult.overallStatus === 'failed') {
      a.setPhase('editing');
      const failedChecks = govResult.checks.filter(c => c.status === 'failed').map(c => c.name).join(', ');
      a.addToast({ type: 'error', message: `Governance failed: ${failedChecks}` });
      return;
    }

    if (govResult.overallStatus === 'passed_with_warnings') {
      a.addToast({ type: 'warning', message: 'Governance passed with warnings' });
    }

    const subId = a.addToast({ type: 'loading', message: 'Submitting registration...' });
    const result = await mockSubmitRegistration(s, logger);
    a.dismissToast(subId);

    a.setPhase('submitted');
    a.setSubmission(result);
    a.addToast({ type: 'success', message: `Submitted! Tracking: ${result.trackingId}` });
  }, [logger]);

  return { handleAppInit, handleSaveAndContinue, handleSaveDraft, handleSubmit };
}
