import { useEffect, useRef } from 'react';

export function usePolling(
  fn: () => Promise<void>,
  intervalMs: number,
  enabled: boolean
) {
  const runningRef = useRef(false);
  const fnRef = useRef(fn);
  fnRef.current = fn;

  useEffect(() => {
    if (!enabled) return;

    const run = async () => {
      if (runningRef.current) return;
      runningRef.current = true;
      try {
        await fnRef.current();
      } finally {
        runningRef.current = false;
      }
    };

    run(); // immediate first call
    const id = setInterval(run, intervalMs);
    return () => clearInterval(id);
  }, [enabled, intervalMs]);
}
