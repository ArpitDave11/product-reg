import { useEffect, useState, useCallback, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { RegistrationForm } from './components/RegistrationForm';
import { ToastStack, ApiLogPanel, LoadingOverlay } from './components/atoms';
import { PostSubmissionView } from './components/post';
import { useAppState } from './hooks/useAppState';
import { useOrchestration } from './hooks/useOrchestration';
import { usePolling } from './hooks/usePolling';
import { mockGetAutomatedChecks, mockGetReviewStatus } from './mock/api';
import type { ChecksResponse, Review } from './types';

export default function App() {
  const { state, actions, store } = useAppState();
  const { handleAppInit, handleSaveAndContinue, handleSaveDraft, handleSubmit } = useOrchestration(store, actions);

  // Post-submission polling state
  const [checksData, setChecksData] = useState<ChecksResponse | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);

  // Stable refs for polling
  const storeRef = useRef(store);
  storeRef.current = store;
  const actionsRef = useRef(actions);
  actionsRef.current = actions;

  // App initialization — run once
  const initRef = useRef(false);
  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;
    handleAppInit();
  }, [handleAppInit]);

  // Stable logger for polling
  const pollingLogger = useCallback((entry: any) => {
    actionsRef.current.addApiLog(entry);
  }, []);

  // Poll automated checks after submission
  usePolling(
    useCallback(async () => {
      const result = await mockGetAutomatedChecks(storeRef.current, pollingLogger);
      setChecksData(result);
    }, [pollingLogger]),
    3000,
    state.phase === 'submitted' && checksData?.status !== 'completed'
  );

  // Poll review status after submission
  usePolling(
    useCallback(async () => {
      const result = await mockGetReviewStatus(storeRef.current, pollingLogger);
      setReviews(result.reviews);
    }, [pollingLogger]),
    5000,
    state.phase === 'submitted'
  );

  // Count filled fields for progress
  const countFilledFields = (stepData: Record<string, any>): number => {
    return Object.values(stepData).filter(v => {
      if (typeof v === 'string') return v.trim().length > 0;
      if (typeof v === 'boolean') return v;
      return v !== null && v !== undefined;
    }).length;
  };

  const stepMeta = [
    { id: 1, key: 'step1', title: 'Product Identity', sub: 'Name, type, domain', required: true },
    { id: 2, key: 'step2', title: 'Ownership', sub: 'Contacts & support', required: true },
    { id: 3, key: 'step3', title: 'Connect', sub: 'Source & entitlements', required: true },
    { id: 4, key: 'step4', title: 'KDE Semantics', sub: 'Business metadata', required: true },
    { id: 5, key: 'step5', title: 'Scope & DQ', sub: 'Fitness & quality rules', required: true },
    { id: 6, key: 'step6', title: 'Data Contract', sub: 'Agreement & access', required: true },
    { id: 7, key: 'step7', title: 'Lineage', sub: 'Sources & transformations', required: true },
    { id: 8, key: 'step8', title: 'Sensitivity', sub: 'Policy & compliance', required: true },
    { id: 9, key: 'step9', title: 'AI Readiness', sub: 'Optional analytics', required: false },
    { id: 10, key: 'step10', title: 'Submit', sub: 'Attestations & review', required: true },
  ];

  const sidebarSteps = stepMeta.map(m => ({
    ...m,
    filled: countFilledFields(state.steps[m.key] || {}),
    total: Object.keys(state.steps[m.key] || {}).length,
    status: state.stepStatuses[m.key],
  }));

  // Loading phase
  if (state.phase === 'loading') {
    return <LoadingOverlay visible message="Initializing WMA Data Platform..." />;
  }

  // Submitted phase
  if (state.phase === 'submitted' && state.submission) {
    return (
      <>
        <div className="flex min-h-screen bg-white">
          <Sidebar
            currentStep={state.currentStep}
            onStepChange={() => {}}
            steps={sidebarSteps}
            phase={state.phase}
          />
          <div className="flex-1 bg-white">
            <div className="max-w-7xl mx-auto p-8">
              <PostSubmissionView
                submission={state.submission}
                checksData={checksData}
                reviews={reviews}
              />
            </div>
          </div>
        </div>
        <ToastStack toasts={state.toasts} onDismiss={actions.dismissToast} />
        <ApiLogPanel logs={state.apiLogs} visible={state.apiLogVisible} onToggle={actions.toggleApiLog} />
      </>
    );
  }

  // Editing / Submitting phase
  return (
    <>
      <div className="flex min-h-screen bg-white">
        <Sidebar
          currentStep={state.currentStep}
          onStepChange={actions.goToStep}
          steps={sidebarSteps}
          phase={state.phase}
        />
        <div className="flex-1 bg-white">
          <div className="max-w-7xl mx-auto p-8">
            <Header
              lastSaved={state.lastSaved}
              onSaveDraft={() => handleSaveDraft(state.currentStep, state.steps[`step${state.currentStep}`])}
              phase={state.phase}
            />
            <RegistrationForm
              currentStep={state.currentStep}
              stepData={state.steps[`step${state.currentStep}`]}
              errors={state.validation[`step${state.currentStep}`]?.errors || {}}
              warnings={state.validation[`step${state.currentStep}`]?.warnings || {}}
              onUpdate={(data) => actions.updateStepData(`step${state.currentStep}`, data)}
              onSaveAndContinue={() => handleSaveAndContinue(state.currentStep, state.steps[`step${state.currentStep}`])}
              onBack={() => { if (state.currentStep > 1) actions.goToStep(state.currentStep - 1); }}
              onSubmit={() => handleSubmit(state)}
            />
          </div>
        </div>
      </div>
      <ToastStack toasts={state.toasts} onDismiss={actions.dismissToast} />
      <ApiLogPanel logs={state.apiLogs} visible={state.apiLogVisible} onToggle={actions.toggleApiLog} />
      <LoadingOverlay visible={state.phase === 'submitting'} message="Submitting registration..." />
    </>
  );
}
