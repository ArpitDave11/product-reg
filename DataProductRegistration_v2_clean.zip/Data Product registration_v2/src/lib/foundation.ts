import { ApiLogEntry } from '../types';

/** F-01: Create a Promise that resolves after ms milliseconds */
export function delay(ms: number): Promise<void> {
  const safeMs = (!ms || ms < 0 || isNaN(ms)) ? 0 : ms;
  return new Promise(resolve => setTimeout(resolve, safeMs));
}

/** F-02: Generate a unique identifier string */
let idCounter = 0;
export function generateId(prefix: string): string {
  idCounter++;
  const year = new Date().getFullYear();
  const random = String(idCounter).padStart(4, '0');
  return `${prefix}-${year}-${random}`;
}

/** F-03: Return current time as ISO 8601 string */
export function getTimestamp(): string {
  return new Date().toISOString();
}

/** F-04: Format a Date or ISO string to HH:MM:SS */
export function formatTime(date: Date | string | null): string {
  try {
    const d = typeof date === 'string' ? new Date(date) : date;
    if (!d || isNaN(d.getTime())) return '00:00:00';
    return d.toTimeString().slice(0, 8);
  } catch {
    return '00:00:00';
  }
}

/** F-05: Deep clone a JSON-serializable value */
export function deepClone<T>(obj: T): T {
  if (obj === null || obj === undefined) return obj;
  if (typeof structuredClone === 'function') return structuredClone(obj);
  return JSON.parse(JSON.stringify(obj));
}

/** F-06: Validate email format */
export function validateEmail(value: string | null | undefined): boolean {
  if (!value || typeof value !== 'string') return false;
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return pattern.test(value.trim());
}

/** F-07: Check if a value is non-empty */
export function validateRequired(value: any): boolean {
  if (value === null || value === undefined) return false;
  if (typeof value === 'string') return value.trim().length > 0;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return !isNaN(value);
  if (Array.isArray(value)) return value.length > 0;
  return true;
}

/** F-08: Create a structured API log entry */
export function createApiLogEntry(options: {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  endpoint: string;
  status: 'ok' | 'pending' | 'error';
  duration?: number | null;
}): ApiLogEntry {
  return {
    id: generateId('log'),
    time: formatTime(new Date()),
    method: options.method,
    endpoint: options.endpoint,
    status: options.status,
    duration: options.duration ?? null,
  };
}
