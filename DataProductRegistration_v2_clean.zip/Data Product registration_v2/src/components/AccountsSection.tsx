import { ChevronRight } from 'lucide-react';

export function AccountsSection() {
  const accounts = [
    { number: '740B', balance: '56.01' },
    { number: '7M1N', balance: "4'008.69" },
  ];

  return (
    <section>
      <h2 className="text-xl text-gray-600 mb-4">Data Products</h2>
      <div className="space-y-3">
        {accounts.map((account, index) => (
          <div
            key={index}
            className="bg-white rounded-2xl p-6 flex items-center justify-between hover:shadow-md transition-shadow cursor-pointer"
          >
            <div className="flex items-center gap-4">
              <div className="w-8 h-8 bg-black rounded flex items-center justify-center">
                <div className="w-4 h-3 border-2 border-white rounded-sm"></div>
              </div>
              <span className="text-xl">{account.number}</span>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-gray-600 text-sm">CHF</span>
              <span className="text-xl">{account.balance}</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}