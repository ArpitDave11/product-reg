import ubsLogo from 'figma:asset/00ac1239b9b421f7eee8b4e260132b1ac860676a.png';
import { CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import type { StepStatus, AppPhase } from '../types';

interface SidebarStep {
  id: number;
  key: string;
  title: string;
  sub: string;
  filled: number;
  total: number;
  required: boolean;
  status: StepStatus;
}

interface SidebarProps {
  currentStep: number;
  onStepChange: (step: number) => void;
  steps: SidebarStep[];
  phase: AppPhase;
}

export function Sidebar({ currentStep, onStepChange, steps, phase }: SidebarProps) {
  const requiredSteps = steps.filter(s => s.required);
  const totalFilled = requiredSteps.reduce((sum, step) => sum + step.filled, 0);
  const totalFields = requiredSteps.reduce((sum, step) => sum + step.total, 0);
  const overallProgress = totalFields > 0 ? Math.round((totalFilled / totalFields) * 100) : 0;

  // Step accessibility: step N is accessible only if all previous required steps are completed
  // Step 9 is optional, so it doesn't block step 10
  const getStepAccessibility = (stepId: number): boolean => {
    if (stepId === 1) return true;
    for (let i = 1; i < stepId; i++) {
      const prev = steps.find(s => s.id === i);
      if (!prev) continue;
      // Skip optional steps (e.g. step 9) — they don't block progression
      if (!prev.required) continue;
      if (prev.status !== 'completed') return false;
    }
    return true;
  };

  const handleStepClick = (stepId: number) => {
    if (phase === 'submitted') return;
    if (!getStepAccessibility(stepId)) return;
    onStepChange(stepId);
  };

  return (
    <div className="w-80 border-r border-[#e5e5e5] bg-white p-6 flex flex-col overflow-y-auto min-h-screen">
      {/* UBS Logo */}
      <div className="flex items-center gap-3 mb-10">
        <img src={ubsLogo} alt="UBS" className="h-12" />
        <div className="flex flex-col">
          <span className="text-lg font-bold text-[#000000]">Data Platform</span>
          <span className="text-xs text-[#5a5a5a] font-medium">Product Registration</span>
        </div>
      </div>

      {/* Progress Circle */}
      <div className="mb-8">
        <div className="relative w-28 h-28 mx-auto">
          <svg className="transform -rotate-90 w-28 h-28">
            <circle cx="56" cy="56" r="50" stroke="#f4f4f4" strokeWidth="6" fill="none" />
            <circle
              cx="56" cy="56" r="50" stroke="#e60028" strokeWidth="6" fill="none"
              strokeDasharray={`${(overallProgress / 100) * 314} 314`}
              strokeLinecap="round" className="transition-all duration-500"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center flex-col">
            <span className="text-2xl font-bold text-[#e60028]">{overallProgress}%</span>
            <span className="text-xs text-[#5a5a5a]">Complete</span>
          </div>
        </div>
        <div className="text-center mt-3">
          <span className="text-xs text-[#5a5a5a] font-medium">{totalFilled} of {totalFields} required fields</span>
        </div>
      </div>

      {/* Registration Steps */}
      <div className="mb-6 flex-1">
        <h3 className="text-xs text-[#5a5a5a] uppercase font-semibold tracking-wide mb-4">Registration Steps</h3>
        <ol className="space-y-2">
          {steps.map((step) => {
            const isAccessible = getStepAccessibility(step.id);
            const isCompleted = step.status === 'completed';
            const isActive = step.id === currentStep;
            const isError = step.status === 'error';
            const isInProgress = step.filled > 0 && step.filled < step.total && !isCompleted;
            const isLocked = !isAccessible && !isCompleted;
            const progressPercent = step.total > 0 ? (step.filled / step.total) * 100 : 0;

            return (
              <li
                key={step.id}
                onClick={() => handleStepClick(step.id)}
                className={`flex gap-3 p-3 rounded-lg transition-all duration-200 ${
                  isLocked
                    ? 'opacity-50 cursor-not-allowed bg-[#fafafa] border border-[#e5e5e5]'
                    : isCompleted
                    ? 'cursor-pointer bg-[#f0fdf4] border border-[#86efac]'
                    : isError
                    ? 'cursor-pointer bg-[#fef2f2] border border-[#fca5a5]'
                    : isActive
                    ? 'cursor-pointer bg-white border-2 border-[#e60028] shadow-sm'
                    : isInProgress
                    ? 'cursor-pointer bg-white border border-[#fbbf24]'
                    : 'cursor-pointer bg-[#fafafa] border border-[#e5e5e5] hover:bg-white hover:border-[#d9d9d9]'
                }`}
              >
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                  isCompleted ? 'bg-[#22c55e] text-white'
                    : isError ? 'bg-[#dc2626] text-white'
                    : isActive ? 'bg-[#e60028] text-white'
                    : isInProgress ? 'bg-[#fbbf24] text-white'
                    : 'bg-white border border-[#d9d9d9] text-[#5a5a5a]'
                }`}>
                  {isCompleted ? <CheckCircle2 className="w-3.5 h-3.5" />
                    : isError ? <AlertCircle className="w-3.5 h-3.5" />
                    : step.id}
                </div>
                <div className="flex flex-col gap-1 flex-1 min-w-0">
                  <div className={`font-semibold text-sm ${
                    isCompleted ? 'text-[#16a34a]' : isError ? 'text-[#dc2626]' : 'text-[#000000]'
                  }`}>{step.title}</div>
                  <div className="text-xs text-[#5a5a5a]">{step.sub}</div>
                  <div className="mt-1 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className={`font-medium ${
                        isCompleted ? 'text-[#16a34a]' : isInProgress ? 'text-[#f59e0b]' : 'text-[#8c8c8c]'
                      }`}>{step.filled}/{step.total} fields</span>
                      <span className={`text-xs font-semibold ${
                        isCompleted ? 'text-[#16a34a]' : isInProgress ? 'text-[#f59e0b]' : 'text-[#8c8c8c]'
                      }`}>{Math.round(progressPercent)}%</span>
                    </div>
                    <div className={`h-1 rounded-full overflow-hidden ${isCompleted ? 'bg-[#86efac]' : 'bg-[#e5e5e5]'}`}>
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isCompleted ? 'bg-[#22c55e]' : isInProgress ? 'bg-[#fbbf24]' : 'bg-[#d9d9d9]'
                        }`}
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>
                  </div>
                </div>
                {isActive && <Clock className="w-4 h-4 text-[#e60028] flex-shrink-0" />}
              </li>
            );
          })}
        </ol>
      </div>

      {/* Status */}
      <div className="mb-6">
        <h3 className="text-xs text-[#5a5a5a] uppercase font-semibold tracking-wide mb-3">Status</h3>
        <div className="space-y-2">
          <div className={`px-4 py-2.5 rounded-lg text-white text-sm text-center font-semibold ${
            phase === 'submitted' ? 'bg-[#22c55e]' : 'bg-[#e60028]'
          }`}>
            {phase === 'submitted' ? 'Submitted' : 'In Progress'}
          </div>
          {phase !== 'submitted' && (
            <div className="text-xs text-[#5a5a5a] text-center font-medium">
              Step {currentStep} of 10 &bull; {10 - currentStep} Remaining
            </div>
          )}
        </div>
      </div>

      {/* Optional Features */}
      <div>
        <h3 className="text-xs text-[#5a5a5a] uppercase font-semibold tracking-wide mb-3">Optional Features</h3>
        <div className="border border-dashed border-[#d9d9d9] rounded-lg p-4 bg-[#fafafa] hover:border-[#e60028] transition-colors">
          <div className="font-semibold text-sm mb-1 text-[#000000]">Enterprise Catalog</div>
          <div className="text-xs text-[#5a5a5a] mb-3">Sync after WMA registration</div>
          <label className="flex items-center gap-3 cursor-pointer group">
            <div className="relative">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-10 h-5 bg-[#d9d9d9] rounded-full peer-checked:bg-[#e60028] transition-all duration-300" />
              <div className="absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full transition-all duration-300 peer-checked:translate-x-5 shadow-sm" />
            </div>
            <span className="text-sm text-[#5a5a5a] group-hover:text-[#000000] transition-colors">Register after publish</span>
          </label>
        </div>
      </div>
    </div>
  );
}
