import { CheckCircle2, Loader2, Clock, AlertTriangle } from 'lucide-react';
import type { AutomatedCheck } from '../../types';

interface AutomatedChecksPanelProps {
  checks: AutomatedCheck[] | null;
  status: 'running' | 'completed';
}

const STATUS_ICON = {
  passed: <CheckCircle2 className="w-4 h-4 text-[#16a34a]" />,
  running: <Loader2 className="w-4 h-4 text-[#2563eb] animate-spin" />,
  pending: <Clock className="w-4 h-4 text-[#9ca3af]" />,
  warning: <AlertTriangle className="w-4 h-4 text-[#d97706]" />,
};

export function AutomatedChecksPanel({ checks, status }: AutomatedChecksPanelProps) {
  return (
    <div className="border border-[#e5e5e5] rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-bold text-[#111827]">Automated Checks</h3>
        {status === 'running' ? (
          <span className="flex items-center gap-1.5 text-xs text-[#2563eb] font-medium">
            <Loader2 className="w-3 h-3 animate-spin" /> Running...
          </span>
        ) : (
          <span className="text-xs text-[#16a34a] font-medium">Completed</span>
        )}
      </div>

      {!checks || checks.length === 0 ? (
        <div className="flex items-center gap-2 py-4 text-sm text-[#9ca3af]">
          <Loader2 className="w-4 h-4 animate-spin" /> Initializing checks...
        </div>
      ) : (
        <div className="space-y-3">
          {checks.map((check, i) => (
            <div key={i} className="flex items-center justify-between py-2 border-b border-[#f3f4f6] last:border-0">
              <div className="flex items-center gap-3">
                {STATUS_ICON[check.status]}
                <span className="text-sm text-[#374151]">{check.name}</span>
              </div>
              <div className="flex items-center gap-2">
                {check.score !== undefined && (
                  <span className="text-xs text-[#6b7280] font-mono">Score: {check.score}</span>
                )}
                {check.note && (
                  <span className="text-xs text-[#d97706]">{check.note}</span>
                )}
                <span className={`text-xs font-medium capitalize ${
                  check.status === 'passed' ? 'text-[#16a34a]' :
                  check.status === 'running' ? 'text-[#2563eb]' :
                  check.status === 'warning' ? 'text-[#d97706]' : 'text-[#9ca3af]'
                }`}>
                  {check.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
