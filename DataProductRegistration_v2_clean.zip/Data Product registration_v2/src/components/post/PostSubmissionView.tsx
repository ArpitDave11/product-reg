import { ConfirmationCard } from './ConfirmationCard';
import { AutomatedChecksPanel } from './AutomatedChecksPanel';
import { ReviewDashboard } from './ReviewDashboard';
import { CertificationPipeline } from './CertificationPipeline';
import type { SubmissionResponse, AutomatedCheck, Review, ChecksResponse } from '../../types';

interface PostSubmissionViewProps {
  submission: SubmissionResponse;
  checksData: ChecksResponse | null;
  reviews: Review[];
}

export function PostSubmissionView({ submission, checksData, reviews }: PostSubmissionViewProps) {
  const checksCompleted = checksData?.status === 'completed';
  const currentStage = checksCompleted ? 2 : 1;

  return (
    <div className="max-w-4xl space-y-6">
      <ConfirmationCard
        trackingId={submission.trackingId}
        submittedAt={submission.submittedAt}
        eta={submission.eta}
      />

      <CertificationPipeline currentStage={currentStage} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AutomatedChecksPanel
          checks={checksData?.checks || null}
          status={checksData?.status || 'running'}
        />
        <ReviewDashboard reviews={reviews} />
      </div>

      <div className="border border-[#e5e5e5] rounded-xl p-6">
        <h3 className="text-sm font-bold text-[#111827] mb-3">Post-Publish Lifecycle</h3>
        <p className="text-sm text-[#6b7280]">
          After approval and publishing, your data product will be monitored for data quality,
          usage patterns, and SLA compliance. Regular reviews are conducted quarterly to ensure
          continued alignment with governance standards.
        </p>
      </div>

      <div className="border border-[#e5e5e5] rounded-xl p-6">
        <h3 className="text-sm font-bold text-[#111827] mb-3">Enterprise Catalog Entry</h3>
        <div className="bg-[#f9fafb] rounded-lg p-4 font-mono text-xs text-[#374151] overflow-x-auto">
          <pre>{JSON.stringify(submission.catalogEntry, null, 2)}</pre>
        </div>
      </div>
    </div>
  );
}
