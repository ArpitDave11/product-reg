import { CheckCircle2 } from 'lucide-react';

interface CertificationPipelineProps {
  currentStage: number;
}

const STAGES = ['Integrity', 'Entitlement', 'Register', 'Publish'];

export function CertificationPipeline({ currentStage }: CertificationPipelineProps) {
  return (
    <div className="border border-[#e5e5e5] rounded-xl p-6">
      <h3 className="text-sm font-bold text-[#111827] mb-4">Certification Pipeline</h3>
      <div className="flex items-center gap-2">
        {STAGES.map((stage, i) => (
          <div key={stage} className="flex items-center flex-1">
            <div className={`flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold w-full transition-colors ${
              i < currentStage
                ? 'bg-[#f0fdf4] text-[#16a34a] border border-[#86efac]'
                : i === currentStage
                ? 'bg-[#e60028] text-white'
                : 'bg-[#f3f4f6] text-[#9ca3af] border border-[#e5e7eb]'
            }`}>
              {i < currentStage && <CheckCircle2 className="w-3.5 h-3.5" />}
              {stage}
            </div>
            {i < STAGES.length - 1 && (
              <div className={`w-4 h-0.5 flex-shrink-0 ${i < currentStage ? 'bg-[#86efac]' : 'bg-[#e5e7eb]'}`} />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
