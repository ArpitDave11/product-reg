import { StatusPill } from '../atoms/StatusPill';
import type { Review } from '../../types';

interface ReviewDashboardProps {
  reviews: Review[];
}

const STATUS_VARIANT: Record<string, 'default' | 'progress' | 'success' | 'warning' | 'error'> = {
  Waiting: 'default',
  Pending: 'progress',
  Approved: 'success',
  Rejected: 'error',
};

export function ReviewDashboard({ reviews }: ReviewDashboardProps) {
  return (
    <div className="border border-[#e5e5e5] rounded-xl p-6">
      <h3 className="text-sm font-bold text-[#111827] mb-4">Review Status</h3>
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-[#9ca3af] border-b border-[#f3f4f6]">
            <th className="py-2 font-medium">Reviewer</th>
            <th className="py-2 font-medium">Assigned To</th>
            <th className="py-2 font-medium">Status</th>
            <th className="py-2 font-medium text-right">SLA</th>
          </tr>
        </thead>
        <tbody>
          {reviews.map((review, i) => (
            <tr key={i} className="border-b border-[#f9fafb] last:border-0">
              <td className="py-3 text-[#374151] font-medium">{review.name}</td>
              <td className="py-3 text-[#6b7280]">{review.assignedTo}</td>
              <td className="py-3">
                <StatusPill label={review.status} variant={STATUS_VARIANT[review.status] || 'default'} />
              </td>
              <td className="py-3 text-[#6b7280] text-right">{review.sla}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
