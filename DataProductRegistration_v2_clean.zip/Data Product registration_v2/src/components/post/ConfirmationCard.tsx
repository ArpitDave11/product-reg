import { CheckCircle2 } from 'lucide-react';
import { StatusPill } from '../atoms/StatusPill';

interface ConfirmationCardProps {
  trackingId: string;
  submittedAt: string;
  eta: string;
}

export function ConfirmationCard({ trackingId, submittedAt, eta }: ConfirmationCardProps) {
  const formattedDate = new Date(submittedAt).toLocaleString();

  return (
    <div className="bg-[#f0fdf4] border border-[#86efac] rounded-xl p-6">
      <div className="flex items-start gap-4">
        <div className="p-2 bg-[#22c55e] rounded-full">
          <CheckCircle2 className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <h2 className="text-lg font-bold text-[#15803d] mb-1">Registration Submitted Successfully</h2>
          <p className="text-sm text-[#6b7280] mb-4">Your data product registration has been submitted for review.</p>
          <div className="flex flex-wrap gap-3">
            <StatusPill label={`Tracking: ${trackingId}`} variant="success" />
            <StatusPill label={`Submitted: ${formattedDate}`} variant="default" />
            <StatusPill label={`ETA: ${eta}`} variant="progress" />
          </div>
        </div>
      </div>
    </div>
  );
}
