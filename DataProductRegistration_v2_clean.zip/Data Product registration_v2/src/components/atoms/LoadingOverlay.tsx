import { Loader2 } from 'lucide-react';

interface LoadingOverlayProps {
  visible: boolean;
  message: string;
}

export function LoadingOverlay({ visible, message }: LoadingOverlayProps) {
  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm">
      <div className="bg-white rounded-xl shadow-2xl px-8 py-6 flex flex-col items-center gap-3 max-w-sm">
        <Loader2 className="w-8 h-8 text-[#e60028] animate-spin" />
        <p className="text-sm font-medium text-[#374151] text-center">{message}</p>
      </div>
    </div>
  );
}
