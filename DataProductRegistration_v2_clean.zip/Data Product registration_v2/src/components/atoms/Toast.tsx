import { useEffect } from 'react';
import { X, CheckCircle2, AlertCircle, Loader2, AlertTriangle } from 'lucide-react';
import type { Toast as ToastType } from '../../types';

interface ToastStackProps {
  toasts: ToastType[];
  onDismiss: (id: string) => void;
}

const ICONS = {
  success: CheckCircle2,
  error: AlertCircle,
  loading: Loader2,
  warning: AlertTriangle,
};

const COLORS = {
  success: 'bg-[#f0fdf4] border-[#86efac] text-[#15803d]',
  error: 'bg-[#fef2f2] border-[#fca5a5] text-[#dc2626]',
  loading: 'bg-[#f0f9ff] border-[#93c5fd] text-[#2563eb]',
  warning: 'bg-[#fffbeb] border-[#fcd34d] text-[#d97706]',
};

export function ToastStack({ toasts, onDismiss }: ToastStackProps) {
  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 max-w-sm">
      {toasts.map(toast => (
        <ToastItem key={toast.id} toast={toast} onDismiss={onDismiss} />
      ))}
    </div>
  );
}

function ToastItem({ toast, onDismiss }: { toast: ToastType; onDismiss: (id: string) => void }) {
  const Icon = ICONS[toast.type];

  useEffect(() => {
    if (toast.type === 'loading') return;
    const timer = setTimeout(() => onDismiss(toast.id), 4000);
    return () => clearTimeout(timer);
  }, [toast.id, toast.type, onDismiss]);

  return (
    <div className={`flex items-center gap-3 px-4 py-3 rounded-lg border shadow-lg animate-in slide-in-from-right ${COLORS[toast.type]}`}>
      <Icon className={`w-4 h-4 flex-shrink-0 ${toast.type === 'loading' ? 'animate-spin' : ''}`} />
      <span className="text-sm font-medium flex-1">{toast.message}</span>
      <button onClick={() => onDismiss(toast.id)} className="flex-shrink-0 opacity-60 hover:opacity-100">
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}
