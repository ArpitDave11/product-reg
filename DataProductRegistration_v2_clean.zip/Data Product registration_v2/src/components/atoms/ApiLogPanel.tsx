import { useEffect, useRef } from 'react';
import { Activity, X } from 'lucide-react';
import type { ApiLogEntry } from '../../types';

interface ApiLogPanelProps {
  logs: ApiLogEntry[];
  visible: boolean;
  onToggle: () => void;
}

const METHOD_COLORS: Record<string, string> = {
  GET: 'text-[#2563eb]',
  POST: 'text-[#16a34a]',
  PUT: 'text-[#d97706]',
  DELETE: 'text-[#dc2626]',
};

const STATUS_COLORS: Record<string, string> = {
  ok: 'text-[#16a34a]',
  pending: 'text-[#d97706]',
  error: 'text-[#dc2626]',
};

export function ApiLogPanel({ logs, visible, onToggle }: ApiLogPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (visible && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, visible]);

  return (
    <>
      {/* Pill button — top-right corner, always visible when panel is closed */}
      {!visible && (
        <button
          onClick={onToggle}
          className="fixed top-4 right-6 z-[9999] flex items-center gap-2 px-4 py-2 rounded-full hover:shadow-lg hover:border-[#e60028] transition-all text-sm font-medium text-[#374151] border border-[#e5e5e5]/40 bg-transparent"
        >
          <Activity className="w-4 h-4 text-[#e60028]" />
          API Log ({logs.length})
        </button>
      )}

      {/* Right-side vertical overlay drawer */}
      <div
        className={`fixed top-0 right-0 z-[9999] h-full w-[380px] max-w-[90vw] bg-transparent transform transition-transform duration-300 ease-in-out ${
          visible ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#e5e5e5]/30 bg-transparent">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#374151]">
            <Activity className="w-4 h-4 text-[#e60028]" />
            API Activity Log
            <span className="ml-1 text-xs font-normal text-[#9ca3af]">({logs.length} calls)</span>
          </div>
          <button
            onClick={onToggle}
            className="p-1.5 rounded-md hover:bg-[#e5e7eb] transition-colors"
          >
            <X className="w-4 h-4 text-[#6b7280]" />
          </button>
        </div>

        {/* Log entries — fills remaining height */}
        <div ref={scrollRef} className="overflow-y-auto h-[calc(100%-49px)] px-3 py-2">
          {logs.length === 0 ? (
            <p className="text-sm text-[#9ca3af] py-4 text-center">No API calls yet</p>
          ) : (
            <div className="space-y-0">
              {logs.map(log => (
                <div key={log.id} className="flex items-start gap-2 py-2 text-xs font-mono border-b border-[#e5e5e5]/20">
                  <span className="text-[#9ca3af] shrink-0 w-[52px]">{log.time}</span>
                  <span className={`font-bold shrink-0 w-[38px] ${METHOD_COLORS[log.method] || ''}`}>{log.method}</span>
                  <span className="text-[#374151] flex-1 truncate">{log.endpoint}</span>
                  <span className={`shrink-0 w-[28px] text-center ${STATUS_COLORS[log.status] || ''}`}>
                    {log.status === 'pending' ? '...' : log.status}
                  </span>
                  <span className="text-[#6b7280] shrink-0 w-[46px] text-right">
                    {log.duration !== null ? `${log.duration}ms` : '—'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
