interface BadgeProps {
  variant: 'required' | 'optional';
}

export function Badge({ variant }: BadgeProps) {
  const classes = variant === 'required'
    ? 'bg-[#fef2f2] text-[#dc2626] border-[#fca5a5]'
    : 'bg-[#f3f4f6] text-[#6b7280] border-[#e5e7eb]';

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold border ${classes}`}>
      {variant === 'required' ? 'Required' : 'Optional'}
    </span>
  );
}
