interface FieldProps {
  label: string;
  value: any;
  onChange: (newValue: any) => void;
  type?: 'text' | 'textarea' | 'select' | 'checkbox';
  options?: string[];
  placeholder?: string;
  disabled?: boolean;
  error?: string;
  warning?: string;
  span2?: boolean;
  required?: boolean;
}

export function Field({
  label, value, onChange, type = 'text', options, placeholder,
  disabled, error, warning, span2, required,
}: FieldProps) {
  const baseInputClass = `w-full border rounded-lg px-3.5 py-2.5 text-sm text-[#000000] transition-colors focus:outline-none ${
    error
      ? 'border-[#dc2626] focus:border-[#dc2626] focus:ring-1 focus:ring-[#dc2626]'
      : 'border-[#d1d5db] hover:border-[#9ca3af] focus:border-[#e60028] focus:ring-1 focus:ring-[#e60028]'
  } ${disabled ? 'bg-[#f9fafb] text-[#9ca3af] cursor-not-allowed' : ''}`;

  return (
    <div className={`space-y-1.5 ${span2 ? 'col-span-2' : ''}`}>
      {type !== 'checkbox' && (
        <label className="block text-sm font-medium text-[#374151]">
          {label} {required && <span className="text-[#e60028]">*</span>}
        </label>
      )}

      {type === 'text' && (
        <input
          type="text"
          value={value || ''}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          className={baseInputClass}
        />
      )}

      {type === 'textarea' && (
        <textarea
          rows={3}
          value={value || ''}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          className={`${baseInputClass} resize-y`}
        />
      )}

      {type === 'select' && (
        <select
          value={value || ''}
          onChange={e => onChange(e.target.value)}
          disabled={disabled}
          className={baseInputClass}
        >
          <option value="">Select...</option>
          {options?.map(opt => (
            <option key={opt} value={opt}>{opt}</option>
          ))}
        </select>
      )}

      {type === 'checkbox' && (
        <label className="flex items-start gap-3 cursor-pointer group">
          <input
            type="checkbox"
            checked={!!value}
            onChange={e => onChange(e.target.checked)}
            disabled={disabled}
            className="mt-0.5 w-4 h-4 rounded border-[#d1d5db] text-[#e60028] focus:ring-[#e60028]"
          />
          <span className="text-sm text-[#374151]">{label}</span>
        </label>
      )}

      {error && <p className="text-xs text-[#dc2626] font-medium">{error}</p>}
      {warning && !error && <p className="text-xs text-[#d97706] font-medium">{warning}</p>}
    </div>
  );
}
