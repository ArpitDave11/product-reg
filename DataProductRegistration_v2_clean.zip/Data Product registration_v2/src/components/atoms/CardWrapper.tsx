import type { ReactNode } from 'react';

interface CardWrapperProps {
  children: ReactNode;
  muted?: boolean;
  className?: string;
}

export function CardWrapper({ children, muted, className = '' }: CardWrapperProps) {
  return (
    <div className={`border border-[#e5e5e5] rounded-xl p-6 ${muted ? 'bg-[#f9fafb]' : 'bg-white'} ${className}`}>
      {children}
    </div>
  );
}
