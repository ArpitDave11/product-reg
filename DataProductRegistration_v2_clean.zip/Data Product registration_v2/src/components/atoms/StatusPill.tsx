interface StatusPillProps {
  label: string;
  variant?: 'default' | 'progress' | 'success' | 'warning' | 'error';
}

const VARIANT_CLASSES: Record<string, string> = {
  default: 'bg-[#f3f4f6] text-[#6b7280] border-[#e5e7eb]',
  progress: 'bg-[#eff6ff] text-[#2563eb] border-[#bfdbfe]',
  success: 'bg-[#f0fdf4] text-[#16a34a] border-[#86efac]',
  warning: 'bg-[#fffbeb] text-[#d97706] border-[#fcd34d]',
  error: 'bg-[#fef2f2] text-[#dc2626] border-[#fca5a5]',
};

export function StatusPill({ label, variant = 'default' }: StatusPillProps) {
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${VARIANT_CLASSES[variant]}`}>
      {label}
    </span>
  );
}
