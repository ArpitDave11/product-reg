import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

export function SpendingAnalysis() {
  const data = [
    { name: 'Active', value: 42, color: '#8b4444' },
    { name: 'In Review', value: 28, color: '#a66060' },
    { name: 'Pending Approval', value: 18, color: '#c97c7c' },
    { name: 'Published', value: 35, color: '#8b4444' },
    { name: 'Draft', value: 15, color: '#e8b8b8' },
    { name: 'Archived', value: 8, color: '#c97c7c' },
    { name: 'Rejected', value: 6, color: '#f0d0d0' },
  ];

  const total = data.reduce((sum, item) => sum + item.value, 0);

  return (
    <section className="bg-white rounded-3xl p-8">
      <h2 className="text-xl text-gray-600 mb-6">Registration Overview</h2>
      
      <div className="flex items-center gap-8">
        {/* Donut Chart */}
        <div className="relative w-48 h-48">
          <PieChart width={192} height={192}>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={90}
              paddingAngle={2}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
          </PieChart>
          <div className="absolute inset-0 flex items-center justify-center flex-col">
            <span className="text-sm text-gray-600">Total</span>
            <span className="text-2xl font-semibold">{total}</span>
          </div>
        </div>

        {/* Legend */}
        <div className="flex-1 space-y-3">
          {data.map((item, index) => (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: item.color }}
                ></div>
                <span className="text-sm text-gray-700">{item.name}</span>
              </div>
              <span className="text-sm">{item.value} datasets</span>
            </div>
          ))}
        </div>
      </div>

      <p className="text-sm text-gray-600 text-center mt-6">
        Dataset registrations<br />
        increased by <span className="font-semibold">24%</span><br />
        from last quarter.
      </p>
    </section>
  );
}