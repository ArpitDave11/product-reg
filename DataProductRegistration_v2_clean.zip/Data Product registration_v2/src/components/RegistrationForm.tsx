import {
  Package, Users, Link2, Database, CheckSquare, FileText,
  GitBranch, Shield, Sparkles, Send, ArrowRight, ChevronLeft
} from 'lucide-react';
import { Step1, Step2, Step3, Step4, Step5, Step6, Step7, Step8, Step9, Step10 } from './steps';
import type { StepData } from '../types';

interface RegistrationFormProps {
  currentStep: number;
  stepData: StepData;
  errors: Record<string, string>;
  warnings: Record<string, string>;
  onUpdate: (data: StepData) => void;
  onSaveAndContinue: () => void;
  onBack: () => void;
  onSubmit: () => void;
}

const STEP_INFO = [
  { number: 1, title: 'Product Identity', icon: Package, description: 'Define core product identity and characteristics.' },
  { number: 2, title: 'Ownership & Contacts', icon: Users, description: 'Define ownership, contacts and support information.' },
  { number: 3, title: 'Connect to Source', icon: Link2, description: 'Link source system and configure entitlements.' },
  { number: 4, title: 'KDE Semantics', icon: Database, description: 'Define business metadata and semantic information.' },
  { number: 5, title: 'Scope & Data Quality', icon: CheckSquare, description: 'Define data scope, fitness criteria and quality rules.' },
  { number: 6, title: 'Data Contract', icon: FileText, description: 'Define SLAs, guarantees and access agreements.' },
  { number: 7, title: 'Data Lineage', icon: GitBranch, description: 'Document data sources, transformations and flows.' },
  { number: 8, title: 'Sensitivity & Compliance', icon: Shield, description: 'Define data sensitivity and compliance requirements.' },
  { number: 9, title: 'AI Readiness', icon: Sparkles, description: 'Optional: Configure AI/ML analytics capabilities.' },
  { number: 10, title: 'Submit & Attestation', icon: Send, description: 'Review and submit your data product registration.' },
];

const STEP_COMPONENTS = [Step1, Step2, Step3, Step4, Step5, Step6, Step7, Step8, Step9, Step10];

export function RegistrationForm({
  currentStep, stepData, errors, warnings, onUpdate, onSaveAndContinue, onBack, onSubmit,
}: RegistrationFormProps) {
  const info = STEP_INFO[currentStep - 1];
  const StepIcon = info.icon;
  const StepComponent = STEP_COMPONENTS[currentStep - 1];

  return (
    <div className="max-w-4xl">
      {/* Step Header */}
      <div className="mb-8">
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#e60028]/10 rounded-lg">
              <StepIcon className="w-5 h-5 text-[#e60028]" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-[#000000]">
                Register Data Product: Step {currentStep} &ndash; {info.title}
              </h1>
              <p className="text-sm text-[#6b7280] mt-1">{info.description}</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2 mt-1">
            <span className="text-sm text-[#9ca3af] font-medium whitespace-nowrap">{currentStep} of 10</span>
            {currentStep === 9 && (
              <span className="text-xs text-[#0891b2] font-semibold bg-[#ecfeff] border border-[#a5f3fc] px-2.5 py-1 rounded whitespace-nowrap">OPTIONAL</span>
            )}
          </div>
        </div>
        <div className="w-full bg-[#f3f4f6] rounded-full h-2 overflow-hidden">
          <div
            className="bg-[#e60028] h-full transition-all duration-500 ease-out rounded-full"
            style={{ width: `${(currentStep / 10) * 100}%` }}
          />
        </div>
      </div>

      {/* Step Content */}
      <div className="bg-white border border-[#e5e5e5] rounded-xl shadow-sm p-10">
        <StepComponent data={stepData} onUpdate={onUpdate} errors={errors} warnings={warnings} />

        {/* Navigation */}
        <div className="flex justify-between items-center mt-10 pt-8 border-t border-[#e5e5e5]">
          <button
            onClick={onBack}
            disabled={currentStep === 1}
            className={`px-5 py-2.5 border border-[#d9d9d9] rounded-lg text-sm font-medium transition-all duration-200 flex items-center gap-2 ${
              currentStep === 1
                ? 'bg-[#fafafa] text-[#a3a3a3] cursor-not-allowed'
                : 'bg-white text-[#000000] hover:bg-[#fafafa] hover:border-[#000000]'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            Back
          </button>

          {currentStep < 10 ? (
            <button
              onClick={onSaveAndContinue}
              className="px-5 py-2.5 bg-[#e60028] text-white rounded-lg text-sm font-medium hover:bg-[#c50023] transition-all duration-200 flex items-center gap-2"
            >
              Save & Continue
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onSubmit}
              className="px-5 py-2.5 bg-[#22c55e] text-white rounded-lg text-sm font-medium hover:bg-[#16a34a] transition-all duration-200 flex items-center gap-2"
            >
              Submit Registration
              <Send className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
