import { Save } from 'lucide-react';
import type { AppPhase } from '../types';

interface HeaderProps {
  lastSaved: string | null;
  onSaveDraft: () => void;
  phase: AppPhase;
}

export function Header({ lastSaved, onSaveDraft, phase }: HeaderProps) {
  const savedText = lastSaved
    ? `Last saved: ${new Date(lastSaved).toLocaleTimeString()}`
    : 'Not saved yet';

  return (
    <header className="bg-white border border-[#e5e5e5] rounded-lg shadow-sm px-8 py-6 mb-8">
      <div className="flex items-start justify-between">
        <div className="flex flex-col gap-3">
          <div className="flex flex-col gap-1">
            <h1 className="text-2xl font-bold text-[#000000]">Register Data Product</h1>
            <p className="text-sm text-[#6b7280]">
              Aligned to WMA governance standards and data platform requirements
            </p>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-[#9ca3af]">{savedText}</span>
          </div>
        </div>

        <div className="flex gap-3">
          <button
            onClick={onSaveDraft}
            disabled={phase === 'submitting'}
            className="px-5 py-2.5 border border-[#d1d5db] rounded-lg text-sm font-medium text-[#374151] bg-white hover:bg-[#f9fafb] hover:border-[#9ca3af] transition-all duration-200 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save className="w-4 h-4" />
            Save Draft
          </button>
        </div>
      </div>
    </header>
  );
}
