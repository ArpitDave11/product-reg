import { ChevronRight } from 'lucide-react';

export function QuickActions() {
  const actions = [
    { label: 'Payment to card' },
    { label: 'Send money' },
  ];

  return (
    <section>
      <h2 className="text-xl text-gray-600 mb-4">Quick actions</h2>
      <div className="space-y-3">
        {actions.map((action, index) => (
          <button
            key={index}
            className="w-full bg-white rounded-2xl p-6 flex items-center justify-between hover:shadow-md transition-shadow"
          >
            <span className="text-lg">{action.label}</span>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>
        ))}
      </div>
    </section>
  );
}
