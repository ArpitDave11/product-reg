import { Field } from '../atoms/Field';
import type { StepFormProps } from './StepProps';

export function Step1({ data, onUpdate, errors, warnings }: StepFormProps) {
  const set = (field: string) => (value: any) => onUpdate({ ...data, [field]: value });
  return (
    <div className="grid grid-cols-2 gap-x-6 gap-y-5">
      <Field label="Product Name" value={data.productName} onChange={set('productName')} required error={errors.productName} warning={warnings.productName} />
      <Field label="Product Type" value={data.productType} onChange={set('productType')} type="select" options={['Composite Data Product', 'Raw Data Product', 'Derived Data Product']} required error={errors.productType} warning={warnings.productType} />
      <Field label="Business Domain" value={data.businessDomain} onChange={set('businessDomain')} type="select" options={['Account', 'Transaction', 'Customer', 'Risk', 'Compliance']} required error={errors.businessDomain} warning={warnings.businessDomain} />
      <Field label="Short Description" value={data.shortDescription} onChange={set('shortDescription')} required error={errors.shortDescription} warning={warnings.shortDescription} />
      <Field label="Long Description" value={data.longDescription} onChange={set('longDescription')} type="textarea" span2 error={errors.longDescription} warning={warnings.longDescription} />
      <Field label="Business Purpose" value={data.businessPurpose} onChange={set('businessPurpose')} type="textarea" span2 error={errors.businessPurpose} warning={warnings.businessPurpose} />
    </div>
  );
}
