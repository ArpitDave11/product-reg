import { Field } from '../atoms/Field';
import type { StepFormProps } from './StepProps';

export function Step5({ data, onUpdate, errors, warnings }: StepFormProps) {
  const set = (field: string) => (value: any) => onUpdate({ ...data, [field]: value });
  return (
    <div className="grid grid-cols-2 gap-x-6 gap-y-5">
      <Field label="Coverage" value={data.coverage} onChange={set('coverage')} error={errors.coverage} warning={warnings.coverage} />
      <Field label="Completeness" value={data.completeness} onChange={set('completeness')} error={errors.completeness} warning={warnings.completeness} />
      <Field label="Latency" value={data.latency} onChange={set('latency')} error={errors.latency} />
      <Field label="Known Gaps" value={data.knownGaps} onChange={set('knownGaps')} error={errors.knownGaps} />
      <Field label="Recommended Use" value={data.recommendedUse} onChange={set('recommendedUse')} error={errors.recommendedUse} />
      <Field label="Not Recommended For" value={data.notRecommended} onChange={set('notRecommended')} error={errors.notRecommended} />
      <Field label="DQ Rule Name" value={data.dqRuleName} onChange={set('dqRuleName')} error={errors.dqRuleName} />
      <Field label="Rule Type" value={data.ruleType} onChange={set('ruleType')} type="select" options={['Completeness', 'Accuracy', 'Timeliness', 'Consistency']} error={errors.ruleType} />
      <Field label="Threshold" value={data.threshold} onChange={set('threshold')} required placeholder="e.g., 95%" error={errors.threshold} warning={warnings.threshold} />
      <Field label="Severity Owner" value={data.severityOwner} onChange={set('severityOwner')} error={errors.severityOwner} />
    </div>
  );
}
