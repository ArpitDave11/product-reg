import { Field } from '../atoms/Field';
import type { StepFormProps } from './StepProps';

export function Step4({ data, onUpdate, errors, warnings }: StepFormProps) {
  const set = (field: string) => (value: any) => onUpdate({ ...data, [field]: value });
  return (
    <div className="space-y-6">
      <div className="bg-[#f9fafb] border border-[#e5e7eb] rounded-lg p-5">
        <p className="text-sm text-[#6b7280] mb-4">Define the business metadata fields for this data product. This includes business glossary terms, definitions, and semantic relationships.</p>
        <div className="grid grid-cols-2 gap-x-6 gap-y-5">
          <Field label="Business Definitions" value={data.businessDefs} onChange={set('businessDefs')} type="textarea" span2 error={errors.businessDefs} warning={warnings.businessDefs} />
          <Field label="Example Values" value={data.exampleValues} onChange={set('exampleValues')} type="textarea" span2 error={errors.exampleValues} warning={warnings.exampleValues} />
          <Field label="KDE Mapping" value={data.kdeMapping} onChange={set('kdeMapping')} error={errors.kdeMapping} warning={warnings.kdeMapping} />
          <Field label="Aliases" value={data.aliases} onChange={set('aliases')} error={errors.aliases} warning={warnings.aliases} />
          <Field label="Time Semantics" value={data.timeSemantics} onChange={set('timeSemantics')} span2 error={errors.timeSemantics} warning={warnings.timeSemantics} />
        </div>
      </div>
    </div>
  );
}
