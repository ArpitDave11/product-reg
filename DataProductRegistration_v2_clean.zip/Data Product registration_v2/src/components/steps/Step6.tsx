import { Field } from '../atoms/Field';
import type { StepFormProps } from './StepProps';

export function Step6({ data, onUpdate, errors, warnings }: StepFormProps) {
  const set = (field: string) => (value: any) => onUpdate({ ...data, [field]: value });
  return (
    <div className="grid grid-cols-2 gap-x-6 gap-y-5">
      <Field label="Output Description" value={data.outputDesc} onChange={set('outputDesc')} type="textarea" span2 error={errors.outputDesc} />
      <Field label="Update Frequency" value={data.updateFrequency} onChange={set('updateFrequency')} type="select" options={['Real-time', 'Hourly', 'Daily', 'Weekly', 'Monthly']} required error={errors.updateFrequency} warning={warnings.updateFrequency} />
      <Field label="Access Modes" value={data.accessModes} onChange={set('accessModes')} type="select" options={['API', 'File Download', 'Streaming', 'Database']} error={errors.accessModes} warning={warnings.accessModes} />
      <Field label="Usage Restrictions" value={data.usageRestrictions} onChange={set('usageRestrictions')} type="textarea" span2 error={errors.usageRestrictions} />
      <Field label="Deprecation Policy" value={data.deprecationPolicy} onChange={set('deprecationPolicy')} error={errors.deprecationPolicy} warning={warnings.deprecationPolicy} />
      <Field label="Eligible Roles" value={data.eligibleRoles} onChange={set('eligibleRoles')} error={errors.eligibleRoles} />
      <Field label="Field Restrictions" value={data.fieldRestrictions} onChange={set('fieldRestrictions')} error={errors.fieldRestrictions} />
      <Field label="Cross-Domain Sharing" value={data.crossDomainSharing} onChange={set('crossDomainSharing')} type="select" options={['Allowed', 'Restricted', 'Prohibited']} error={errors.crossDomainSharing} />
    </div>
  );
}
