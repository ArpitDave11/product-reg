import { Field } from '../atoms/Field';
import type { StepFormProps } from './StepProps';

export function Step8({ data, onUpdate, errors, warnings }: StepFormProps) {
  const set = (field: string) => (value: any) => onUpdate({ ...data, [field]: value });
  return (
    <div className="grid grid-cols-2 gap-x-6 gap-y-5">
      <Field label="Data Classification" value={data.classification} onChange={set('classification')} type="select" options={['Highly Confidential', 'Confidential', 'Internal', 'Public']} required error={errors.classification} warning={warnings.classification} />
      <Field label="Permitted Uses" value={data.permittedUses} onChange={set('permittedUses')} error={errors.permittedUses} warning={warnings.permittedUses} />
      <Field label="Retention Requirement" value={data.retentionReq} onChange={set('retentionReq')} type="select" options={['7 years', '5 years', '3 years', '1 year']} error={errors.retentionReq} warning={warnings.retentionReq} />
      <Field label="Regulatory References" value={data.regulatoryRefs} onChange={set('regulatoryRefs')} error={errors.regulatoryRefs} />
      <Field label="Legal Disclaimers" value={data.legalDisclaimers} onChange={set('legalDisclaimers')} type="textarea" span2 error={errors.legalDisclaimers} />
    </div>
  );
}
