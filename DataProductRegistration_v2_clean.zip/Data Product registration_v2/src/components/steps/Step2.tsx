import { Field } from '../atoms/Field';
import type { StepFormProps } from './StepProps';

export function Step2({ data, onUpdate, errors, warnings }: StepFormProps) {
  const set = (field: string) => (value: any) => onUpdate({ ...data, [field]: value });
  return (
    <div className="grid grid-cols-2 gap-x-6 gap-y-5">
      <Field label="Data Product Owner" value={data.owner} onChange={set('owner')} placeholder="owner@ubs.com" required error={errors.owner} warning={warnings.owner} />
      <Field label="Backup Owner" value={data.backupOwner} onChange={set('backupOwner')} placeholder="backup@ubs.com" error={errors.backupOwner} warning={warnings.backupOwner} />
      <Field label="IT Lead" value={data.itLead} onChange={set('itLead')} placeholder="itlead@ubs.com" error={errors.itLead} warning={warnings.itLead} />
      <Field label="Data Steward" value={data.dataSteward} onChange={set('dataSteward')} placeholder="steward@ubs.com" error={errors.dataSteward} warning={warnings.dataSteward} />
      <Field label="Distribution List" value={data.distributionList} onChange={set('distributionList')} placeholder="dl-team@ubs.com" error={errors.distributionList} warning={warnings.distributionList} />
      <Field label="Support Hours" value={data.supportHours} onChange={set('supportHours')} disabled />
      <Field label="Escalation Path" value={data.escalationPath} onChange={set('escalationPath')} span2 error={errors.escalationPath} warning={warnings.escalationPath} />
    </div>
  );
}
