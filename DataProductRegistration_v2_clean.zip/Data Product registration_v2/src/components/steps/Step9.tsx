import { Field } from '../atoms/Field';
import type { StepFormProps } from './StepProps';

export function Step9({ data, onUpdate, errors, warnings }: StepFormProps) {
  const set = (field: string) => (value: any) => onUpdate({ ...data, [field]: value });
  return (
    <div className="space-y-6">
      <div className="bg-[#f0f9ff] border border-[#bfdbfe] rounded-lg p-5">
        <p className="text-sm text-[#1e40af]">This step is optional. Configure if this data product will be used for AI/ML workloads.</p>
      </div>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <Field label="Label Field" value={data.labelField} onChange={set('labelField')} error={errors.labelField} />
        <Field label="Leakage Notes" value={data.leakageNotes} onChange={set('leakageNotes')} error={errors.leakageNotes} />
        <Field label="Bias & Drift" value={data.biasDrift} onChange={set('biasDrift')} error={errors.biasDrift} />
        <Field label="Certified Measures" value={data.certifiedMeasures} onChange={set('certifiedMeasures')} error={errors.certifiedMeasures} />
        <Field label="Analytics Grain" value={data.analyticsGrain} onChange={set('analyticsGrain')} error={errors.analyticsGrain} />
        <Field label="Novice Enablement" value={data.noviceEnablement} onChange={set('noviceEnablement')} error={errors.noviceEnablement} />
      </div>
    </div>
  );
}
