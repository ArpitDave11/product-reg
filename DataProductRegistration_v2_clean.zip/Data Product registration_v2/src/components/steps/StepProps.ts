import type { StepData } from '../../types';

export interface StepFormProps {
  data: StepData;
  onUpdate: (data: StepData) => void;
  errors: Record<string, string>;
  warnings: Record<string, string>;
}
