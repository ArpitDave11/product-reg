import { Field } from '../atoms/Field';
import type { StepFormProps } from './StepProps';

export function Step7({ data, onUpdate, errors, warnings }: StepFormProps) {
  const set = (field: string) => (value: any) => onUpdate({ ...data, [field]: value });
  return (
    <div className="space-y-5">
      <Field label="Upstream Products" value={data.upstreamProducts} onChange={set('upstreamProducts')} type="textarea" error={errors.upstreamProducts} warning={warnings.upstreamProducts} />
      <div className="grid grid-cols-2 gap-x-6 gap-y-5">
        <Field label="Upstream Certification" value={data.upstreamCert} onChange={set('upstreamCert')} error={errors.upstreamCert} />
        <Field label="Upstream Owner" value={data.upstreamOwner} onChange={set('upstreamOwner')} error={errors.upstreamOwner} />
      </div>
      <Field label="Lineage Narrative" value={data.lineageNarrative} onChange={set('lineageNarrative')} type="textarea" error={errors.lineageNarrative} warning={warnings.lineageNarrative} />
      <Field label="Transformation Logic" value={data.transformationLogic} onChange={set('transformationLogic')} type="textarea" error={errors.transformationLogic} />
      <Field label="Assumptions" value={data.assumptions} onChange={set('assumptions')} type="textarea" error={errors.assumptions} />
    </div>
  );
}
