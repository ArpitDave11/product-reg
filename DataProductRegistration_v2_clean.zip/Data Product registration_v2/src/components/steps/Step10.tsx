import { Field } from '../atoms/Field';
import type { StepFormProps } from './StepProps';

export function Step10({ data, onUpdate, errors, warnings }: StepFormProps) {
  const set = (field: string) => (value: any) => onUpdate({ ...data, [field]: value });
  return (
    <div className="space-y-6">
      <div className="bg-[#f0fdf4] border border-[#bbf7d0] rounded-lg p-5">
        <h3 className="text-sm font-semibold text-[#15803d] mb-2">Review & Submit</h3>
        <p className="text-sm text-[#6b7280]">Please review all steps and confirm the attestations below before submitting.</p>
      </div>

      <div className="border border-[#e5e7eb] rounded-lg p-5 space-y-4">
        <h3 className="text-sm font-semibold text-[#111827]">Attestation</h3>
        <Field label="I attest that the information provided is accurate and complete to the best of my knowledge." value={data.accuracyAttest} onChange={set('accuracyAttest')} type="checkbox" error={errors.accuracyAttest} />
        <Field label="I confirm ownership responsibility for this data product and its ongoing maintenance." value={data.ownershipAttest} onChange={set('ownershipAttest')} type="checkbox" error={errors.ownershipAttest} />
        <Field label="I acknowledge this registration will be reviewed against UBS data governance policies." value={data.policyAttest} onChange={set('policyAttest')} type="checkbox" error={errors.policyAttest} />
      </div>

      <div className="bg-[#fffbeb] border border-[#fef3c7] rounded-lg p-5">
        <p className="text-sm text-[#92400e]">
          <strong>Next Steps:</strong> After submission, your registration will undergo automated checks and governance review. Expected timeline: 3-5 business days.
        </p>
      </div>

      <div className="border border-[#e5e7eb] rounded-lg p-5">
        <h3 className="text-sm font-semibold text-[#111827] mb-3">Reviewers</h3>
        <div className="space-y-2 text-sm text-[#6b7280]">
          <p>Upstream Data Owners — upstream-team@ubs.com (SLA: 2 days)</p>
          <p>DWO Steward — steward@ubs.com (SLA: 3 days)</p>
          <p>KDE Reviewer — kde-team@ubs.com (SLA: 3 days)</p>
        </div>
      </div>
    </div>
  );
}
