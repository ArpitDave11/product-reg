import { Field } from '../atoms/Field';
import type { StepFormProps } from './StepProps';

export function Step3({ data, onUpdate, errors, warnings }: StepFormProps) {
  const set = (field: string) => (value: any) => onUpdate({ ...data, [field]: value });
  return (
    <div className="grid grid-cols-2 gap-x-6 gap-y-5">
      <Field label="Source Application URL" value={data.sourceUrl} onChange={set('sourceUrl')} placeholder="https://source-app/" span2 error={errors.sourceUrl} warning={warnings.sourceUrl} />
      <Field label="Environment" value={data.environment} onChange={set('environment')} type="select" options={['PROD', 'DEV', 'UAT']} required error={errors.environment} warning={warnings.environment} />
      <Field label="CID Classification" value={data.cidClassification} onChange={set('cidClassification')} type="select" options={['Green', 'Amber', 'Red']} required error={errors.cidClassification} warning={warnings.cidClassification} />
      <Field label="Input Datasets" value={data.inputDatasets} onChange={set('inputDatasets')} type="textarea" span2 placeholder="List input datasets..." error={errors.inputDatasets} warning={warnings.inputDatasets} />
      <Field label="Storage Location" value={data.storageLocation} onChange={set('storageLocation')} error={errors.storageLocation} />
      <Field label="Own Entitlement" value={data.ownEntitlement} onChange={set('ownEntitlement')} error={errors.ownEntitlement} />
      <Field label="BBS Info" value={data.bbsInfo} onChange={set('bbsInfo')} error={errors.bbsInfo} />
      <Field label="DPAS Alignment" value={data.dpasAlignment} onChange={set('dpasAlignment')} error={errors.dpasAlignment} />
    </div>
  );
}
