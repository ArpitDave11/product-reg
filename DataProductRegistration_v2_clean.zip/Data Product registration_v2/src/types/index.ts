// API Log Entry
export interface ApiLogEntry {
  id: string;
  time: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  endpoint: string;
  status: 'ok' | 'pending' | 'error';
  duration: number | null;
}

// Toast notification
export interface Toast {
  id: string;
  type: 'success' | 'error' | 'loading' | 'warning';
  message: string;
}

// Dataset from catalog
export interface Dataset {
  dataset_title: string;
  name: string;
  description: string | null;
  sourcedescription: string | null;
  aigenerateddescription: string | null;
  ontologyid: string | null;
  ontologyname: string | null;
  cidstaterag: string;
  cidcategory: string;
  cidjustification: string | null;
  disocidcategory: string;
  disocidstaterag: string;
  kde: string | null;
  dqobject: string;
  recommendedusage: string | null;
}

// Datasets response (paginated)
export interface DatasetsResponse {
  data: Dataset[];
  limit: number;
  offset: number;
  count: number;
}

// Health response
export interface HealthResponse {
  status: 'ok' | 'unavailable';
}

// Step data types
export interface StepData {
  [key: string]: any;
}

// Draft state
export interface DraftState {
  exists: boolean;
  registrationId: string | null;
  status: string | null;
  currentStep: number;
  lastSaved: string | null;
  steps: Record<string, StepData> | null;
}

// Save response
export interface SaveResponse {
  success: boolean;
  message: string;
  timestamp: string;
  registrationId: string;
}

// Validation error/warning
export interface ValidationIssue {
  field: string;
  message: string;
}

// Validation response
export interface ValidationResponse {
  valid: boolean;
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
}

// Governance check
export interface GovernanceCheck {
  name: string;
  status: 'passed' | 'warning' | 'failed';
  detail: string;
}

// Governance response
export interface GovernanceResponse {
  overallStatus: 'passed' | 'passed_with_warnings' | 'failed';
  checks: GovernanceCheck[];
}

// Catalog entry
export interface CatalogEntry {
  p_dataset_data: {
    resource_iri: string;
    title: string;
    description: string;
    status: string;
  };
  p_internal: {
    source_system_code: string;
    owner_team: string;
  };
}

// Submission response
export interface SubmissionResponse {
  success: boolean;
  trackingId: string;
  submittedAt: string;
  eta: string;
  catalogEntry: CatalogEntry;
}

// Automated check
export interface AutomatedCheck {
  name: string;
  status: 'passed' | 'running' | 'pending' | 'warning';
  score?: number;
  note?: string;
}

// Checks response
export interface ChecksResponse {
  status: 'running' | 'completed';
  checks: AutomatedCheck[];
}

// Review
export interface Review {
  name: string;
  status: 'Pending' | 'Waiting' | 'Approved' | 'Rejected';
  assignedTo: string;
  sla: string;
}

// Review response
export interface ReviewResponse {
  reviews: Review[];
}

// Mock store
export interface MockStore {
  datasets: Dataset[];
  draft: DraftState | null;
  submission: SubmissionResponse | null;
  checksProgress: AutomatedCheck[];
  reviewStatus: Review[];
  _simulateErrors?: boolean;
  _checkTick?: number;
}

// Step status
export type StepStatus = 'completed' | 'active' | 'upcoming' | 'error';

// App phase
export type AppPhase = 'loading' | 'editing' | 'submitting' | 'submitted';

// Step validation state
export interface StepValidation {
  errors: Record<string, string>;
  warnings: Record<string, string>;
}

// Full app state
export interface AppState {
  phase: AppPhase;
  currentStep: number;
  steps: Record<string, StepData>;
  stepStatuses: Record<string, StepStatus>;
  validation: Record<string, StepValidation>;
  lastSaved: string | null;
  apiHealth: boolean;
  submission: SubmissionResponse | null;
  toasts: Toast[];
  apiLogs: ApiLogEntry[];
  apiLogVisible: boolean;
}
