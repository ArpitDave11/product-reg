export function RegistrationForm() {
  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 text-[#000000]">Register Data Product</h1>
        <p className="text-[#5a5a5a]">Simple, guided registration aligned to WMA governance.</p>
      </div>

      {/* Step 1: Product Identity */}
      <section className="bg-white border border-[#d9d9d9] rounded-2xl p-6">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold mb-1 text-[#000000]">Step 1: Product Identity</h2>
            <p className="text-sm text-[#5a5a5a]">Define core product identity and characteristics.</p>
          </div>
          <span className="px-3 py-1 bg-[#ffe6ea] text-[#e60028] border border-[#ffcccc] rounded-full text-xs font-medium">
            Required
          </span>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Product Name</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              WMA Account
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Product Type</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              Composite Data Product
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Business Domain</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              Account
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Short Description</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              Brief description
            </div>
          </div>
          <div className="space-y-2 col-span-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Long Description</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              Detailed business description
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Business Purpose</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              Purpose & objectives
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Key KPIs / Metrics</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              KPIs linked to measures
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Consumer Personas</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              Data Scientist, Analytics
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Source System</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              SPP
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-6">
          <button className="px-5 py-2 border border-[#000000] rounded-full text-sm font-medium hover:bg-[#f4f4f4] transition-colors">
            Save Draft
          </button>
          <button className="px-5 py-2 bg-[#e60028] text-white rounded-full text-sm font-medium hover:bg-[#c50022] transition-colors">
            Continue
          </button>
        </div>
      </section>

      {/* Step 2: Ownership & Contacts */}
      <section className="bg-white border border-[#d9d9d9] rounded-2xl p-6">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold mb-1 text-[#000000]">Step 2: Ownership & Contacts</h2>
            <p className="text-sm text-[#5a5a5a]">Define ownership, contacts and support information.</p>
          </div>
          <span className="px-3 py-1 bg-[#ffe6ea] text-[#e60028] border border-[#ffcccc] rounded-full text-xs font-medium">
            Required
          </span>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Data Product Owner</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              owner@ubs.com
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Backup Owner</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              backup@ubs.com
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">IT Lead</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              itlead@ubs.com
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Data Steward</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              steward@ubs.com
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Distribution List</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              team-dl@ubs.com
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Support Hours</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              From AppDir
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-6">
          <button className="px-5 py-2 border border-[#000000] rounded-full text-sm font-medium hover:bg-[#f4f4f4] transition-colors">
            Back
          </button>
          <button className="px-5 py-2 bg-[#e60028] text-white rounded-full text-sm font-medium hover:bg-[#c50022] transition-colors">
            Save & Continue
          </button>
        </div>
      </section>

      {/* Step 3: Connect to Source */}
      <section className="bg-white border border-[#d9d9d9] rounded-2xl p-6">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold mb-1 text-[#000000]">Step 3: Connect to Source & Entitlements</h2>
            <p className="text-sm text-[#5a5a5a]">Link source system and configure entitlements.</p>
          </div>
          <span className="px-3 py-1 bg-[#ffe6ea] text-[#e60028] border border-[#ffcccc] rounded-full text-xs font-medium">
            Required
          </span>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Source Application URL</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              https://source-app/
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Environment</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              PROD
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">Storage Location</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              adbfs://container@account
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#5a5a5a] font-medium uppercase tracking-wide">CID Classification</label>
            <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 text-sm bg-white text-[#000000]">
              Red / Green / Amber
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-6">
          <button className="px-5 py-2 border border-[#000000] rounded-full text-sm font-medium hover:bg-[#f4f4f4] transition-colors">
            Back
          </button>
          <button className="px-5 py-2 bg-[#e60028] text-white rounded-full text-sm font-medium hover:bg-[#c50022] transition-colors">
            Save & Continue
          </button>
        </div>
      </section>

      {/* Automated Checks & Human Review */}
      <div className="grid grid-cols-2 gap-6">
        <section className="bg-white border border-[#d9d9d9] rounded-2xl p-6">
          <h3 className="font-bold mb-4 text-[#000000]">Automated Checks</h3>
          <ul className="space-y-2 text-sm text-[#000000] list-disc list-inside">
            <li>Data product qualification</li>
            <li>Ontology score (advisory)</li>
            <li>Upstream source certification</li>
            <li>Entitlement source validation</li>
          </ul>
          <p className="text-xs text-[#5a5a5a] mt-4">Runs after submission.</p>
        </section>

        <section className="bg-white border border-[#d9d9d9] rounded-2xl p-6">
          <h3 className="font-bold mb-4 text-[#000000]">Human Review</h3>
          <ul className="space-y-2 text-sm text-[#000000] list-disc list-inside">
            <li>Upstream Data Owners</li>
            <li>DWO Steward</li>
            <li>KDE Reviewer</li>
          </ul>
          <p className="text-xs text-[#5a5a5a] mt-4">Triggered when checks pass.</p>
        </section>
      </div>

      {/* Governance Checks */}
      <section className="bg-white border border-[#d9d9d9] rounded-2xl p-6">
        <h3 className="font-bold mb-4 text-[#000000]">Governance Checks</h3>
        <ul className="space-y-2 text-sm text-[#000000] list-disc list-inside">
          <li>PII detection</li>
          <li>Retention compliance</li>
          <li>Naming conventions</li>
          <li>Metadata completeness</li>
          <li>Entitlement alignment</li>
        </ul>
        <p className="text-xs text-[#5a5a5a] mt-4">Shown before submission to ensure compliance.</p>
      </section>

      {/* Review Dashboard */}
      <section className="bg-white border border-[#d9d9d9] rounded-2xl p-6">
        <h3 className="font-bold mb-4 text-[#000000]">Review Dashboard</h3>
        <div className="space-y-2">
          <div className="grid grid-cols-3 gap-3 p-3 bg-[#f4f4f4] rounded-xl font-bold text-sm text-[#000000]">
            <div>Reviewer</div>
            <div>Status</div>
            <div>SLA</div>
          </div>
          <div className="grid grid-cols-3 gap-3 p-3 border border-[#d9d9d9] rounded-xl text-sm text-[#000000]">
            <div>Upstream Owners</div>
            <div>
              <span className="px-3 py-1 border border-[#e60028] text-[#e60028] rounded-full text-xs font-medium">
                Pending
              </span>
            </div>
            <div>2 days</div>
          </div>
          <div className="grid grid-cols-3 gap-3 p-3 border border-[#d9d9d9] rounded-xl text-sm text-[#000000]">
            <div>DWO Steward</div>
            <div>
              <span className="px-3 py-1 border border-[#e60028] text-[#e60028] rounded-full text-xs font-medium">
                Waiting
              </span>
            </div>
            <div>3 days</div>
          </div>
          <div className="grid grid-cols-3 gap-3 p-3 border border-[#d9d9d9] rounded-xl text-sm text-[#000000]">
            <div>KDE Reviewer</div>
            <div>
              <span className="px-3 py-1 border border-[#e60028] text-[#e60028] rounded-full text-xs font-medium">
                Waiting
              </span>
            </div>
            <div>3 days</div>
          </div>
        </div>
        <p className="text-xs text-[#5a5a5a] mt-4">Producers can view and nudge reviewers.</p>
      </section>

      {/* Submission Confirmation */}
      <section className="bg-white border border-[#d9d9d9] rounded-2xl p-6">
        <h3 className="font-bold mb-4 text-[#000000]">Submission Confirmation</h3>
        <div className="flex items-center gap-4 p-4 border border-dashed border-[#d9d9d9] rounded-xl bg-[#fffdf5]">
          <div className="w-9 h-9 rounded-full bg-[#ddf6e0] text-[#2e7d32] flex items-center justify-center font-bold text-lg">
            ✓
          </div>
          <div>
            <div className="font-bold text-sm text-[#000000]">Submission Received</div>
            <div className="text-xs text-[#5a5a5a]">Your data product is now in automated checks.</div>
          </div>
        </div>
        <div className="flex flex-wrap gap-3 mt-4">
          <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            Tracking ID: WMA-2026-0142
          </span>
          <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            ETA: 3-5 days
          </span>
        </div>
      </section>

      {/* Certification & Publish */}
      <section className="bg-white border border-[#d9d9d9] rounded-2xl p-6">
        <h3 className="font-bold mb-4 text-[#000000]">Certification & Publish (WMA)</h3>
        <div className="flex flex-wrap gap-3">
          <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            Integrity Check
          </span>
          <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            Entitlement Validation
          </span>
          <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            Register
          </span>
          <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            Publish
          </span>
        </div>
        <p className="text-xs text-[#5a5a5a] mt-4">
          Product becomes discoverable for consumers in WMA Data Catalog.
        </p>
      </section>

      {/* Post-Publish Lifecycle */}
      <section className="bg-[#f4f4f4] border border-[#d9d9d9] rounded-2xl p-6">
        <h3 className="font-bold mb-4 text-[#000000]">Post-Publish Lifecycle</h3>
        <div className="flex flex-wrap gap-3">
          <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            Monitor Quality
          </span>
          <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            Consumer Experience
          </span>
          <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            Version Updates
          </span>
          <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            Change Management
          </span>
          <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            Deprecation
          </span>
        </div>
        <p className="text-xs text-[#5a5a5a] mt-4">
          Lifecycle management per versioning policy and retirement criteria.
        </p>
      </section>
    </div>
  );
}