export function Header() {
  return (
    <header className="flex items-center justify-between border-b-2 border-[#e60028] pb-4 mb-8">
      <div className="flex items-baseline gap-3">
        <span className="text-2xl font-bold text-[#e60028] tracking-wider">UBS</span>
        <span className="text-sm text-[#5a5a5a] uppercase font-medium">WMA Data Platform</span>
      </div>
      <div className="flex gap-3">
        <button className="px-5 py-2 border border-[#000000] rounded-full text-sm font-medium hover:bg-[#f4f4f4] transition-colors">
          Save Draft
        </button>
        <button className="px-5 py-2 bg-[#e60028] text-white rounded-full text-sm font-medium hover:bg-[#c50022] transition-colors">
          Submit
        </button>
      </div>
    </header>
  );
}