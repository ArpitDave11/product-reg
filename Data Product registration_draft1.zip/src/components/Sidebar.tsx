import ubsLogo from 'figma:asset/00ac1239b9b421f7eee8b4e260132b1ac860676a.png';

export function Sidebar() {
  const steps = [
    { id: "1", title: "Product Identity", sub: "Name, type, domain" },
    { id: "2", title: "Ownership", sub: "Contacts & support" },
    { id: "3", title: "Connect", sub: "Source & entitlements" },
    { id: "4", title: "KDE Semantics", sub: "Business metadata" },
    { id: "5", title: "Scope & DQ", sub: "Fitness & quality rules" },
    { id: "6", title: "Data Contract", sub: "Agreement & access" },
    { id: "7", title: "Lineage", sub: "Sources & transformations" },
    { id: "8", title: "Sensitivity", sub: "Policy & compliance" },
    { id: "9", title: "AI Readiness", sub: "Optional analytics" },
    { id: "10", title: "Submit", sub: "Attestations & review" },
  ];

  return (
    <div className="w-80 bg-[#f4f4f4] border-r border-[#d9d9d9] p-6 flex flex-col overflow-y-auto">
      {/* Browser Chrome */}
      <div className="flex gap-2 mb-8">
        <div className="w-3 h-3 rounded-full bg-[#ed6a5e]"></div>
        <div className="w-3 h-3 rounded-full bg-[#f4bf4f]"></div>
        <div className="w-3 h-3 rounded-full bg-[#61c554]"></div>
      </div>

      {/* UBS Logo */}
      <div className="flex items-center mb-12">
        <img src={ubsLogo} alt="UBS" className="h-12" />
        <span className="flex flex-col text-[#e60028]">
          <span className="text-xl font-semibold">Data</span>
          <span className="text-sm font-semibold">Product Registration</span>
        </span>
      </div>

      {/* Registration Steps */}
      <div className="mb-6">
        <h3 className="text-xs text-[#5a5a5a] uppercase mb-3 font-medium tracking-wide">Registration Steps</h3>
        <ol className="space-y-3">
          {steps.map((step, index) => (
            <li
              key={step.id}
              className={`flex gap-3 p-3 border rounded-xl bg-white ${
                index === 1
                  ? 'border-[#e60028] shadow-sm'
                  : 'border-dashed border-[#d9d9d9]'
              }`}
            >
              <div className="w-7 h-7 rounded-full bg-[#e60028] text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                {step.id}
              </div>
              <div className="flex flex-col gap-1">
                <div className="font-medium text-sm text-[#000000]">{step.title}</div>
                <div className="text-xs text-[#5a5a5a]">{step.sub}</div>
              </div>
            </li>
          ))}
        </ol>
      </div>

      {/* Status */}
      <div className="mb-6">
        <h3 className="text-xs text-[#5a5a5a] uppercase mb-3 font-medium tracking-wide">Status</h3>
        <div className="space-y-2">
          <div className="px-3 py-2 rounded-full border border-[#e60028] text-[#e60028] text-xs text-center bg-white font-medium">
            In Progress
          </div>
          <div className="text-xs text-[#5a5a5a] text-center">Step 2 of 10</div>
        </div>
      </div>

      {/* Optional */}
      <div>
        <h3 className="text-xs text-[#5a5a5a] uppercase mb-3 font-medium tracking-wide">Optional</h3>
        <div className="border border-dashed border-[#d9d9d9] rounded-xl p-3 bg-white">
          <div className="font-medium text-sm mb-1 text-[#000000]">Enterprise Catalog</div>
          <div className="text-xs text-[#5a5a5a] mb-3">Sync after WMA registration</div>
          <label className="flex items-center gap-2 cursor-pointer">
            <div className="relative">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-9 h-5 bg-[#d9d9d9] rounded-full peer-checked:bg-[#e60028] transition-colors"></div>
              <div className="absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full transition-transform peer-checked:translate-x-4 shadow-sm"></div>
            </div>
            <span className="text-xs text-[#5a5a5a]">Register after publish</span>
          </label>
        </div>
      </div>
    </div>
  );
}