import { ChevronRight, Plus } from 'lucide-react';

export function CardsSection() {
  const cards = [
    { number: '4340', balance: '172.60', type: 'credit' },
    { number: '3650', balance: '50.48', type: 'credit' },
    { number: '2564', balance: '74.20', type: 'debit' },
  ];

  return (
    <section>
      <h2 className="text-xl text-gray-600 mb-4">Cards</h2>
      <div className="space-y-3">
        {cards.map((card, index) => (
          <div
            key={index}
            className="bg-white rounded-2xl p-6 flex items-center justify-between hover:shadow-md transition-shadow cursor-pointer"
          >
            <div className="flex items-center gap-4">
              <div className="w-8 h-6 bg-black rounded flex items-center justify-center">
                <div className="w-5 h-4 bg-white rounded-sm"></div>
              </div>
              <span className="text-xl">{card.number}</span>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-gray-600 text-sm">CHF</span>
              <span className="text-xl">{card.balance}</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </div>
          </div>
        ))}
        
        {/* Add Card Button */}
        <button className="w-full bg-white rounded-2xl p-6 flex items-center justify-center hover:shadow-md transition-shadow">
          <Plus className="w-6 h-6 text-gray-400" />
        </button>
      </div>
    </section>
  );
}
