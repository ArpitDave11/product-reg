import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { RegistrationForm } from './components/RegistrationForm';

export default function App() {
  return (
    <div className="flex min-h-screen bg-white">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1">
        <div className="max-w-6xl mx-auto p-8">
          <Header />
          <RegistrationForm />
        </div>
      </div>
    </div>
  );
}