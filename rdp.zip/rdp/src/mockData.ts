import { DataProduct } from './types';

export function generateId(): string {
  return crypto.randomUUID();
}

export function generateIri(title: string): string {
  const slug = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
  return `urn:ubs:data-product:${slug}`;
}

export const initialProducts: DataProduct[] = [
  {
    resource_iri: 'urn:ubs:data-product:client-portfolio-holdings',
    resource_id: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890',
    title: 'Client Portfolio Holdings',
    description: 'Consolidated view of client portfolio holdings across all asset classes including equities, fixed income, derivatives, and alternative investments.',
    status: 'published',
    source_system_code: 'WMS-CORE',
    owner: 'maria.schmidt@ubs.com',
    created_at: '2025-06-15T09:30:00Z',
    updated_at: '2025-11-20T14:22:00Z',
  },
  {
    resource_iri: 'urn:ubs:data-product:transaction-history',
    resource_id: 'b2c3d4e5-f6a7-8901-bcde-f12345678901',
    title: 'Transaction History',
    description: 'Complete transaction history for all client accounts including trades, transfers, deposits, and withdrawals with full audit trail.',
    status: 'published',
    source_system_code: 'TRX-ENGINE',
    owner: 'james.chen@ubs.com',
    created_at: '2025-04-10T11:00:00Z',
    updated_at: '2025-12-01T08:45:00Z',
  },
  {
    resource_iri: 'urn:ubs:data-product:risk-exposure-metrics',
    resource_id: 'c3d4e5f6-a7b8-9012-cdef-123456789012',
    title: 'Risk Exposure Metrics',
    description: 'Real-time risk exposure calculations including VaR, stress testing results, and concentration risk metrics across all business lines.',
    status: 'published',
    source_system_code: 'RISK-CALC',
    owner: 'anna.mueller@ubs.com',
    created_at: '2025-03-22T15:45:00Z',
    updated_at: '2025-10-15T16:30:00Z',
  },
  {
    resource_iri: 'urn:ubs:data-product:kyc-compliance-data',
    resource_id: 'd4e5f6a7-b8c9-0123-defa-234567890123',
    title: 'KYC Compliance Data',
    description: 'Know Your Customer compliance dataset containing client verification status, document records, and periodic review schedules.',
    status: 'draft',
    source_system_code: 'COMPLY-HUB',
    owner: 'peter.weber@ubs.com',
    created_at: '2025-09-01T10:15:00Z',
    updated_at: '2025-12-10T09:00:00Z',
  },
  {
    resource_iri: 'urn:ubs:data-product:market-data-feed',
    resource_id: 'e5f6a7b8-c9d0-1234-efab-345678901234',
    title: 'Market Data Feed',
    description: 'Aggregated market data feed covering equities, FX, commodities, and fixed income instruments from major global exchanges.',
    status: 'published',
    source_system_code: 'MKT-STREAM',
    owner: 'sophie.laurent@ubs.com',
    created_at: '2025-01-18T08:00:00Z',
    updated_at: '2025-11-28T12:10:00Z',
  },
  {
    resource_iri: 'urn:ubs:data-product:client-segmentation',
    resource_id: 'f6a7b8c9-d0e1-2345-fabc-456789012345',
    title: 'Client Segmentation',
    description: 'Client segmentation model outputs including wealth tier classification, behavioral segments, and product affinity scores.',
    status: 'draft',
    source_system_code: 'ANALYTICS',
    owner: 'luca.rossi@ubs.com',
    created_at: '2025-08-05T13:20:00Z',
    updated_at: '2025-12-05T17:55:00Z',
  },
  {
    resource_iri: 'urn:ubs:data-product:regulatory-reporting',
    resource_id: 'a7b8c9d0-e1f2-3456-abcd-567890123456',
    title: 'Regulatory Reporting Dataset',
    description: 'Pre-aggregated regulatory reporting data for MiFID II, FINMA, and cross-border compliance requirements.',
    status: 'retired',
    source_system_code: 'REG-RPT',
    owner: 'elena.kovacs@ubs.com',
    created_at: '2024-11-30T07:30:00Z',
    updated_at: '2025-09-15T10:00:00Z',
  },
  {
    resource_iri: 'urn:ubs:data-product:fx-pricing-engine',
    resource_id: 'b8c9d0e1-f2a3-4567-bcde-678901234567',
    title: 'FX Pricing Engine Output',
    description: 'Foreign exchange pricing engine output including spot rates, forward points, and implied volatility surfaces for major currency pairs.',
    status: 'published',
    source_system_code: 'FX-ENGINE',
    owner: 'thomas.hartmann@ubs.com',
    created_at: '2025-02-14T09:45:00Z',
    updated_at: '2025-11-30T15:20:00Z',
  },
  {
    resource_iri: 'urn:ubs:data-product:esg-scoring',
    resource_id: 'c9d0e1f2-a3b4-5678-cdef-789012345678',
    title: 'ESG Scoring Dataset',
    description: 'Environmental, Social, and Governance scoring data for investment universe covering 5000+ global issuers with quarterly updates.',
    status: 'draft',
    source_system_code: 'ESG-HUB',
    owner: 'maria.schmidt@ubs.com',
    created_at: '2025-10-20T11:30:00Z',
    updated_at: '2025-12-08T14:45:00Z',
  },
];
