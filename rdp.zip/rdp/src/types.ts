export type StatusType = 'draft' | 'published' | 'retired';

export type ViewType = 'list' | 'detail' | 'create' | 'edit';

export type ToastType = 'success' | 'error' | 'info';

export interface DataProduct {
  resource_iri: string;
  resource_id: string;
  title: string;
  description: string;
  status: StatusType;
  source_system_code: string;
  owner: string;
  created_at: string;
  updated_at: string;
}

export interface DataProductCreate {
  title: string;
  description?: string;
  status?: StatusType;
  source_system_code: string;
  owner: string;
}

export interface DataProductUpdate {
  description?: string;
  status?: StatusType;
  source_system_code?: string;
  owner?: string;
}

export interface Toast {
  id: string;
  type: ToastType;
  message: string;
}
