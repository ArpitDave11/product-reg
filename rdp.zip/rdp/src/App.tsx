import { useState, useCallback } from 'react'
import { DataProduct, DataProductCreate, DataProductUpdate, ViewType, Toast as ToastT } from './types'
import { initialProducts, generateId, generateIri } from './mockData'
import Sidebar from './components/Sidebar'
import DataProductList from './components/DataProductList'
import DataProductDetail from './components/DataProductDetail'
import DataProductForm from './components/DataProductForm'
import DeleteModal from './components/DeleteModal'
import Toast from './components/Toast'

export default function App() {
  const [products, setProducts] = useState<DataProduct[]>(initialProducts)
  const [currentView, setCurrentView] = useState<ViewType>('list')
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null)
  const [toasts, setToasts] = useState<ToastT[]>([])
  const [deleteTarget, setDeleteTarget] = useState<DataProduct | null>(null)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  const addToast = useCallback((type: ToastT['type'], message: string) => {
    const id = generateId()
    setToasts(prev => [...prev, { id, type, message }])
  }, [])

  const dismissToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id))
  }, [])

  const navigate = useCallback((view: ViewType, productId?: string) => {
    setCurrentView(view)
    setSelectedProductId(productId ?? null)
  }, [])

  const handleCreate = useCallback((data: DataProductCreate) => {
    const now = new Date().toISOString()
    const newProduct: DataProduct = {
      resource_id: generateId(),
      resource_iri: generateIri(data.title),
      title: data.title,
      description: data.description ?? '',
      status: data.status ?? 'draft',
      source_system_code: data.source_system_code,
      owner: data.owner,
      created_at: now,
      updated_at: now,
    }
    setProducts(prev => [newProduct, ...prev])
    navigate('detail', newProduct.resource_id)
    addToast('success', `Data product "${newProduct.title}" created successfully`)
  }, [navigate, addToast])

  const handleUpdate = useCallback((id: string, data: DataProductUpdate) => {
    setProducts(prev =>
      prev.map(p => {
        if (p.resource_id !== id) return p
        return {
          ...p,
          ...data,
          updated_at: new Date().toISOString(),
        }
      })
    )
    navigate('detail', id)
    addToast('success', 'Data product updated successfully')
  }, [navigate, addToast])

  const handleDelete = useCallback((id: string) => {
    setProducts(prev =>
      prev.map(p => {
        if (p.resource_id !== id) return p
        return { ...p, status: 'retired' as const, updated_at: new Date().toISOString() }
      })
    )
    setDeleteTarget(null)
    navigate('list')
    addToast('info', 'Data product retired successfully')
  }, [navigate, addToast])

  const selectedProduct = products.find(p => p.resource_id === selectedProductId) ?? null

  const renderView = () => {
    switch (currentView) {
      case 'list':
        return (
          <DataProductList
            products={products}
            onNavigate={navigate}
          />
        )
      case 'detail':
        if (!selectedProduct) {
          navigate('list')
          return null
        }
        return (
          <DataProductDetail
            product={selectedProduct}
            onNavigate={navigate}
            onDelete={(product) => setDeleteTarget(product)}
          />
        )
      case 'create':
        return (
          <DataProductForm
            mode="create"
            onSubmit={(data) => handleCreate(data as DataProductCreate)}
            onCancel={() => navigate('list')}
          />
        )
      case 'edit':
        if (!selectedProduct) {
          navigate('list')
          return null
        }
        return (
          <DataProductForm
            mode="edit"
            product={selectedProduct}
            onSubmit={(data) => handleUpdate(selectedProduct.resource_id, data as DataProductUpdate)}
            onCancel={() => navigate('detail', selectedProduct.resource_id)}
          />
        )
      default:
        return null
    }
  }

  return (
    <div className="app-layout">
      <Sidebar
        currentView={currentView}
        onNavigate={navigate}
        isCollapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(c => !c)}
      />
      <main className="main-content">
        {renderView()}
      </main>

      {deleteTarget && (
        <DeleteModal
          product={deleteTarget}
          onConfirm={() => handleDelete(deleteTarget.resource_id)}
          onCancel={() => setDeleteTarget(null)}
        />
      )}

      <Toast toasts={toasts} onDismiss={dismissToast} />
    </div>
  )
}
