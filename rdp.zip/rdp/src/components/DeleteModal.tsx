import { DataProduct } from '../types'

interface DeleteModalProps {
  product: DataProduct
  onConfirm: () => void
  onCancel: () => void
}

export default function DeleteModal({ product, onConfirm, onCancel }: DeleteModalProps) {
  return (
    <div className="modal-overlay" onClick={onCancel}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-icon">
          <span style={{ fontSize: '24px' }}>⚠️</span>
        </div>
        <h3 className="modal-title">Retire Data Product</h3>
        <p className="modal-text">
          Are you sure you want to retire <strong>"{product.title}"</strong>?
          <br /><br />
          This will set the status to <em>retired</em> (soft delete). The data product will remain visible but marked as inactive.
        </p>
        <div className="modal-actions">
          <button className="btn btn-secondary" onClick={onCancel}>
            Cancel
          </button>
          <button className="btn btn-primary" onClick={onConfirm} style={{ background: '#E60000' }}>
            🗑️ Retire
          </button>
        </div>
      </div>
    </div>
  )
}
