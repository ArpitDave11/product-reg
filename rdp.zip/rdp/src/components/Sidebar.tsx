import { useState, CSSProperties } from 'react'
import { ViewType } from '../types'

const UBS_COLORS = {
  red: '#E60000',
  bordeauxI: '#BD000C',
  black: '#000000',
  white: '#FFFFFF',
  grayI: '#CCCABC',
  grayIII: '#8E8D83',
  grayV: '#5A5D5C',
  pastelI: '#ECEBE4',
  pastelII: '#F5F0E1',
  neutral50: '#FAFAFA',
  neutral200: '#E5E5E5',
}

interface SidebarProps {
  currentView: ViewType
  onNavigate: (view: ViewType) => void
  isCollapsed: boolean
  onToggleCollapse: () => void
}

interface NavItem {
  id: ViewType
  label: string
  icon: string
}

const navItems: NavItem[] = [
  { id: 'list', label: 'Data Products', icon: '📊' },
  { id: 'create', label: 'Register New', icon: '➕' },
]

export default function Sidebar({ currentView, onNavigate, isCollapsed, onToggleCollapse }: SidebarProps) {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null)
  const [tooltipItem, setTooltipItem] = useState<string | null>(null)

  const styles: Record<string, CSSProperties> = {
    wrapper: {
      position: 'sticky',
      top: '16px',
      height: 'calc(100vh - 32px)',
      margin: '16px 0 16px 16px',
      display: 'flex',
      alignItems: 'flex-start',
    },
    sidebar: {
      width: isCollapsed ? '56px' : '240px',
      minWidth: isCollapsed ? '56px' : '240px',
      height: '100%',
      background: UBS_COLORS.neutral50,
      display: 'flex',
      flexDirection: 'column',
      borderRadius: '12px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
      border: `1px solid ${UBS_COLORS.neutral200}`,
      overflow: 'hidden',
      transition: 'width 0.3s cubic-bezier(0.4, 0, 0.2, 1), min-width 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    },
    logoContainer: {
      padding: isCollapsed ? '16px 12px' : '20px 16px',
      borderBottom: `1px solid ${UBS_COLORS.neutral200}`,
      background: UBS_COLORS.white,
      display: isCollapsed ? 'none' : 'flex',
      justifyContent: 'flex-start',
      alignItems: 'center',
      minHeight: '64px',
      gap: '12px',
    },
    logoIcon: {
      width: '36px',
      height: '36px',
      borderRadius: '8px',
      background: UBS_COLORS.red,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 2px 8px rgba(230, 0, 0, 0.2)',
      color: UBS_COLORS.white,
      fontSize: '16px',
      fontWeight: 600,
      flexShrink: 0,
    },
    logoText: {
      fontSize: '15px',
      fontWeight: 600,
      color: UBS_COLORS.black,
      letterSpacing: '-0.01em',
      lineHeight: 1.2,
      whiteSpace: 'nowrap',
    },
    logoSub: {
      fontSize: '11px',
      fontWeight: 300,
      color: UBS_COLORS.grayIII,
      letterSpacing: '-0.01em',
    },
    nav: {
      flex: 1,
      padding: '12px 8px',
      display: 'flex',
      flexDirection: 'column',
      gap: '4px',
    },
    footer: {
      padding: isCollapsed ? '12px 8px' : '16px',
      borderTop: `1px solid ${UBS_COLORS.neutral200}`,
      background: UBS_COLORS.pastelI,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '4px',
    },
    footerText: {
      fontSize: '10px',
      fontWeight: 300,
      color: UBS_COLORS.grayIII,
      textAlign: 'center' as const,
      lineHeight: 1.4,
    },
    toggleBtn: {
      position: 'absolute',
      top: '20px',
      right: '-14px',
      width: '28px',
      height: '28px',
      borderRadius: '8px',
      background: UBS_COLORS.white,
      border: `1px solid ${UBS_COLORS.neutral200}`,
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.08)',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '12px',
      color: UBS_COLORS.grayV,
      transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
      zIndex: 10,
    },
  }

  const getNavBtnStyle = (id: string): CSSProperties => {
    const isActive = currentView === id || (id === 'list' && (currentView === 'detail' || currentView === 'edit'))
    const isHovered = hoveredItem === id

    return {
      display: 'flex',
      alignItems: 'center',
      gap: '12px',
      width: '100%',
      padding: isCollapsed ? '10px' : '12px 14px',
      cursor: 'pointer',
      color: isActive ? UBS_COLORS.white : UBS_COLORS.black,
      backgroundColor: isActive
        ? UBS_COLORS.red
        : isHovered
          ? UBS_COLORS.pastelII
          : 'transparent',
      border: 'none',
      borderRadius: '8px',
      fontSize: '14px',
      fontWeight: isActive ? 400 : 300,
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
      textAlign: 'left',
      position: 'relative',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    }
  }

  const tooltipStyle: CSSProperties = {
    position: 'absolute',
    left: '100%',
    marginLeft: '12px',
    padding: '8px 12px',
    background: UBS_COLORS.black,
    color: UBS_COLORS.white,
    fontSize: '12px',
    fontWeight: 300,
    letterSpacing: '-0.01em',
    borderRadius: '8px',
    whiteSpace: 'nowrap',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
    zIndex: 1000,
  }

  return (
    <div style={styles.wrapper}>
      <div style={{ position: 'relative' }}>
        <nav style={styles.sidebar}>
          <div style={styles.logoContainer}>
            <div style={styles.logoIcon}>DP</div>
            <div>
              <div style={styles.logoText}>Data Products</div>
              <div style={styles.logoSub}>Registration Portal</div>
            </div>
          </div>

          <div style={styles.nav}>
            {navItems.map(item => (
              <button
                key={item.id}
                style={getNavBtnStyle(item.id)}
                onClick={() => onNavigate(item.id)}
                onMouseEnter={() => {
                  setHoveredItem(item.id)
                  if (isCollapsed) setTooltipItem(item.id)
                }}
                onMouseLeave={() => {
                  setHoveredItem(null)
                  setTooltipItem(null)
                }}
              >
                <span style={{ fontSize: '16px', flexShrink: 0 }}>{item.icon}</span>
                {!isCollapsed && <span>{item.label}</span>}
                {isCollapsed && tooltipItem === item.id && (
                  <div style={tooltipStyle}>{item.label}</div>
                )}
              </button>
            ))}
          </div>

          <div style={styles.footer}>
            {!isCollapsed && (
              <>
                <div style={styles.footerText}>Data Product Registration</div>
                <div style={styles.footerText}>&copy; 2025 UBS</div>
              </>
            )}
            {isCollapsed && (
              <div style={{ fontSize: '10px', color: UBS_COLORS.grayIII }}>UBS</div>
            )}
          </div>
        </nav>

        <button
          style={styles.toggleBtn}
          onClick={onToggleCollapse}
          title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isCollapsed ? '▶' : '◀'}
        </button>
      </div>
    </div>
  )
}
