import { useState } from 'react'
import { DataProduct, ViewType, StatusType } from '../types'

interface DataProductDetailProps {
  product: DataProduct
  onNavigate: (view: ViewType, productId?: string) => void
  onDelete: (product: DataProduct) => void
}

function StatusBadge({ status }: { status: StatusType }) {
  return (
    <span className={`badge badge-${status}`}>
      <span className="badge-dot" />
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  )
}

function formatDateTime(iso: string): string {
  const d = new Date(iso)
  return d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }) + ' at ' + d.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
  })
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <button className="copy-btn" onClick={handleCopy} title="Copy to clipboard">
      {copied ? '✓' : '📋'}
    </button>
  )
}

export default function DataProductDetail({ product, onNavigate, onDelete }: DataProductDetailProps) {
  return (
    <div>
      <button className="btn btn-ghost" onClick={() => onNavigate('list')} style={{ marginBottom: '16px' }}>
        ← Back to list
      </button>

      <div className="card">
        <div className="detail-header">
          <div className="detail-title-group">
            <h1 className="detail-title">{product.title}</h1>
            <StatusBadge status={product.status} />
          </div>
          <div className="detail-actions">
            <button className="btn btn-secondary" onClick={() => onNavigate('edit', product.resource_id)}>
              ✏️ Edit
            </button>
            {product.status !== 'retired' && (
              <button className="btn btn-danger" onClick={() => onDelete(product)}>
                🗑️ Retire
              </button>
            )}
          </div>
        </div>

        <div className="info-grid">
          <div className="info-item">
            <div className="info-label">Resource IRI</div>
            <div className="info-value info-value-with-copy">
              <span style={{ fontFamily: 'monospace', fontSize: '13px' }}>{product.resource_iri}</span>
              <CopyButton text={product.resource_iri} />
            </div>
          </div>

          <div className="info-item">
            <div className="info-label">Resource ID</div>
            <div className="info-value info-value-with-copy">
              <span style={{ fontFamily: 'monospace', fontSize: '13px' }}>{product.resource_id}</span>
              <CopyButton text={product.resource_id} />
            </div>
          </div>

          <div className="info-item">
            <div className="info-label">Owner</div>
            <div className="info-value">{product.owner}</div>
          </div>

          <div className="info-item">
            <div className="info-label">Source System Code</div>
            <div className="info-value">
              <code style={{ fontSize: '13px', background: '#f4f4f4', padding: '2px 8px', borderRadius: '4px' }}>
                {product.source_system_code}
              </code>
            </div>
          </div>

          <div className="info-item full-width">
            <div className="info-label">Description</div>
            <div className="info-value">{product.description || 'No description provided'}</div>
          </div>

          <div className="info-item">
            <div className="info-label">Created</div>
            <div className="info-value">{formatDateTime(product.created_at)}</div>
          </div>

          <div className="info-item">
            <div className="info-label">Last Updated</div>
            <div className="info-value">{formatDateTime(product.updated_at)}</div>
          </div>
        </div>
      </div>
    </div>
  )
}
