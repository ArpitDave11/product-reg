import { useState, FormEvent } from 'react'
import { DataProduct, DataProductCreate, DataProductUpdate, StatusType } from '../types'

interface DataProductFormProps {
  mode: 'create' | 'edit'
  product?: DataProduct
  onSubmit: (data: DataProductCreate | DataProductUpdate) => void
  onCancel: () => void
}

interface FormErrors {
  title?: string
  owner?: string
  source_system_code?: string
  description?: string
}

const EMAIL_PATTERN = /^[a-zA-Z0-9._%+-]+@ubs\.com$/

export default function DataProductForm({ mode, product, onSubmit, onCancel }: DataProductFormProps) {
  const [title, setTitle] = useState(product?.title ?? '')
  const [description, setDescription] = useState(product?.description ?? '')
  const [status, setStatus] = useState<StatusType>(product?.status ?? 'draft')
  const [sourceSystemCode, setSourceSystemCode] = useState(product?.source_system_code ?? '')
  const [owner, setOwner] = useState(product?.owner ?? '')
  const [errors, setErrors] = useState<FormErrors>({})
  const [touched, setTouched] = useState<Record<string, boolean>>({})

  const validate = (): FormErrors => {
    const errs: FormErrors = {}

    if (mode === 'create') {
      if (!title.trim()) {
        errs.title = 'Title is required'
      } else if (title.trim().length < 3) {
        errs.title = 'Title must be at least 3 characters'
      }
    }

    if (!owner.trim()) {
      errs.owner = 'Owner is required'
    } else if (!EMAIL_PATTERN.test(owner.trim())) {
      errs.owner = 'Owner must be a valid @ubs.com email'
    }

    if (mode === 'create' && !sourceSystemCode.trim()) {
      errs.source_system_code = 'Source system code is required'
    } else if (sourceSystemCode.trim() && sourceSystemCode.trim().length > 20) {
      errs.source_system_code = 'Source system code must be 20 characters or less'
    }

    if (description.length > 1000) {
      errs.description = 'Description must be 1000 characters or less'
    }

    return errs
  }

  const handleBlur = (field: string) => {
    setTouched(prev => ({ ...prev, [field]: true }))
    setErrors(validate())
  }

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    const errs = validate()
    setErrors(errs)
    setTouched({ title: true, owner: true, source_system_code: true, description: true })

    if (Object.keys(errs).length > 0) return

    if (mode === 'create') {
      const data: DataProductCreate = {
        title: title.trim(),
        description: description.trim() || undefined,
        status,
        source_system_code: sourceSystemCode.trim(),
        owner: owner.trim(),
      }
      onSubmit(data)
    } else {
      const data: DataProductUpdate = {
        description: description.trim(),
        status,
        source_system_code: sourceSystemCode.trim() || undefined,
        owner: owner.trim(),
      }
      onSubmit(data)
    }
  }

  return (
    <div>
      <button className="btn btn-ghost" onClick={onCancel} style={{ marginBottom: '16px' }}>
        ← {mode === 'create' ? 'Back to list' : 'Back to detail'}
      </button>

      <div className="card form-card">
        <h2 className="form-title">
          {mode === 'create' ? 'Register New Data Product' : `Edit: ${product?.title}`}
        </h2>

        <form onSubmit={handleSubmit} noValidate>
          {/* Title */}
          <div className="form-group">
            <label className="form-label">Title {mode === 'create' && '*'}</label>
            {mode === 'create' ? (
              <>
                <input
                  className="input-premium"
                  type="text"
                  placeholder="e.g. Client Portfolio Holdings"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  onBlur={() => handleBlur('title')}
                />
                {touched.title && errors.title && (
                  <div className="form-error">{errors.title}</div>
                )}
              </>
            ) : (
              <input
                className="input-premium"
                type="text"
                value={title}
                readOnly
              />
            )}
            {mode === 'edit' && (
              <div className="form-hint">Title cannot be changed after creation</div>
            )}
          </div>

          {/* Owner */}
          <div className="form-group">
            <label className="form-label">Owner *</label>
            <input
              className="input-premium"
              type="email"
              placeholder="firstname.lastname@ubs.com"
              value={owner}
              onChange={e => setOwner(e.target.value)}
              onBlur={() => handleBlur('owner')}
            />
            {touched.owner && errors.owner && (
              <div className="form-error">{errors.owner}</div>
            )}
            <div className="form-hint">Must be a valid @ubs.com email address</div>
          </div>

          {/* Source System Code */}
          <div className="form-group">
            <label className="form-label">Source System Code {mode === 'create' && '*'}</label>
            <input
              className="input-premium"
              type="text"
              placeholder="e.g. WMS-CORE"
              value={sourceSystemCode}
              onChange={e => setSourceSystemCode(e.target.value.toUpperCase())}
              onBlur={() => handleBlur('source_system_code')}
              maxLength={20}
            />
            {touched.source_system_code && errors.source_system_code && (
              <div className="form-error">{errors.source_system_code}</div>
            )}
            <div className="form-hint">Max 20 characters, uppercase recommended</div>
          </div>

          {/* Description */}
          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              className="input-premium"
              placeholder="Describe the data product..."
              value={description}
              onChange={e => setDescription(e.target.value)}
              onBlur={() => handleBlur('description')}
              maxLength={1000}
            />
            <div className={`char-counter ${description.length > 900 ? 'near-limit' : ''}`}>
              {description.length}/1000
            </div>
            {touched.description && errors.description && (
              <div className="form-error">{errors.description}</div>
            )}
          </div>

          {/* Status */}
          <div className="form-group">
            <label className="form-label">Status</label>
            <select
              className="input-premium"
              value={status}
              onChange={e => setStatus(e.target.value as StatusType)}
            >
              <option value="draft">Draft</option>
              <option value="published">Published</option>
              <option value="retired">Retired</option>
            </select>
          </div>

          {/* Actions */}
          <div className="form-actions">
            <button type="submit" className="btn btn-primary">
              {mode === 'create' ? '✓ Register Product' : '✓ Save Changes'}
            </button>
            <button type="button" className="btn btn-secondary" onClick={onCancel}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
