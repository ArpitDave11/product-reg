import { useEffect } from 'react'
import { Toast as ToastT } from '../types'

interface ToastProps {
  toasts: ToastT[]
  onDismiss: (id: string) => void
}

export default function Toast({ toasts, onDismiss }: ToastProps) {
  return (
    <div className="toast-container">
      {toasts.map(toast => (
        <ToastItem key={toast.id} toast={toast} onDismiss={onDismiss} />
      ))}
    </div>
  )
}

function ToastItem({ toast, onDismiss }: { toast: ToastT; onDismiss: (id: string) => void }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss(toast.id)
    }, 4000)
    return () => clearTimeout(timer)
  }, [toast.id, onDismiss])

  const icon = toast.type === 'success' ? '✓' : toast.type === 'error' ? '✕' : 'ℹ'

  return (
    <div className={`toast toast-${toast.type}`}>
      <span style={{ fontSize: '16px', fontWeight: 600 }}>{icon}</span>
      <span className="toast-message">{toast.message}</span>
      <button className="toast-dismiss" onClick={() => onDismiss(toast.id)}>
        ✕
      </button>
    </div>
  )
}
