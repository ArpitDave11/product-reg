import { useState, useMemo } from 'react'
import { DataProduct, ViewType, StatusType } from '../types'

interface DataProductListProps {
  products: DataProduct[]
  onNavigate: (view: ViewType, productId?: string) => void
}

function StatusBadge({ status }: { status: StatusType }) {
  return (
    <span className={`badge badge-${status}`}>
      <span className="badge-dot" />
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  )
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
}

export default function DataProductList({ products, onNavigate }: DataProductListProps) {
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [ownerSearch, setOwnerSearch] = useState('')
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)

  const filtered = useMemo(() => {
    return products.filter(p => {
      if (statusFilter !== 'all' && p.status !== statusFilter) return false
      if (ownerSearch && !p.owner.toLowerCase().includes(ownerSearch.toLowerCase())) return false
      return true
    })
  }, [products, statusFilter, ownerSearch])

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const safeP = Math.min(page, totalPages)
  const paginated = filtered.slice((safeP - 1) * pageSize, safeP * pageSize)

  const handlePageSizeChange = (newSize: number) => {
    setPageSize(newSize)
    setPage(1)
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Data Products</h1>
          <p className="page-subtitle">{filtered.length} product{filtered.length !== 1 ? 's' : ''} registered</p>
        </div>
        <button className="btn btn-primary" onClick={() => onNavigate('create')}>
          ➕ Register New
        </button>
      </div>

      <div className="filters-bar">
        <select
          className="filter-select"
          value={statusFilter}
          onChange={e => { setStatusFilter(e.target.value); setPage(1) }}
        >
          <option value="all">All Statuses</option>
          <option value="draft">Draft</option>
          <option value="published">Published</option>
          <option value="retired">Retired</option>
        </select>
        <input
          className="filter-input"
          type="text"
          placeholder="Search by owner..."
          value={ownerSearch}
          onChange={e => { setOwnerSearch(e.target.value); setPage(1) }}
        />
        {(statusFilter !== 'all' || ownerSearch) && (
          <button
            className="btn btn-ghost btn-sm"
            onClick={() => { setStatusFilter('all'); setOwnerSearch(''); setPage(1) }}
          >
            Clear filters
          </button>
        )}
      </div>

      {paginated.length === 0 ? (
        <div className="card">
          <div className="empty-state">
            <div className="empty-state-icon">📋</div>
            <div className="empty-state-text">No data products found</div>
            <div className="empty-state-sub">Try adjusting your filters or register a new product</div>
          </div>
        </div>
      ) : (
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Status</th>
                <th>Owner</th>
                <th>Source System</th>
                <th>Updated</th>
                <th style={{ width: '120px' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginated.map(product => (
                <tr key={product.resource_id}>
                  <td className="title-cell">{product.title}</td>
                  <td><StatusBadge status={product.status} /></td>
                  <td>{product.owner}</td>
                  <td><code style={{ fontSize: '12px', background: '#f4f4f4', padding: '2px 6px', borderRadius: '4px' }}>{product.source_system_code}</code></td>
                  <td style={{ whiteSpace: 'nowrap' }}>{formatDate(product.updated_at)}</td>
                  <td>
                    <div style={{ display: 'flex', gap: '4px' }}>
                      <button
                        className="btn btn-ghost btn-sm"
                        onClick={() => onNavigate('detail', product.resource_id)}
                      >
                        View
                      </button>
                      <button
                        className="btn btn-ghost btn-sm"
                        onClick={() => onNavigate('edit', product.resource_id)}
                      >
                        Edit
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="pagination">
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span>Show</span>
              <select
                className="page-size-select"
                value={pageSize}
                onChange={e => handlePageSizeChange(Number(e.target.value))}
              >
                <option value={10}>10</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
              </select>
              <span>per page</span>
            </div>

            <div className="pagination-controls">
              <button
                className="pagination-btn"
                disabled={safeP <= 1}
                onClick={() => setPage(safeP - 1)}
              >
                ← Prev
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
                <button
                  key={p}
                  className={`pagination-btn ${p === safeP ? 'active' : ''}`}
                  onClick={() => setPage(p)}
                >
                  {p}
                </button>
              ))}
              <button
                className="pagination-btn"
                disabled={safeP >= totalPages}
                onClick={() => setPage(safeP + 1)}
              >
                Next →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
