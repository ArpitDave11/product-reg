import { useEffect, useRef } from 'react';
import { mockSaveDraft } from '../lib/mockApi';
import type { MockStore, StepData, Logger } from '../lib/mockApi';

interface UseAutoSaveOptions {
  store: MockStore;
  logger: Logger;
  currentStep: number;
  stepData: Record<string, StepData>;
  addToast: (toast: { type: 'success' | 'error' | 'loading' | 'warning'; message: string }) => void;
}

/**
 * O-02: useAutoSave — Debounced auto-save. Saves the current step data
 * to the mock API 2 seconds after the last field change.
 */
export function useAutoSave({ store, logger, currentStep, stepData, addToast }: UseAutoSaveOptions) {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prevDataRef = useRef<string>('');

  useEffect(() => {
    const stepKey = `step${currentStep}`;
    const data = stepData[stepKey] || {};
    const serialized = JSON.stringify(data);

    if (serialized === prevDataRef.current) return;
    if (serialized === '{}') { prevDataRef.current = serialized; return; }

    prevDataRef.current = serialized;

    if (timerRef.current) clearTimeout(timerRef.current);

    timerRef.current = setTimeout(async () => {
      try {
        const result = await mockSaveDraft(store, logger, stepKey, data);
        if (result.success) {
          addToast({ type: 'success', message: 'Draft saved' });
        }
      } catch {
        addToast({ type: 'error', message: 'Auto-save failed' });
      }
    }, 2000);

    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [store, logger, currentStep, stepData, addToast]);
}
