import { useEffect, useRef, useState } from 'react';
import { mockGetAutomatedChecks, mockGetReviewStatus } from '../lib/mockApi';
import type { MockStore, Logger, Check, Review } from '../lib/mockApi';

interface UsePollingOptions {
  store: MockStore;
  logger: Logger;
  active: boolean;
  intervalMs?: number;
}

/**
 * O-03: usePolling — Polls automated checks and review status at a
 * configurable interval. Only runs when `active` is true (post-submission).
 */
export function usePolling({ store, logger, active, intervalMs = 3000 }: UsePollingOptions) {
  const [checks, setChecks] = useState<Check[]>([]);
  const [checksComplete, setChecksComplete] = useState(false);
  const [reviews, setReviews] = useState<Review[]>([]);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!active) return;

    const poll = async () => {
      try {
        const checksRes = await mockGetAutomatedChecks(store, logger);
        setChecks(checksRes.checks);
        setChecksComplete(checksRes.status === 'completed');

        const reviewRes = await mockGetReviewStatus(store, logger);
        setReviews(reviewRes.reviews);
      } catch {
        // Silently skip poll failures
      }
    };

    poll();
    intervalRef.current = setInterval(poll, intervalMs);

    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [active, store, logger, intervalMs]);

  return { checks, checksComplete, reviews };
}
