import type { StepData } from '../lib/mockApi';
import {
  Step1ProductIdentity,
  Step2Ownership,
  Step3Connect,
  Step4KdeSemantics,
  Step5ScopeDq,
  Step6DataContract,
  Step7Lineage,
  Step8Sensitivity,
  Step9AiReadiness,
  Step10Submit,
} from './steps';

interface RegistrationFormProps {
  currentStep: number;
  stepData: Record<string, StepData>;
  errors: Record<string, string>;
  warnings: Record<string, string>;
  onUpdate: (field: string, value: string | boolean) => void;
  onBack: () => void;
  onContinue: () => void;
  onSubmit: () => void;
  isLastStep: boolean;
}

const STEP_COMPONENTS = [
  Step1ProductIdentity,
  Step2Ownership,
  Step3Connect,
  Step4KdeSemantics,
  Step5ScopeDq,
  Step6DataContract,
  Step7Lineage,
  Step8Sensitivity,
  Step9AiReadiness,
  Step10Submit,
];

/**
 * RegistrationForm — Renders the active step form with Back/Continue buttons.
 * Routes to the correct step component based on currentStep.
 */
export function RegistrationForm({
  currentStep,
  stepData,
  errors,
  warnings,
  onUpdate,
  onBack,
  onContinue,
  onSubmit,
  isLastStep,
}: RegistrationFormProps) {
  const StepComponent = STEP_COMPONENTS[currentStep - 1];
  const stepKey = `step${currentStep}`;
  const data = stepData[stepKey] || {};

  return (
    <div className="space-y-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 text-[#000000]">Register Data Product</h1>
        <p className="text-[#5a5a5a]">Simple, guided registration aligned to WMA governance.</p>
      </div>

      <StepComponent
        data={data}
        onUpdate={onUpdate}
        errors={errors}
        warnings={warnings}
      />

      <div className="flex justify-end gap-3">
        {currentStep > 1 && (
          <button
            onClick={onBack}
            className="px-5 py-2 border border-[#000000] rounded-full text-sm font-medium hover:bg-[#f4f4f4] transition-colors"
          >
            Back
          </button>
        )}
        {isLastStep ? (
          <button
            onClick={onSubmit}
            className="px-5 py-2 bg-[#e60028] text-white rounded-full text-sm font-medium hover:bg-[#c50022] transition-colors"
          >
            Submit Registration
          </button>
        ) : (
          <button
            onClick={onContinue}
            className="px-5 py-2 bg-[#e60028] text-white rounded-full text-sm font-medium hover:bg-[#c50022] transition-colors"
          >
            Save & Continue
          </button>
        )}
      </div>
    </div>
  );
}
