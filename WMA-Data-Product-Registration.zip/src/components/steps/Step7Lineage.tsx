import { Field } from '../atoms';
import { Badge } from '../atoms';
import { CardWrapper } from '../atoms';
import type { StepFormProps } from './StepFormProps';

/**
 * S-07: Step7Lineage — Document upstream sources and transformation logic.
 * Fields: upstreamProducts, lineageNarrative, transformations, dataFlowDiagram.
 * All fields optional (warnings only).
 */
export function Step7Lineage({ data, onUpdate, errors, warnings }: StepFormProps) {
  const v = (field: string) => (typeof data[field] === 'string' ? data[field] as string : '');

  return (
    <CardWrapper>
      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold mb-1 text-[#000000]">Step 7: Lineage</h2>
          <p className="text-sm text-[#5a5a5a]">Document data sources and transformations.</p>
        </div>
        <Badge variant="optional" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Upstream Products" value={v('upstreamProducts')} onChange={(val) => onUpdate('upstreamProducts', val)} type="textarea" placeholder="List upstream data products" error={errors.upstreamProducts} warning={warnings.upstreamProducts} span2 />
        <Field label="Lineage Narrative" value={v('lineageNarrative')} onChange={(val) => onUpdate('lineageNarrative', val)} type="textarea" placeholder="Describe the data flow end-to-end" error={errors.lineageNarrative} warning={warnings.lineageNarrative} span2 />
        <Field label="Transformations" value={v('transformations')} onChange={(val) => onUpdate('transformations', val)} type="textarea" placeholder="Key transformations applied" error={errors.transformations} warning={warnings.transformations} span2 />
        <Field label="Data Flow Diagram URL" value={v('dataFlowDiagram')} onChange={(val) => onUpdate('dataFlowDiagram', val)} placeholder="Link to diagram (optional)" error={errors.dataFlowDiagram} warning={warnings.dataFlowDiagram} span2 />
      </div>
    </CardWrapper>
  );
}
