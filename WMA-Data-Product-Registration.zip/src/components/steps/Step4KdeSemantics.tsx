import { Field } from '../atoms';
import { Badge } from '../atoms';
import { CardWrapper } from '../atoms';
import type { StepFormProps } from './StepFormProps';

/**
 * S-04: Step4KdeSemantics — Business metadata and KDE mapping.
 * Fields: businessDefs, kdeMapping, ontologyAlignment, glossaryTerms.
 * All fields are optional (warnings only, no required).
 */
export function Step4KdeSemantics({ data, onUpdate, errors, warnings }: StepFormProps) {
  const v = (field: string) => (typeof data[field] === 'string' ? data[field] as string : '');

  return (
    <CardWrapper>
      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold mb-1 text-[#000000]">Step 4: KDE Semantics</h2>
          <p className="text-sm text-[#5a5a5a]">Define business metadata and KDE alignment.</p>
        </div>
        <Badge variant="optional" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Business Definitions" value={v('businessDefs')} onChange={(val) => onUpdate('businessDefs', val)} type="textarea" placeholder="Business term definitions" error={errors.businessDefs} warning={warnings.businessDefs} span2 />
        <Field label="KDE Mapping" value={v('kdeMapping')} onChange={(val) => onUpdate('kdeMapping', val)} type="textarea" placeholder="Key data element mappings" error={errors.kdeMapping} warning={warnings.kdeMapping} span2 />
        <Field label="Ontology Alignment" value={v('ontologyAlignment')} onChange={(val) => onUpdate('ontologyAlignment', val)} placeholder="Ontology name or ID" error={errors.ontologyAlignment} warning={warnings.ontologyAlignment} />
        <Field label="Glossary Terms" value={v('glossaryTerms')} onChange={(val) => onUpdate('glossaryTerms', val)} placeholder="Linked glossary terms" error={errors.glossaryTerms} warning={warnings.glossaryTerms} />
      </div>
    </CardWrapper>
  );
}
