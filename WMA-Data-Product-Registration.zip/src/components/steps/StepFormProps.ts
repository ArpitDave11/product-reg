import type { StepData } from '../../lib/mockApi';

/**
 * Common props for all step form components.
 * Each step receives the same contract — data in, changes out.
 */
export interface StepFormProps {
  data: StepData;
  onUpdate: (field: string, value: string | boolean) => void;
  errors: Record<string, string>;
  warnings: Record<string, string>;
}
