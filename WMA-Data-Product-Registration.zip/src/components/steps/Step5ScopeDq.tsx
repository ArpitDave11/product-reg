import { Field } from '../atoms';
import { Badge } from '../atoms';
import { CardWrapper } from '../atoms';
import type { StepFormProps } from './StepFormProps';

/**
 * S-05: Step5ScopeDq — Define data quality thresholds and fitness metrics.
 * Fields: threshold, coverage, completeness, timeliness, accuracy.
 */
export function Step5ScopeDq({ data, onUpdate, errors, warnings }: StepFormProps) {
  const v = (field: string) => (typeof data[field] === 'string' ? data[field] as string : '');

  return (
    <CardWrapper>
      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold mb-1 text-[#000000]">Step 5: Scope & Data Quality</h2>
          <p className="text-sm text-[#5a5a5a]">Define fitness-for-use and data quality rules.</p>
        </div>
        <Badge variant="required" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="DQ Threshold (%)" value={v('threshold')} onChange={(val) => onUpdate('threshold', val)} placeholder="e.g. 95" error={errors.threshold} warning={warnings.threshold} />
        <Field label="Coverage (%)" value={v('coverage')} onChange={(val) => onUpdate('coverage', val)} placeholder="e.g. 99" error={errors.coverage} warning={warnings.coverage} />
        <Field label="Completeness (%)" value={v('completeness')} onChange={(val) => onUpdate('completeness', val)} placeholder="e.g. 98" error={errors.completeness} warning={warnings.completeness} />
        <Field label="Timeliness" value={v('timeliness')} onChange={(val) => onUpdate('timeliness', val)} type="select" options={['Real-time', 'Near real-time', 'Hourly', 'Daily', 'Weekly']} error={errors.timeliness} warning={warnings.timeliness} />
        <Field label="Accuracy Rule" value={v('accuracy')} onChange={(val) => onUpdate('accuracy', val)} type="textarea" placeholder="Describe accuracy requirements" error={errors.accuracy} warning={warnings.accuracy} span2 />
      </div>
    </CardWrapper>
  );
}
