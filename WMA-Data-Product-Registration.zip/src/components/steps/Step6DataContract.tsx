import { Field } from '../atoms';
import { Badge } from '../atoms';
import { CardWrapper } from '../atoms';
import type { StepFormProps } from './StepFormProps';

/**
 * S-06: Step6DataContract — Define update frequency, access modes, and agreements.
 * Fields: updateFrequency, accessModes, deprecationPolicy, slaTarget, versioningPolicy.
 */
export function Step6DataContract({ data, onUpdate, errors, warnings }: StepFormProps) {
  const v = (field: string) => (typeof data[field] === 'string' ? data[field] as string : '');

  return (
    <CardWrapper>
      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold mb-1 text-[#000000]">Step 6: Data Contract</h2>
          <p className="text-sm text-[#5a5a5a]">Define agreement, access modes and SLAs.</p>
        </div>
        <Badge variant="required" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Update Frequency" value={v('updateFrequency')} onChange={(val) => onUpdate('updateFrequency', val)} type="select" options={['Real-time', 'Daily', 'Weekly', 'Monthly', 'Quarterly', 'On-demand']} error={errors.updateFrequency} warning={warnings.updateFrequency} />
        <Field label="Access Modes" value={v('accessModes')} onChange={(val) => onUpdate('accessModes', val)} type="select" options={['API', 'Batch', 'Stream', 'SQL', 'File Export']} error={errors.accessModes} warning={warnings.accessModes} />
        <Field label="SLA Target" value={v('slaTarget')} onChange={(val) => onUpdate('slaTarget', val)} placeholder="e.g. 99.5% uptime" error={errors.slaTarget} warning={warnings.slaTarget} />
        <Field label="Versioning Policy" value={v('versioningPolicy')} onChange={(val) => onUpdate('versioningPolicy', val)} type="select" options={['Semantic', 'Date-based', 'None']} error={errors.versioningPolicy} warning={warnings.versioningPolicy} />
        <Field label="Deprecation Policy" value={v('deprecationPolicy')} onChange={(val) => onUpdate('deprecationPolicy', val)} type="textarea" placeholder="How and when the product may be deprecated" error={errors.deprecationPolicy} warning={warnings.deprecationPolicy} span2 />
      </div>
    </CardWrapper>
  );
}
