import { Field } from '../atoms';
import { Badge } from '../atoms';
import { CardWrapper } from '../atoms';
import type { StepFormProps } from './StepFormProps';

/**
 * S-09: Step9AiReadiness — Optional AI/ML readiness assessment.
 * Fields: aiReadyFlag, aiUseCases, mlModelCompatibility, featureStore, biasAssessment.
 * Entirely optional — no required fields.
 */
export function Step9AiReadiness({ data, onUpdate, errors, warnings }: StepFormProps) {
  const v = (field: string) => (typeof data[field] === 'string' ? data[field] as string : '');
  const b = (field: string) => data[field] === true;

  return (
    <CardWrapper>
      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold mb-1 text-[#000000]">Step 9: AI Readiness</h2>
          <p className="text-sm text-[#5a5a5a]">Optional assessment for AI/ML analytics readiness.</p>
        </div>
        <Badge variant="optional" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="AI Ready" value={b('aiReadyFlag')} onChange={(val) => onUpdate('aiReadyFlag', val)} type="checkbox" placeholder="This product is suitable for AI/ML use" error={errors.aiReadyFlag} warning={warnings.aiReadyFlag} span2 />
        <Field label="AI Use Cases" value={v('aiUseCases')} onChange={(val) => onUpdate('aiUseCases', val)} type="textarea" placeholder="Describe intended AI/ML use cases" error={errors.aiUseCases} warning={warnings.aiUseCases} span2 />
        <Field label="ML Model Compatibility" value={v('mlModelCompatibility')} onChange={(val) => onUpdate('mlModelCompatibility', val)} type="select" options={['Structured only', 'Unstructured', 'Both', 'Not assessed']} error={errors.mlModelCompatibility} warning={warnings.mlModelCompatibility} />
        <Field label="Feature Store" value={v('featureStore')} onChange={(val) => onUpdate('featureStore', val)} type="select" options={['Available', 'Planned', 'Not applicable']} error={errors.featureStore} warning={warnings.featureStore} />
        <Field label="Bias Assessment" value={v('biasAssessment')} onChange={(val) => onUpdate('biasAssessment', val)} type="textarea" placeholder="Known biases or mitigation notes" error={errors.biasAssessment} warning={warnings.biasAssessment} span2 />
      </div>
    </CardWrapper>
  );
}
