import { CardWrapper, StatusPill } from '../atoms';

interface CertificationPipelineProps {
  checksComplete: boolean;
}

const PIPELINE_STEPS = ['Integrity Check', 'Entitlement Validation', 'Register', 'Publish'];

/**
 * P-04: CertificationPipeline — Shows the certification and publish pipeline
 * steps. Activated after automated checks complete.
 */
export function CertificationPipeline({ checksComplete }: CertificationPipelineProps) {
  return (
    <CardWrapper>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-[#000000]">Certification & Publish (WMA)</h3>
        <StatusPill label={checksComplete ? 'Ready' : 'Waiting'} variant={checksComplete ? 'success' : 'default'} />
      </div>
      <div className="flex flex-wrap gap-3">
        {PIPELINE_STEPS.map((step) => (
          <span key={step} className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
            {step}
          </span>
        ))}
      </div>
      <p className="text-xs text-[#5a5a5a] mt-4">
        Product becomes discoverable for consumers in WMA Data Catalog.
      </p>
    </CardWrapper>
  );
}
