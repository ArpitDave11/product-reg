import { CardWrapper, StatusPill } from '../atoms';
import type { Check } from '../../lib/mockApi';
import type { PillVariant } from '../atoms';

interface AutomatedChecksPanelProps {
  checks: Check[];
  complete: boolean;
}

const STATUS_VARIANT: Record<Check['status'], PillVariant> = {
  passed: 'success',
  running: 'progress',
  pending: 'default',
  warning: 'warning',
  failed: 'error',
};

/**
 * P-02: AutomatedChecksPanel — Displays the list of automated checks
 * with their current status (pending → running → passed/warning/failed).
 */
export function AutomatedChecksPanel({ checks, complete }: AutomatedChecksPanelProps) {
  return (
    <CardWrapper>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-[#000000]">Automated Checks</h3>
        <StatusPill label={complete ? 'Completed' : 'Running'} variant={complete ? 'success' : 'progress'} />
      </div>
      <ul className="space-y-3">
        {checks.map((check) => (
          <li key={check.name} className="flex items-center justify-between p-3 border border-[#d9d9d9] rounded-xl text-sm">
            <div className="text-[#000000]">
              {check.name}
              {check.score != null && <span className="ml-2 text-xs text-[#5a5a5a]">(Score: {check.score})</span>}
              {check.note && <span className="ml-2 text-xs text-[#f57f17]">{check.note}</span>}
            </div>
            <StatusPill label={check.status} variant={STATUS_VARIANT[check.status]} />
          </li>
        ))}
      </ul>
      {checks.length === 0 && (
        <p className="text-sm text-[#5a5a5a]">Waiting for checks to start...</p>
      )}
    </CardWrapper>
  );
}
