import { CardWrapper, StatusPill } from '../atoms';
import type { Review } from '../../lib/mockApi';
import type { PillVariant } from '../atoms';

interface ReviewDashboardProps {
  reviews: Review[];
}

const REVIEW_VARIANT: Record<Review['status'], PillVariant> = {
  Pending: 'progress',
  Waiting: 'default',
  Approved: 'success',
};

/**
 * P-03: ReviewDashboard — Shows human reviewer status with SLA info.
 */
export function ReviewDashboard({ reviews }: ReviewDashboardProps) {
  return (
    <CardWrapper>
      <h3 className="font-bold mb-4 text-[#000000]">Human Review</h3>
      <div className="space-y-2">
        <div className="grid grid-cols-3 gap-3 p-3 bg-[#f4f4f4] rounded-xl font-bold text-sm text-[#000000]">
          <div>Reviewer</div>
          <div>Status</div>
          <div>SLA</div>
        </div>
        {reviews.map((review) => (
          <div key={review.name} className="grid grid-cols-3 gap-3 p-3 border border-[#d9d9d9] rounded-xl text-sm text-[#000000]">
            <div>{review.name}</div>
            <div><StatusPill label={review.status} variant={REVIEW_VARIANT[review.status]} /></div>
            <div>{review.sla}</div>
          </div>
        ))}
      </div>
      {reviews.length === 0 && (
        <p className="text-sm text-[#5a5a5a]">Reviews will begin after automated checks complete.</p>
      )}
    </CardWrapper>
  );
}
