import { CardWrapper } from '../atoms';

interface ConfirmationCardProps {
  trackingId: string;
  submittedAt: string;
  eta: string;
}

/**
 * P-01: ConfirmationCard — Displays submission receipt with tracking ID,
 * timestamp, and estimated time to completion.
 */
export function ConfirmationCard({ trackingId, submittedAt, eta }: ConfirmationCardProps) {
  return (
    <CardWrapper>
      <div className="flex items-center gap-4 p-4 border border-dashed border-[#d9d9d9] rounded-xl bg-[#fffdf5]">
        <div className="w-9 h-9 rounded-full bg-[#ddf6e0] text-[#2e7d32] flex items-center justify-center font-bold text-lg flex-shrink-0">
          &#x2713;
        </div>
        <div>
          <div className="font-bold text-sm text-[#000000]">Submission Received</div>
          <div className="text-xs text-[#5a5a5a]">Your data product is now in automated checks.</div>
        </div>
      </div>
      <div className="flex flex-wrap gap-3 mt-4">
        <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
          Tracking ID: {trackingId}
        </span>
        <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
          Submitted: {submittedAt}
        </span>
        <span className="px-3 py-1 border border-[#d9d9d9] rounded-full text-xs bg-white text-[#000000]">
          ETA: {eta}
        </span>
      </div>
    </CardWrapper>
  );
}
