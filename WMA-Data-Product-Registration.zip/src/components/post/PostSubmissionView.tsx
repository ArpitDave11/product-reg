import type { Check, Review, SubmissionState } from '../../lib/mockApi';
import { ConfirmationCard } from './ConfirmationCard';
import { AutomatedChecksPanel } from './AutomatedChecksPanel';
import { ReviewDashboard } from './ReviewDashboard';
import { CertificationPipeline } from './CertificationPipeline';

interface PostSubmissionViewProps {
  submission: SubmissionState | null;
  checks: Check[];
  checksComplete: boolean;
  reviews: Review[];
}

/**
 * P-05: PostSubmissionView — Composite view that assembles all
 * post-submission components into the dashboard layout.
 */
export function PostSubmissionView({ submission, checks, checksComplete, reviews }: PostSubmissionViewProps) {
  if (!submission) return null;

  return (
    <div className="space-y-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 text-[#000000]">Submission Dashboard</h1>
        <p className="text-[#5a5a5a]">Track your data product registration progress.</p>
      </div>

      <ConfirmationCard
        trackingId={submission.trackingId}
        submittedAt={submission.submittedAt}
        eta={submission.eta}
      />

      <div className="grid grid-cols-2 gap-6">
        <AutomatedChecksPanel checks={checks} complete={checksComplete} />
        <ReviewDashboard reviews={reviews} />
      </div>

      <CertificationPipeline checksComplete={checksComplete} />
    </div>
  );
}
