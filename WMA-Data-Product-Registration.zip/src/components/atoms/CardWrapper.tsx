import type { ReactNode } from 'react';

interface CardWrapperProps {
  children: ReactNode;
  muted?: boolean;
  className?: string;
}

/**
 * U-07: CardWrapper — Standard card container used by every step form
 * and dashboard panel. Matches the wireframe card style.
 */
export function CardWrapper({ children, muted = false, className = '' }: CardWrapperProps) {
  const bg = muted ? 'bg-[#f4f4f4]' : 'bg-white';

  return (
    <div className={`border border-[#d9d9d9] rounded-2xl p-6 ${bg} ${className}`}>
      {children}
    </div>
  );
}
