export type PillVariant = 'default' | 'progress' | 'success' | 'warning' | 'error';

interface StatusPillProps {
  label: string;
  variant?: PillVariant;
}

const VARIANT_STYLES: Record<PillVariant, string> = {
  default:  'border-[#d9d9d9] text-[#5a5a5a] bg-white',
  progress: 'border-[#e60028] text-[#e60028] bg-white',
  success:  'border-[#2e7d32] text-[#2e7d32] bg-[#ddf6e0]',
  warning:  'border-[#f57f17] text-[#f57f17] bg-[#fff8e1]',
  error:    'border-[#e60028] text-[#e60028] bg-[#ffe6ea]',
};

/**
 * U-06: StatusPill — Small pill showing a status label with colored styling.
 */
export function StatusPill({ label, variant = 'default' }: StatusPillProps) {
  return (
    <span className={`px-3 py-1 border rounded-full text-xs font-medium ${VARIANT_STYLES[variant]}`}>
      {label}
    </span>
  );
}
