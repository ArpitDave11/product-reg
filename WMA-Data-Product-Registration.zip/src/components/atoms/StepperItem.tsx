export interface StepInfo {
  id: number;
  title: string;
  sub: string;
}

export type StepStatus = 'completed' | 'active' | 'upcoming' | 'error';

interface StepperItemProps {
  step: StepInfo;
  status: StepStatus;
  onClick: () => void;
}

/**
 * U-04: StepperItem — A single step item in the sidebar stepper.
 * Shows step number in a circle, title, subtitle, and visual status.
 */
export function StepperItem({ step, status, onClick }: StepperItemProps) {
  const circleStyle = {
    completed: 'bg-[#e60028] text-white',
    active: 'border-2 border-[#e60028] text-[#e60028] bg-white',
    upcoming: 'bg-[#d9d9d9] text-white',
    error: 'border-2 border-[#e60028] text-[#e60028] bg-white',
  }[status];

  const cardStyle = {
    completed: 'border-[#d9d9d9] bg-white',
    active: 'border-[#e60028] shadow-sm bg-white',
    upcoming: 'border-dashed border-[#d9d9d9] bg-white',
    error: 'border-[#e60028] bg-[#ffe6ea]',
  }[status];

  const titleColor = status === 'error' ? 'text-[#e60028]' : 'text-[#000000]';

  return (
    <li
      className={`flex gap-3 p-3 border rounded-xl cursor-pointer transition-colors ${cardStyle}`}
      onClick={onClick}
    >
      <div
        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${circleStyle}`}
      >
        {status === 'completed' ? '\u2713' : step.id}
      </div>
      <div className="flex flex-col gap-0.5">
        <div className={`font-medium text-sm ${titleColor}`}>{step.title}</div>
        <div className="text-xs text-[#5a5a5a]">{step.sub}</div>
      </div>
    </li>
  );
}
