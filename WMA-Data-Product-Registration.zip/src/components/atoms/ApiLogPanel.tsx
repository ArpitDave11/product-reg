import { useEffect, useRef } from 'react';
import type { ApiLogEntry } from '../../lib/foundation';

interface ApiLogPanelProps {
  logs: ApiLogEntry[];
  visible: boolean;
  onToggle: () => void;
}

const METHOD_COLORS: Record<string, string> = {
  GET: 'text-[#2e7d32]',
  POST: 'text-[#1565c0]',
  PUT: 'text-[#f57f17]',
  DELETE: 'text-[#e60028]',
};

const STATUS_COLORS: Record<string, string> = {
  ok: 'text-[#2e7d32]',
  pending: 'text-[#5a5a5a]',
  error: 'text-[#e60028]',
};

/**
 * U-02: ApiLogPanel — Collapsible panel showing API activity.
 * Collapsed: thin bar with call count. Expanded: scrollable log list.
 */
export function ApiLogPanel({ logs, visible, onToggle }: ApiLogPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (visible && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs.length, visible]);

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#d9d9d9]">
      <button
        className="w-full flex items-center justify-between px-4 py-2 text-xs text-[#5a5a5a] hover:bg-[#f4f4f4] transition-colors"
        onClick={onToggle}
      >
        <span className="font-medium">API Activity Log ({logs.length} calls)</span>
        <span>{visible ? '\u25BC' : '\u25B2'}</span>
      </button>

      {visible && (
        <div ref={scrollRef} className="max-h-48 overflow-y-auto px-4 pb-3">
          <div className="grid grid-cols-[60px_50px_1fr_60px_60px] gap-2 text-xs font-bold text-[#5a5a5a] border-b border-[#d9d9d9] pb-1 mb-1">
            <span>Time</span>
            <span>Method</span>
            <span>Endpoint</span>
            <span>Status</span>
            <span>Duration</span>
          </div>
          {logs.map((entry) => (
            <div
              key={entry.id}
              className="grid grid-cols-[60px_50px_1fr_60px_60px] gap-2 text-xs py-0.5"
            >
              <span className="text-[#5a5a5a]">{entry.time}</span>
              <span className={`font-bold ${METHOD_COLORS[entry.method] || 'text-[#000000]'}`}>
                {entry.method}
              </span>
              <span className="text-[#000000] truncate">{entry.endpoint}</span>
              <span className={`font-medium ${STATUS_COLORS[entry.status] || ''}`}>
                {entry.status}
              </span>
              <span className="text-[#5a5a5a]">
                {entry.duration != null ? `${entry.duration}ms` : '...'}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
