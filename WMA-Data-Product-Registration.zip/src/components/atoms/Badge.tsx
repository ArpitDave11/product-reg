interface BadgeProps {
  variant: 'required' | 'optional';
}

/**
 * U-05: Badge — Small pill showing "Required" or "Optional" on step cards.
 */
export function Badge({ variant }: BadgeProps) {
  const style = variant === 'required'
    ? 'bg-[#ffe6ea] text-[#e60028] border-[#ffcccc]'
    : 'bg-[#f4f4f4] text-[#5a5a5a] border-[#d9d9d9]';

  const label = variant === 'required' ? 'Required' : 'Optional';

  return (
    <span className={`px-3 py-1 border rounded-full text-xs font-medium ${style}`}>
      {label}
    </span>
  );
}
