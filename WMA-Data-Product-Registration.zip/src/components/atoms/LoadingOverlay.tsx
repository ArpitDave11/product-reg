interface LoadingOverlayProps {
  visible: boolean;
  message: string;
}

/**
 * U-08: LoadingOverlay — Semi-transparent overlay with spinner and message.
 * Used during submission and other heavy operations.
 */
export function LoadingOverlay({ visible, message }: LoadingOverlayProps) {
  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
      <div className="bg-white rounded-2xl p-8 shadow-lg flex flex-col items-center gap-4 max-w-sm">
        <div className="w-10 h-10 border-4 border-[#d9d9d9] border-t-[#e60028] rounded-full animate-spin" />
        <p className="text-sm text-[#000000] font-medium text-center">{message}</p>
      </div>
    </div>
  );
}
